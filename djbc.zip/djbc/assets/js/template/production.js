const content =`
<div id="content-prod">
  <div class="row ps-3 pe-3 mt-2">
    PRODUCTION KONTENT
  </div>
</div>`;

export function showContent(){
  return content;
}