<?php
session_start();
//error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ERROR);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  //prod list
  if ($section == 1){ //view prod list
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];

    $strSql = "
    SELECT a.*, IFNULL(b.aqtynx, 0) aqtynx, IFNULL(b.aqtyox, 0) aqtyox, IFNULL(c.ahcnx, 0) ahcnx, IFNULL(c.ahcox, 0) ahcox, IFNULL(d.awhnx, 0) awhnx, IFNULL(e.awhox, 0) awhox, 
    f.PART_NAME part_namex, g.LINE_DESC line_namex, g.LINE_NAME_SPV line_spvx, CURDATE() datex, HOUR(CURTIME()) timex 
    FROM (
      SELECT a.planx, a.linex, a.groupx, partx, fchx, dayx, phcx, effx, groupidx, 
        SUM(whnx) whnx, SUM(whox) whox, SUM(qtynx) qtynx, SUM(qtyox) qtyox 
      FROM (
        SELECT
          (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
          CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) planx, 
          a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_PART partx, 
          a.PLAN_PROD_FCH fchx, a.PLAN_PROD_RD dayx, a.PLAN_PROD_OPT phcx, 
          a.PLAN_PROD_EFF effx, 
          CASE WHEN a.PLAN_PROD_FLAG ='N' THEN a.PLAN_PROD_WH ELSE 0 END whnx,
          CASE WHEN a.PLAN_PROD_FLAG ='O' THEN a.PLAN_PROD_WH ELSE 0 END whox,
          CASE WHEN a.PLAN_PROD_FLAG ='N' THEN a.PLAN_PROD_QTY ELSE 0 END qtynx,
          CASE WHEN a.PLAN_PROD_FLAG ='O' THEN a.PLAN_PROD_QTY ELSE 0 END qtyox,
          a.PLAN_PROD_GROUP groupidx
        FROM plan_prod_daily a 
        WHERE a.PLAN_PROD_DATE = '" . $date . "'
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
      ) a GROUP BY a.planx, a.linex, a.groupx, partx, fchx, dayx, phcx, effx, groupidx
    ) a
    LEFT JOIN (
      SELECT planx, SUM(aqtynx) aqtynx, SUM(aqtyox) aqtyox 
      FROM (
        SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) planx, a.OUT_PROD_QTY aqtynx, 0 aqtyox 
        FROM output_prod_good a 
        WHERE a.OUT_PROD_DATE = '" . $date . "' 
        AND IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE ='N' UNION ALL
        SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) planx, 0 aqtynx, a.OUT_PROD_QTY aqtyox 
        FROM output_prod_good a 
        WHERE a.OUT_PROD_DATE = '" . $date . "' 
        AND IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE ='O'
      ) a GROUP BY planx
    ) b ON a.planx = b.planx
    LEFT JOIN (
      SELECT planx, SUM(ahcnx) ahcnx, SUM(ahcox) ahcox 
      FROM ( 
        SELECT CONCAT(LEFT(a.PLAN_ID, 19), REPLACE(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'N','')) planx, a.OUT_PROD_GOOD_AHC ahcnx, 0 ahcox
        FROM output_prod_good_hc a 
        WHERE LEFT(a.PLAN_ID, 8) = '" . str_replace("-", "", $date) . "' AND INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'N') <> 0 UNION ALL
        SELECT CONCAT(LEFT(a.PLAN_ID, 19), REPLACE(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'O','')) planx, 0 ahcnx, a.OUT_PROD_GOOD_AHC ahcox
        FROM output_prod_good_hc a 
        WHERE LEFT(a.PLAN_ID, 8) = '" . str_replace("-", "", $date) . "' AND INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'O') <> 0
      ) a GROUP BY a.planx
    ) c ON a.planx = c.planx
    LEFT JOIN (
      SELECT planx, count_actual_wh(HOUR(a.FIRST_TIME), HOUR(a.LAST_TIME), a.datex) awhnx
      FROM (
        SELECT 
          CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) planx,
          a.OUT_PROD_DATE datex,
          MIN(a.OUT_PROD_TIME) FIRST_TIME,
          MAX(a.OUT_PROD_TIME) LAST_TIME,
          TIMESTAMPDIFF(MINUTE, MIN(a.OUT_PROD_TIME), MAX(a.OUT_PROD_TIME)) WH_ACT, 0 HC_ACT
        FROM output_prod_good a 
        WHERE a.OUT_PROD_DATE = '" . $date . "'
        AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D' AND INSTR(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N') <> 0
        GROUP BY CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N',''))
      ) a
    ) d ON a.planx = d.planx
    LEFT JOIN (
      SELECT planx, count_actual_wh(HOUR(a.FIRST_TIME), HOUR(a.LAST_TIME), a.datex) awhox
      FROM (
        SELECT 
          CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) planx,
          a.OUT_PROD_DATE datex,
          MIN(a.OUT_PROD_TIME) FIRST_TIME,
          MAX(a.OUT_PROD_TIME) LAST_TIME,
          TIMESTAMPDIFF(MINUTE, MIN(a.OUT_PROD_TIME), MAX(a.OUT_PROD_TIME)) WH_ACT, 0 HC_ACT
        FROM output_prod_good a 
        WHERE a.OUT_PROD_DATE = '" . $date . "'
        AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D' AND INSTR(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O') <> 0
        GROUP BY CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O',''))
      ) a
    ) e ON a.planx = e.planx 
    LEFT JOIN toy_part f ON a.partx = f.PART_NUM
    LEFT JOIN line g ON a.linex = g.LINE_CODE
    WHERE 1=1
    " . (($unit !="" && $unit != "ALL") ? " AND g.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND g.LINE_CODE ='$line' " : "") . "
    " . (($line_all !="") ? " AND g.LINE_CODE IN (" . $line_all . ")" : "") . "
    ORDER BY g.LINE_ORDR, a.groupx, a.partx;
    ";

  } else if ($section == 2) { //view prod detail
    $plan_id = $_GET["param_id"];
    $strSql = "
    SELECT a.*, IFNULL(b.aqtynx, 0) aqtynx, IFNULL(b.aqtyox, 0) aqtyox, IFNULL(c.ahcnx, 0) ahcnx, IFNULL(c.ahcox, 0) ahcox, IFNULL(d.awhnx, 0) awhnx, IFNULL(e.awhox, 0) awhox, 
    f.PART_NAME part_namex, g.LINE_DESC line_namex, IFNULL(j.LEADER_NAME, g.LINE_NAME_SPV) line_spvx, g.LINE_PREF unitx, 
    IFNULL(h.idnx, '') idnx, IFNULL(i.idox, '') idox, IFNULL(h.csldnx, '') csldnx, IFNULL(i.csldox, '') csldox,  
    CURDATE() date_svrx, HOUR(CURTIME()) time_svrx
    FROM (
      SELECT a.planx, a.datex, a.linex, a.groupx, partx, fchx, dayx, phcx, effx, groupidx, 
        SUM(whnx) whnx, SUM(whox) whox, SUM(qtynx) qtynx, SUM(qtyox) qtyox 
      FROM (
        SELECT
          (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
          CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) planx, 
          a.PLAN_PROD_DATE datex,
          a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_PART partx, 
          a.PLAN_PROD_FCH fchx, a.PLAN_PROD_RD dayx, a.PLAN_PROD_OPT phcx, 
          a.PLAN_PROD_EFF effx, 
          CASE WHEN a.PLAN_PROD_FLAG ='N' THEN a.PLAN_PROD_WH ELSE 0 END whnx,
          CASE WHEN a.PLAN_PROD_FLAG ='O' THEN a.PLAN_PROD_WH ELSE 0 END whox,
          CASE WHEN a.PLAN_PROD_FLAG ='N' THEN a.PLAN_PROD_QTY ELSE 0 END qtynx,
          CASE WHEN a.PLAN_PROD_FLAG ='O' THEN a.PLAN_PROD_QTY ELSE 0 END qtyox,
          a.PLAN_PROD_GROUP groupidx
        FROM plan_prod_daily a 
        WHERE (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
          CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) = '" . $plan_id . "' 
      ) a GROUP BY a.planx, a.datex, a.linex, a.groupx, partx, fchx, dayx, phcx, effx, groupidx
    ) a
    LEFT JOIN (
      SELECT planx, SUM(aqtynx) aqtynx, SUM(aqtyox) aqtyox 
      FROM (
        SELECT 
          CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) planx, 
          a.OUT_PROD_QTY aqtynx, 0 aqtyox 
        FROM output_prod_good a 
        WHERE CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) = '" . $plan_id . "'
        AND IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE ='N' UNION ALL
        SELECT 
          CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) planx, 
          0 aqtynx, a.OUT_PROD_QTY aqtyox 
        FROM output_prod_good a 
        WHERE CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) = '" . $plan_id . "'
        AND IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE ='O'
      ) a GROUP BY planx
    ) b ON a.planx = b.planx
    LEFT JOIN (
      SELECT planx, SUM(ahcnx) ahcnx, SUM(ahcox) ahcox 
      FROM ( 
        SELECT 
          CONCAT(LEFT(a.PLAN_ID, 19), REPLACE(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'N','')) planx,
          a.OUT_PROD_GOOD_AHC ahcnx, 0 ahcox
        FROM output_prod_good_hc a 
        WHERE INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'N') <> 0 AND CONCAT(LEFT(a.PLAN_ID, 19), REPLACE(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'N','')) = '" . $plan_id ."' UNION ALL
        SELECT 
          CONCAT(LEFT(a.PLAN_ID, 19), REPLACE(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'O','')) planx,
          0 ahcnx, a.OUT_PROD_GOOD_AHC ahcox
        FROM output_prod_good_hc a 
        WHERE INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'O') <> 0 AND CONCAT(LEFT(a.PLAN_ID, 19), REPLACE(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'O','')) ='" . $plan_id ."'
      ) a GROUP BY a.planx
    ) c ON a.planx = c.planx
    LEFT JOIN (
      SELECT planx, count_actual_wh(HOUR(a.FIRST_TIME), HOUR(a.LAST_TIME), a.datex) awhnx
      FROM (
        SELECT 
          CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) planx,
          a.OUT_PROD_DATE datex,
          MIN(a.OUT_PROD_TIME) FIRST_TIME,
          MAX(a.OUT_PROD_TIME) LAST_TIME,
          TIMESTAMPDIFF(MINUTE, MIN(a.OUT_PROD_TIME), MAX(a.OUT_PROD_TIME)) WH_ACT, 0 HC_ACT
        FROM output_prod_good a 
        WHERE IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D' AND a.OUT_PROD_TYPE ='N'
        AND CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) = '" . $plan_id ."'
        GROUP BY CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')), a.OUT_PROD_DATE
      ) a
    ) d ON a.planx = d.planx
    LEFT JOIN (
      SELECT planx, count_actual_wh(HOUR(a.FIRST_TIME), HOUR(a.LAST_TIME), a.datex) awhox
      FROM (
        SELECT 
          CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) planx,
          a.OUT_PROD_DATE datex,
          MIN(a.OUT_PROD_TIME) FIRST_TIME,
          MAX(a.OUT_PROD_TIME) LAST_TIME,
          TIMESTAMPDIFF(MINUTE, MIN(a.OUT_PROD_TIME), MAX(a.OUT_PROD_TIME)) WH_ACT, 0 HC_ACT
        FROM output_prod_good a 
        WHERE IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D' AND a.OUT_PROD_TYPE ='O'
        AND CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) ='" . $plan_id ."'
        GROUP BY CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')), a.OUT_PROD_DATE
      ) a
    ) e ON a.planx = e.planx 
    LEFT JOIN toy_part f ON a.partx = f.PART_NUM
    LEFT JOIN line g ON a.linex = g.LINE_CODE
    LEFT JOIN (
      SELECT
        (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
        CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) idnx, a.PLAN_PROD_CONSLD csldnx
      FROM plan_prod_daily a 
      WHERE a.PLAN_PROD_FLAG = 'N' AND (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
        CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) = '" . $plan_id . "' 
    ) h on 1=1
    LEFT JOIN (
      SELECT
        (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
        CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) idox, a.PLAN_PROD_CONSLD csldox
      FROM plan_prod_daily a 
      WHERE a.PLAN_PROD_FLAG = 'O' AND (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
        CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) = '" . $plan_id . "' 
    ) i on 1=1
    LEFT JOIN output_prod_good_lead j ON a.planx = CONCAT(LEFT(j.PLAN_ID, 19), REPLACE(RIGHT(j.PLAN_ID, LENGTH(j.PLAN_ID) - 19), 'N',''))
    WHERE 1=1
    ORDER BY g.LINE_ORDR, a.groupx, a.partx;
    ";
    
    //var_dump($strSql);

  } else if ($section == 3) { //view prod hour
    $plan_id = $_GET["param_id"];
    $strSql = "
    SELECT CONVERT(a.hourx, SIGNED) inthourx, a.hourx, SUM(goodnx) goodnx, SUM(goodox) goodox, 
      SUM(def1) def1, SUM(def2) def2, SUM(def3) def3, 
      SUM(def4) def4, SUM(def5) def5, SUM(def6) def6, SUM(def7) def7, 
      SUM(rej1) rej1, SUM(rej2) rej2, SUM(rej3) rej3, CURDATE() date_svrx
    FROM (
      SELECT LEFT(a.OUT_PROD_TIME, 2) hourx, SUM(a.OUT_PROD_QTY) goodnx, 0 goodox,
        0 def1, 0 def2, 0 def3, 0 def4, 0 def5,
        0 def6, 0 def7, 0 rej1, 0 rej2, 0 rej3  
      FROM output_prod_good a 
      WHERE IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE = 'N' 
      AND CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) = '" . $plan_id . "'
      GROUP BY LEFT(a.OUT_PROD_TIME, 2) 
      UNION ALL
      SELECT LEFT(a.OUT_PROD_TIME, 2) hourx, 0 goodnx, SUM(a.OUT_PROD_QTY) goodox,
        0 def1, 0 def2, 0 def3, 0 def4, 0 def5,
        0 def6, 0 def7, 0 rej1, 0 rej2, 0 rej3  
      FROM output_prod_good a 
      WHERE IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE = 'O' 
      AND CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) = '" . $plan_id . "'
      GROUP BY LEFT(a.OUT_PROD_TIME, 2) 
      UNION ALL
      SELECT hourx, 0 goodnx, 0 goodox, 
      SUM(def1) def1, SUM(def2) def2, SUM(def3) def3, SUM(def4) def4, SUM(def5) def5, 
      SUM(def6) def6, SUM(def7) def7, SUM(def8) def8, SUM(def9) def9, SUM(def10) def10
      FROM (
        SELECT a.OUT_PLAN_ID planx, LEFT(a.OUT_DEF_TIME, 2) hourx, a.OUT_DEF_CODE defx, 
          CASE WHEN a.OUT_DEF_CODE = 1 THEN a.OUT_DEF_QTY ELSE 0 END def1,
          CASE WHEN a.OUT_DEF_CODE = 2 THEN a.OUT_DEF_QTY ELSE 0 END def2, 
          CASE WHEN a.OUT_DEF_CODE = 3 THEN a.OUT_DEF_QTY ELSE 0 END def3, 
          CASE WHEN a.OUT_DEF_CODE = 4 THEN a.OUT_DEF_QTY ELSE 0 END def4, 
          CASE WHEN a.OUT_DEF_CODE = 5 THEN a.OUT_DEF_QTY ELSE 0 END def5,
          CASE WHEN a.OUT_DEF_CODE = 6 THEN a.OUT_DEF_QTY ELSE 0 END def6,
          CASE WHEN a.OUT_DEF_CODE = 7 THEN a.OUT_DEF_QTY ELSE 0 END def7,
          CASE WHEN a.OUT_DEF_CODE = 8 THEN a.OUT_DEF_QTY ELSE 0 END def8,
          CASE WHEN a.OUT_DEF_CODE = 9 THEN a.OUT_DEF_QTY ELSE 0 END def9,
          CASE WHEN a.OUT_DEF_CODE = 10 THEN a.OUT_DEF_QTY ELSE 0 END def10  
        FROM output_prod_defect a 
        WHERE IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D'
        AND (CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) = '" . $plan_id . "'
        OR CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) = '" . $plan_id . "')
      ) a GROUP BY hourx 
      UNION ALL
      SELECT hourx, 0 goodnx, 0 goodox, 
        0 def1, 0 def2, 0 def3, 0 def4, 0 def5, 
        0 def6, 0 def7, SUM(rej1) rej1, SUM(rej2) rej2, SUM(rej3) rej3
      FROM (
        SELECT a.OUT_PLAN_ID planx, LEFT(a.OUT_REJ_TIME, 2) hourx, a.OUT_REJ_CODE rejx, 
          CASE WHEN a.OUT_REJ_CODE = 1 THEN a.OUT_REJ_QTY ELSE 0 END rej1,
          CASE WHEN a.OUT_REJ_CODE = 2 THEN a.OUT_REJ_QTY ELSE 0 END rej2, 
          CASE WHEN a.OUT_REJ_CODE = 3 THEN a.OUT_REJ_QTY ELSE 0 END rej3
        FROM output_prod_reject a 
        WHERE IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D'
        AND (CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) = '" . $plan_id . "'
        OR CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) = '" . $plan_id . "')
      ) a GROUP BY hourx
    ) a GROUP BY a.hourx;
    ";
    //var_dump($strSql);
  } else if ($section == 4) { // view transfer
    $param_id = $_GET["param_id"];
    $param_arr = explode("#", $param_id);

    $strSql = "
    SELECT IFNULL(SUM(a.PACK_BRCD_QTY), 0) tfx
    FROM pack_brcd a 
    INNER JOIN pack_scan_tf b ON a.PACK_BRCD_NUM = b.SCAN_ID
    WHERE a.PACK_BRCD_DATE = '". $param_arr[0] ."' 
    AND b.SCAN_DATE >= '". $param_arr[0] ."'  
    AND a.PACK_BRCD_LINE ='". $param_arr[1] ."'
    AND a.PACK_BRCD_PART = '". $param_arr[2] ."' 
    AND a.PACK_BRCD_GRP = '". $param_arr[3] ."';
    ";
  } else if ($section == 5) { // add defect
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $prod_id = $_GET["prod_id"];
    $def_hour = $_GET["def_hour"];
    $pref_hour = ':30:01';
    $def_hour = (strlen($def_hour) == 1 ? '0'.$def_hour.$pref_hour : $def_hour.$pref_hour);
    
    $strSql ="
    SELECT COUNT(*) REC_COUNT
    FROM output_prod_defect a
    WHERE a.OUT_PLAN_ID='". $prod_id ."' AND HOUR(a.OUT_DEF_TIME) =".$_GET["def_hour"]." 
    AND a.OUT_DEF_CODE = ".$_GET["def_code"].";
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    if ($rec_count <> 0){
      //update
      $strSql ="
      UPDATE output_prod_defect
      SET OUT_DEF_QTY = '".$_GET["def_qty"]."'
      WHERE OUT_PLAN_ID='". $prod_id ."' AND HOUR(OUT_DEF_TIME) =".$_GET["def_hour"]." 
      AND OUT_DEF_CODE = ".$_GET["def_code"].";
      ";

    } else {
      //insert
      $strSql = "
      INSERT INTO `output_prod_defect` (
        `OUT_PLAN_ID`, `OUT_DEF_DATE`, `OUT_DEF_PART`, 
        `OUT_DEF_CODE`, `OUT_DEF_QTY`, `OUT_DEF_ACT_HC`, 
        `OUT_DEF_CONSLD`, `OUT_DEF_TIME`, `OUT_DEF_TYPE`, 
        `OUT_DEF_UNIT`, `OUT_DEF_LINE_CODE`, `OUT_DEF_LINE_DESC`, 
        `OUT_DEF_LINE_SPV`, `OUT_DEF_ADD_ID`, `OUT_DEF_ADD_DATE`
      ) VALUES (
        '". $prod_id ."', '". $_GET["prod_date"] ."', '". $_GET["prod_part"] ."', 
        ". $_GET["def_code"] .", ". $_GET["def_qty"] .", ". $_GET["prod_hc"] .", 
        ". $_GET["prod_csld"] .", '". $def_hour . "', '". $_GET["prod_type"] ."', 
        '". $_GET["prod_unit"] ."', '". $_GET["prod_line"] ."', '". $_GET["prod_line_name"] ."', 
        '". $_GET["prod_line_lead"] ."', ". $useridx .", NOW()
        );
      ";
    }

    // action succes
    //echo $strSql;
    $action = '';
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    // action false
    } else {
      $action = 'FALSE';
    }

    $strSql = "
    SELECT '". $action ."' action_stat,
    '" . $_GET["prod_id"] . "' prod_id,
    '" . $_GET["prod_date"] . "' prod_date,
    '" . $_GET["prod_unit"] . "' prod_unit,
    '" . $_GET["prod_line"] . "' prod_line,
    '" . $_GET["prod_line_name"] . "' prod_line_name,
    '" . $_GET["prod_line_lead"] . "' prod_line_lead,
    '" . $_GET["prod_part"] . "' prod_part,
    '" . $_GET["prod_type"] . "' prod_type,
    '" . $_GET["prod_csld"] . "' prod_csld,
    '" . $_GET["prod_hc"] . "' prod_hc,
    '" . $_GET["def_hour"] . "' def_hour,
    '" . $_GET["def_code"] . "' def_code,
    '" . $_GET["def_qty"] . "' def_qty;
    ";
  } else if ($section == 6) { // add reject
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $prod_id = $_GET["prod_id"];
    $rej_hour = $_GET["rej_hour"];
    $pref_hour = ':30:01';
    $rej_hour = (strlen($rej_hour) == 1 ? '0'.$rej_hour.$pref_hour : $rej_hour.$pref_hour);
    
    $strSql ="
    SELECT COUNT(*) REC_COUNT
    FROM output_prod_reject a
    WHERE a.OUT_PLAN_ID='". $prod_id ."' AND HOUR(a.OUT_REJ_TIME) =".$_GET["rej_hour"]." 
    AND a.OUT_REJ_CODE = ".$_GET["rej_code"].";
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    if ($rec_count <> 0){
      //update
      $strSql ="
      UPDATE output_prod_reject
      SET OUT_REJ_QTY = '".$_GET["rej_qty"]."'
      WHERE OUT_PLAN_ID='". $prod_id ."' AND HOUR(OUT_REJ_TIME) =".$_GET["rej_hour"]." 
      AND OUT_REJ_CODE = ".$_GET["rej_code"].";
      ";

    } else {
      //insert
      $strSql = "
      INSERT INTO `output_prod_reject` (
        `OUT_PLAN_ID`, `OUT_REJ_DATE`, `OUT_REJ_PART`, 
        `OUT_REJ_CODE`, `OUT_REJ_QTY`, `OUT_REJ_ACT_HC`, 
        `OUT_REJ_CONSLD`, `OUT_REJ_TIME`, `OUT_REJ_TYPE`, 
        `OUT_REJ_UNIT`, `OUT_REJ_LINE_CODE`, `OUT_REJ_LINE_DESC`, 
        `OUT_REJ_LINE_SPV`, `OUT_REJ_ADD_ID`, `OUT_REJ_ADD_DATE`
      ) VALUES (
        '". $prod_id ."', '". $_GET["prod_date"] ."', '". $_GET["prod_part"] ."', 
        ". $_GET["rej_code"] .", ". $_GET["rej_qty"] .", ". $_GET["prod_hc"] .", 
        ". $_GET["prod_csld"] .", '". $rej_hour . "', '". $_GET["prod_type"] ."', 
        '". $_GET["prod_unit"] ."', '". $_GET["prod_line"] ."', '". $_GET["prod_line_name"] ."', 
        '". $_GET["prod_line_lead"] ."', ". $useridx .", NOW()
        );
      ";
    }

    // action succes
    //echo $strSql;
    $action = '';
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    // action false
    } else {
      $action = 'FALSE';
    }

    $strSql = "
    SELECT '". $action ."' action_stat,
    '" . $_GET["prod_id"] . "' prod_id,
    '" . $_GET["prod_date"] . "' prod_date,
    '" . $_GET["prod_unit"] . "' prod_unit,
    '" . $_GET["prod_line"] . "' prod_line,
    '" . $_GET["prod_line_name"] . "' prod_line_name,
    '" . $_GET["prod_line_lead"] . "' prod_line_lead,
    '" . $_GET["prod_part"] . "' prod_part,
    '" . $_GET["prod_type"] . "' prod_type,
    '" . $_GET["prod_csld"] . "' prod_csld,
    '" . $_GET["prod_hc"] . "' prod_hc,
    '" . $_GET["rej_hour"] . "' rej_hour,
    '" . $_GET["rej_code"] . "' rej_code,
    '" . $_GET["rej_qty"] . "' rej_qty;
    ";
  } else if ($section == 7) { // add good
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $prod_id = $_GET["prod_id"];
    $prod_hour = $_GET["prod_hour"];
    $prod_qty = $_GET["prod_qty"];
    $prod_type = $_GET["prod_type"];
    $prod_group = $_GET["prod_group"];
    $pref_hour = ':30:01';

    // set hour
    $prod_hour = (strlen($prod_hour) == 1 ? '0'.$prod_hour.$pref_hour : $prod_hour.$pref_hour);
    
    $strSql ="
    SELECT COUNT(*) REC_COUNT
    FROM output_prod_good a
    WHERE a.OUT_PLAN_ID='". $prod_id ."' AND HOUR(a.OUT_PROD_TIME) =".$_GET["prod_hour"]. ";
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    if ($rec_count <> 0){
      //update
      if ($prod_qty == '') {
        $strSql ="
        DELETE FROM output_prod_good
        WHERE OUT_PLAN_ID='". $prod_id ."' AND HOUR(OUT_PROD_TIME) =".$_GET["prod_hour"].";
        ";
      } else {
        $strSql ="
        UPDATE output_prod_good
        SET OUT_PROD_QTY = '".$prod_qty."', OUT_PROD_MOD_ID = '". $useridx ."', OUT_PROD_MOD_DATE = NOW()
        WHERE OUT_PLAN_ID='". $prod_id ."' AND HOUR(OUT_PROD_TIME) =".$_GET["prod_hour"].";
        ";
      }
    } else {
      //insert
      if ($prod_qty != '') {
        $strSql = "
        INSERT INTO `output_prod_good` (
          `OUT_PLAN_ID`, `OUT_PROD_DATE`, `OUT_PROD_PART`, 
          `OUT_PROD_TIME`, `OUT_PROD_QTY`, `OUT_PROD_ACT_HC`, 
          `OUT_PROD_CONSLD`, `OUT_PROD_TYPE`, `OUT_PROD_FLAG_DEL`, 
          `OUT_PROD_UNIT`, `OUT_PROD_LINE_CODE`, `OUT_PROD_LINE_DESC`, 
          `OUT_PORD_LINE_SPV`, `OUT_PROD_GROUP`, `OUT_PROD_ADD_ID`, `OUT_PROD_ADD_DATE`
        ) VALUES (
          '". $prod_id ."', '". $_GET["prod_date"] ."', '". $_GET["prod_part"] ."', 
          '". $prod_hour . "', '". $prod_qty ."', ". $_GET["prod_hc"] .", 
          ". $_GET["prod_csld"] .", '". $prod_type ."', NULL, 
          '". $_GET["prod_unit"] ."', '". $_GET["prod_line"] ."', '". $_GET["prod_line_name"] ."', 
          '". $_GET["prod_line_lead"] ."','". $prod_group ."', ". $useridx .", NOW()
          );
        ";
      } else {
        $strSql = "SELECT 'TRUE' resx;";
      }
    }

    // action succes
    //echo $strSql;
    $action = '';
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    // action false
    } else {
      $action = 'FALSE';
    }

    $strSql = "
    SELECT '". $action ."' action_stat,
    '" . $_GET["prod_id"] . "' prod_id,
    '" . $_GET["prod_date"] . "' prod_date,
    '" . $_GET["prod_unit"] . "' prod_unit,
    '" . $_GET["prod_line"] . "' prod_line,
    '" . $_GET["prod_line_name"] . "' prod_line_name,
    '" . $_GET["prod_line_lead"] . "' prod_line_lead,
    '" . $_GET["prod_part"] . "' prod_part,
    '" . $_GET["prod_type"] . "' prod_type,
    '" . $_GET["prod_csld"] . "' prod_csld,
    '" . $_GET["prod_hc"] . "' prod_hc,
    '" . $_GET["prod_hour"] . "' prod_hour,
    '" . $_GET["prod_qty"] . "' prod_qty;
    ";
  } else if ($section == 8) { // add actual hc
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $prod_id = $_GET["prod_id"];
    $prod_type = $_GET["prod_type"];
    $prod_ahc = $_GET["prod_ahc"];

    $strSql ="
    SELECT COUNT(*) REC_COUNT
    FROM output_prod_good_hc a
    WHERE a.PLAN_ID='". $prod_id ."';
    ";
	
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    if ($rec_count <> 0){
      //update
      $strSql ="
      UPDATE output_prod_good_hc
      SET OUT_PROD_GOOD_AHC = '".$prod_ahc."'
      WHERE PLAN_ID='". $prod_id ."';
      ";

    } else {
      //insert
      $strSql = "
      INSERT INTO `output_prod_good_hc` (
        `PLAN_ID`, `OUT_PROD_GOOD_AHC`, `OUT_PROD_GOOD_COUNT_DEL`
      ) VALUES (
        '". $prod_id ."', '". $prod_ahc ."', 0 
      );
      ";
    }

    // action succes
    //echo $strSql;
    $action = '';
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    // action false
    } else {
      $action = 'FALSE';
    }

    $strSql = "
    SELECT '". $action ."' action_stat,
    '" . $prod_id . "' prod_id,
    '" . $prod_type . "' prod_type,
    '" . $prod_ahc . "' prod_ahc;
    ";

  } else if ($section == 10) { // view lbo acc
    $prod_id = $_GET["param_id"];
    $date_ppm = substr($_GET["param_id"], 0, 4).'-'.substr($_GET["param_id"], 4, 2).'-'.substr($_GET["param_id"], 6, 2);
    $strSql = "
    SELECT a.ssx, b.defcodex, c.DEFECT_CAT defcatx, UCASE(c.DEFECT_NAME) defnamex, b.defqtyx, b.procidx, UCASE(IFNULL(d.CBSD_PROC_DESC, '')) procdesx, e.tppmx 
    FROM (
      SELECT a.QC_LBO_PART partx, SUM(a.QC_LBO_SS) ssx
      FROM qc_lbo_input a 
      WHERE (CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N','')) = '" . $plan_id . "'
      OR CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O','')) = '" . $plan_id . "')
      GROUP BY a.QC_LBO_PART
    ) a LEFT JOIN (
      SELECT a.LBO_DEFECT_CODE defcodex, a.LBO_PROCESS_ID procidx, COUNT(a.LBO_DEFECT_CODE) defqtyx 
      FROM qc_lbo_input_detail a 
      LEFT JOIN qc_lbo_input b ON a.QC_LBO_ID = b.QC_LBO_ID
      WHERE a.LBO_CATEGORY = 'DEFECT' 
      AND (CONCAT(LEFT(b.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(b.QC_LBO_PLAN_ID, LENGTH(b.QC_LBO_PLAN_ID) - 19), 'N','')) = '" . $plan_id . "'
      OR CONCAT(LEFT(b.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(b.QC_LBO_PLAN_ID, LENGTH(b.QC_LBO_PLAN_ID) - 19), 'O','')) = '" . $plan_id . "')
      GROUP BY a.LBO_DEFECT_CODE, a.LBO_PROCESS_ID
    ) b ON 1=1
    LEFT JOIN defect_lbo c ON b.defcodex = c.DEFECT_CODE
    LEFT JOIN toy_part_cbsd d ON a.partx = d.CBSD_PART_NUM AND b.procidx = d.CBSD_ID
    LEFT JOIN (
      SELECT ((a.qc_lbo_target_ppm/1000000) * 100) tppmx 
      FROM qc_lbo_target_list a WHERE '".$date_ppm."' BETWEEN a.qc_lbo_target_start_date AND a.qc_lbo_target_end_date  
    ) e ON 1=1
    ";

  } else if ($section == 11) { // view issue
    $prod_id = $_GET["prod_id"];
    $prod_hour = $_GET["prod_hour"];
    $prod_part = $_GET["prod_part"];

    $strSql = "
    SELECT * FROM (
    SELECT 
      a.prod_issue_id idx, 0 seqx, 0 prc_idx, a.prod_issue_cat catx,  a.prod_issue_cat_desc catdx, 
      a.prod_issue_desc descx, 0 fchx, 
      0 ftx, 0 tppx,
      CASE WHEN IFNULL(b.plan_id,'') = '' THEN 0 ELSE 1 END AS chkx, 0 cntx, '' optx, 
      a.prod_issue_order ordx 
    FROM xref_prod_issue a 
    LEFT JOIN output_prod_issue b ON a.prod_issue_id = b.issue_id 
      AND b.plan_id = '". $prod_id."' AND b.issue_hour = $prod_hour
    WHERE a.prod_issue_cat <> 'PROCESS' and prod_issue_expire <> 'Y'
    UNION ALL
    SELECT 
      18 idx, ifnull(b.issue_proc_seq, 0) seqx,  a.CBSD_ID prc_idx, 'PROCESS' catx, 'Proses issue' catdx, 
      a.CBSD_PROC_DESC descx, a.CBSD_PROC_FCH fchx, 
      a.CBSD_PROC_FCH_TARGET ftx, a.CBSD_PROC_CT_FCH tppx,
      0 chkx, ifnull(b.issue_proc_cnt, '') cntx, ifnull(b.issue_proc_opt, '') optx,
      18 ordx
    FROM toy_part_cbsd a 
    INNER JOIN output_prod_issue b ON b.issue_id = 18
    AND b.plan_id = '". $prod_id."' 
    AND b.issue_hour = $prod_hour AND b.issue_proc_id = a.CBSD_ID
    WHERE a.CBSD_PART_NUM = '".$prod_part."'
    UNION ALL
    SELECT 
      99 idx, 0 seqx, a.CBSD_ID prc_idx, 'PROCESS' catx, 'Proses issue' catdx, 
      a.CBSD_PROC_DESC descx, a.CBSD_PROC_FCH fchx, 
      a.CBSD_PROC_FCH_TARGET ftx, a.CBSD_PROC_CT_FCH tppx,
      0 chkx, 0 cntx, '' optx,
      99 ordx
    FROM toy_part_cbsd a 
    WHERE a.CBSD_PART_NUM = '".$prod_part."'
    ) a ORDER BY ordx, seqx";
  } else if ($section == 12) { // dell issue
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $prod_id = $_GET["prod_id"];
    $prod_hour = $_GET["prod_hour"];
    $prod_date = $_GET["prod_date"];
    $prod_line = $_GET["prod_line"];
    $prod_group = $_GET["prod_group"];
    $prod_part = $_GET["prod_part"];
    $int_hour = (int)$prod_hour;
    $int_hour = $int_hour - 1;
    $hour_format = "c".($int_hour)."_". $prod_hour;

    //echo $hour_format;

    //count note data
    $strSql = "SELECT COUNT(*) REC_COUNT FROM output_prod_hour_note WHERE linex='".$prod_line."' AND datex='".$prod_date."' AND groupx='".$prod_group."' AND partx='".$prod_part."';";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    //if not exsist add
    if ($rec_count == 0){
      //add hour
      $strSql = "
      INSERT INTO `output_prod_hour_note` (`linex`, `datex`, `groupx`, `partx`) VALUES (
        '".$prod_line."', '".$prod_date."', '".$prod_group."', '".$prod_part."'
      );
      ";
    } else {
      //empty hour
      $strSql = "
      UPDATE `output_prod_hour_note` 
      SET `".$hour_format."`= NULL 
      WHERE `linex`='".$prod_line."' AND `datex`='".$prod_date."' AND `groupx`='".$prod_group."' AND `partx`='".$prod_part."';
      ";
    }
    //echo $strSql;
    //execute
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }
    
    //delete new format data
    $strSql ="
    DELETE
    FROM output_prod_issue
    WHERE plan_id='". $prod_id ."' AND issue_hour =".$prod_hour. ";
    ";

    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    // action false
    } else {
      $action = 'FALSE';
    }

    $strSql = "
    SELECT '". $action ."';
    ";

  } else if ($section == 13) { // add issue
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $prod_id = $_GET["prod_id"];
    $prod_hour = $_GET["prod_hour"];
    $prod_issue_id = $_GET["prod_issue_id"];
    $prod_issue_desc = $_GET["prod_issue_desc"];
    $prod_seq = $_GET["prod_seq"] == '' ? 'NULL' : $_GET["prod_seq"];
    $prod_proc_id = $_GET["prod_proc_id"] == '' ? 'NULL' : $_GET["prod_proc_id"];
    $prod_proc_des = $_GET["prod_proc_des"] == '' ? 'NULL' : "'".$_GET["prod_proc_des"]."'";
    $prod_proc_val = $_GET["prod_proc_val"] == '' ? 'NULL' : "'".$_GET["prod_proc_val"]."'";
    $prod_proc_opt = $_GET["prod_proc_opt"] == '' ? 'NULL' : "'".$_GET["prod_proc_opt"]."'";
    $pref_hour = ':30:01';

    //for old table
    $prod_date = $_GET["prod_date"];
    $prod_line = $_GET["prod_line"];
    $prod_group = $_GET["prod_group"];
    $prod_part = $_GET["prod_part"];
    $int_hour = (int)$prod_hour;
    $int_hour = $int_hour - 1;
    $hour_format = "c".($int_hour)."_". $prod_hour;

    $strSql = "
      UPDATE `output_prod_hour_note` 
      SET `".$hour_format."`=CONCAT(IFNULL(`".$hour_format."`,''),'".$prod_issue_desc.";') 
      WHERE `linex`='".$prod_line."' AND `datex`='".$prod_date."' AND `groupx`='".$prod_group."' AND `partx`='".$prod_part."';
    ";
    //echo $strSql;
    $action = '';
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    // action false
    } else {
      $action = 'FALSE';
    }
  
    //insert new data
    $strSql = "
      INSERT INTO `output_prod_issue` (
        `plan_id`, `issue_date`, `issue_hour`, `issue_id`, 
        `issue_proc_seq`, `issue_proc_id`, `issue_proc_desc`, 
        `issue_proc_cnt`, `issue_proc_opt`, 
        `issue_add_date`, `issue_add_id`) 
      VALUES (
        '".$prod_id."', '".$prod_date."', ".$prod_hour.", ".$prod_issue_id.", 
        ".$prod_seq.", ".$prod_proc_id.", ".$prod_proc_des.", 
        ".$prod_proc_val.", ".$prod_proc_opt.",
        NOW(), ". $useridx .");
    ";
    //echo '<pre>'. $strSql . '</pre>';

    $action = '';
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    // action false
    } else {
      $action = 'FALSE';
    }

    $strSql = "
    SELECT '". $action ."';
    ";
  } else if ($section == 14) { // view hourly
    
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $style = $_GET["style"];
    $group = $_GET["group"];

    $strSql = "
    SELECT datex, HOUR(timex_min) firsth, HOUR(timex_max) lasth, (HOUR(timex_max) - HOUR(timex_min)) + 1 sequenh
    FROM (
      SELECT sx.datex, MIN(timex) timex_min, MAX(timex) timex_max
      FROM (
        SELECT a.OUT_PROD_DATE datex, a.OUT_PROD_TIME timex
        FROM output_prod_good a 
        WHERE IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_DATE = '".$date."' UNION ALL
        SELECT '".$date."' datex, '08:00:01' timex UNION ALL
        SELECT '".$date."' datex, '09:00:01' timex UNION ALL
        SELECT '".$date."' datex, '10:00:01' timex UNION ALL
        SELECT '".$date."' datex, '11:00:01' timex UNION ALL
        SELECT '".$date."' datex, '12:00:01' timex
      ) sx
      GROUP BY sx.datex
    ) sx order by sx.datex;
    ";

    //echo $strSql;
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    //$prod_id = $row['plan_id'];

    // CASE WHEN sz.datex = '2024-06-25' AND sz.timex = 14 then lotx END `2024_06_25_14`,

    $str_sum = "SELECT sz.plan_id";
    $str_col = "SELECT sz.plan_id";

    $str_sum_issue = "SELECT sz.plan_id";
    $str_col_issue = "SELECT sz.plan_id";  

    $str_sum_issue_desc = "SELECT sz.plan_id";
    $str_col_issue_desc = "SELECT sz.plan_id";  

    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        for($x = $row['firsth']; $x <= $row['lasth']; $x++){
          //qty
          $str_sum = $str_sum . ", SUM(`D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`) `D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          $str_col = $str_col . ", CASE WHEN sz.datex='" . $row['datex'] . "' AND sz.timex=" . $x ." THEN sz.qtyx END `D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          
          //issue
          $str_sum_issue = $str_sum_issue . ", SUM(`I_" . str_replace("-","_", $row['datex']) . "_" . $x ."`) `I_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          $str_col_issue = $str_col_issue . ", CASE WHEN sz.datex='" . $row['datex'] . "' AND sz.timex=" . $x ." THEN sz.qtyx END `I_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          
          //issue desc
          $str_sum_issue_desc = $str_sum_issue_desc . ", GROUP_CONCAT(`E_" . str_replace("-","_", $row['datex']) . "_" . $x ."`) `E_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          $str_col_issue_desc = $str_col_issue_desc . ", CASE WHEN sz.datex='" . $row['datex'] . "' AND sz.timex=" . $x ." THEN sz.issuex END `E_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          
        }
      }
    }
    //qty
    $str_col = $str_col . " FROM (";
    $str_col = $str_col ."
    SELECT sx.plan_id, sx.datex, sx.timex, SUM(qtyx) qtyx
    FROM (
      SELECT 
        CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) plan_id, 
        a.OUT_PROD_DATE datex, HOUR(a.OUT_PROD_TIME) timex, 
        a.OUT_PROD_QTY qtyx
      FROM output_prod_good a WHERE 
      IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE='N'
      AND a.OUT_PROD_DATE = '".$date."' UNION ALL
      SELECT 
        CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) plan_id, 
        a.OUT_PROD_DATE datex, HOUR(a.OUT_PROD_TIME) timex, 
        a.OUT_PROD_QTY qtyx
      FROM output_prod_good a WHERE 
      IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE='O'
      AND a.OUT_PROD_DATE = '".$date."'
    ) sx GROUP BY sx.plan_id, sx.datex, sx.timex
    ";
    $str_col = $str_col . " ) sz";
    $str_col = $str_sum . ' FROM (' . $str_col . ') sz GROUP BY sz.plan_id';

    //issue
    $str_col_issue = $str_col_issue . " FROM (";
    $str_col_issue = $str_col_issue ."
    SELECT sx.plan_id, sx.datex, sx.timex, SUM(qtyx) qtyx
    FROM (
      SELECT 
        a.plan_id, 
        a.issue_date datex, issue_hour timex, 
        1 qtyx
      FROM output_prod_issue a WHERE a.issue_date = '".$date."'
    ) sx GROUP BY sx.plan_id, sx.datex, sx.timex
    ";
    $str_col_issue = $str_col_issue . " ) sz";
    $str_col_issue = $str_sum_issue . ' FROM (' . $str_col_issue . ') sz GROUP BY sz.plan_id';

    //issue desc
    $str_col_issue_desc = $str_col_issue_desc . " FROM (";
    $str_col_issue_desc = $str_col_issue_desc ."
      SELECT plan_id, datex, timex, GROUP_CONCAT(issuex SEPARATOR '<br />') issuex  
      FROM (
        SELECT a.plan_id, a.issue_date datex, a.issue_hour timex, GROUP_CONCAT(UCASE(b.prod_issue_desc)  SEPARATOR '<br />') issuex
        FROM output_prod_issue a
        LEFT JOIN xref_prod_issue b ON a.issue_id = b.prod_issue_id
        WHERE a.issue_date = '".$date."' AND b.prod_issue_cat <> 'PROCESS'
        GROUP BY a.plan_id, a.issue_date, a.issue_hour UNION ALL
        SELECT a.plan_id, a.issue_date datex, a.issue_hour timex, GROUP_CONCAT(UCASE(a.issue_proc_desc)  SEPARATOR '<br />') issuex
        FROM output_prod_issue a
        LEFT JOIN xref_prod_issue b ON a.issue_id = b.prod_issue_id
        WHERE a.issue_date = '".$date."' AND b.prod_issue_cat = 'PROCESS'
        GROUP BY a.plan_id, a.issue_date, a.issue_hour
      ) a GROUP BY plan_id, datex, timex
    ";
    $str_col_issue_desc = $str_col_issue_desc . " ) sz";
    $str_col_issue_desc = $str_sum_issue_desc . ' FROM (' . $str_col_issue_desc . ') sz GROUP BY sz.plan_id';

    //last query
    $strSql = "
    SELECT c.LINE_PREF unitx, a.linex, c.LINE_DESC line_namex, c.LINE_NAME_SPV spvx, 
      a.groupx, a.partx, d.PART_NAME part_namex, 
      d.PART_TYPE part_typex, a.plan_id group_id, a.planx, IFNULL(b.actual, 0) actualx, a.fchx, a.rdx, a.hcx, a.plan_whx, IFNULL(f.ftix,'') ftix, 
      g.*, e.*, h.*
    FROM (
      SELECT (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) plan_id, 
      a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_PART partx, a.PLAN_PROD_FCH fchx,
      a.PLAN_PROD_RD rdx, a.PLAN_PROD_OPT hcx, 
      SUM(a.PLAN_PROD_QTY) planx, SUM(a.PLAN_PROD_WH) plan_whx
      FROM plan_prod_daily a WHERE a.PLAN_PROD_DATE = '" . $date . "'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
      GROUP BY (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')),
      a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_GROUP_ORD, a.PLAN_PROD_PART, a.PLAN_PROD_FCH
    ) a LEFT JOIN (
      SELECT plan_id, SUM(prodx) actual
      FROM (
        SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) plan_id, a.OUT_PROD_QTY prodx
        FROM output_prod_good a WHERE 
        IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE='N'
        AND a.OUT_PROD_DATE = '" . $date . "' UNION ALL
        SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) plan_id, a.OUT_PROD_QTY prodx
        FROM output_prod_good a WHERE 
        IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE='O'
        AND a.OUT_PROD_DATE = '" . $date . "'
      ) sa GROUP BY sa.plan_id
    ) b ON a.plan_id = b.plan_id
    LEFT JOIN line c ON a.linex = c.LINE_CODE
    LEFT JOIN toy_part d ON a.partx = d.PART_NUM
    LEFT JOIN (
    ". $str_col ."
    ) e on e.plan_id = a.plan_id
    LEFT JOIN (
      SELECT plan_id, MIN(ftix) ftix
      FROM (
        SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) plan_id, a.OUT_PROD_TIME ftix
        FROM output_prod_good a WHERE 
        IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE='N'
        AND a.OUT_PROD_DATE = '" . $date . "' UNION ALL
        SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) plan_id, a.OUT_PROD_TIME ftix
        FROM output_prod_good a WHERE 
        IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE='O'
        AND a.OUT_PROD_DATE = '" . $date . "'
      ) sa GROUP BY sa.plan_id
    ) f on f.plan_id = a.plan_id
    LEFT JOIN (
    ". $str_col_issue ."
    ) g on g.plan_id = a.plan_id
    LEFT JOIN (
    ". $str_col_issue_desc ."
    ) h on h.plan_id = a.plan_id
    WHERE 1=1 " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND a.linex ='$line' " : "") . "
    " . (($line_all !="") ? " AND a.linex IN (" . $line_all . ")" : "") . "
    " . (($group !="" && $group != "ALL") ? " AND a.groupx ='$group' " : "") . "
    " . (($style !="" && $style != "ALL") ? " AND (UCASE(a.partx) LIKE '%".strtoupper($style)."%' OR UCASE(d.PART_NAME) LIKE '%".strtoupper($style)."%')" : "") . "
    ORDER BY c.LINE_PREF, c.LINE_ORDR, a.groupx, a.partx;
    ";
      
  } else if ($section == 15) { // view daily summary
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $style = $_GET["style"];
    $group = $_GET["group"];

    $strSql = "
      SELECT 
      (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR), CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) plan_idx, 
      a.PLAN_PROD_LINE_CODE linex,
      c.LINE_PREF unitx,
      c.LINE_NAME_SPV leadx,
      c.LINE_DESC line_descx,
      a.PLAN_PROD_GROUP groupidx,
      a.PLAN_PROD_GROUP_ORD groupx,
      a.PLAN_PROD_PART partx,
      d.PART_NAME part_descx,
      a.PLAN_PROD_FCH fchx,
      a.PLAN_PROD_EFF effx,
      a.PLAN_PROD_RD rdx,
      a.PLAN_PROD_FLAG flagx,
      a.PLAN_PROD_OPT phcx,
      a.PLAN_PROD_WH pwhx,
      a.PLAN_PROD_QTY pqtyx,
      (a.PLAN_PROD_FCH * a.PLAN_PROD_QTY)/1000 pehx,
      1 pparx,
      IF(IFNULL(b.aqtyx, 0 ) >= a.PLAN_PROD_QTY,1,0) aparx,
      IFNULL(b.ahcx ,'') ahcx,
      IFNULL(b.awhx, 0) awhx,
      IFNULL(b.aqtyx,0) aqtyx,
      (a.PLAN_PROD_FCH * IFNULL(b.aqtyx,0))/1000 aehx,
      IFNULL(b.aqtyx,0) - IFNULL(a.PLAN_PROD_QTY, 0) varx,
      IFNULL(b.ltix, '00:00:00') ltix
    FROM plan_prod_daily a 
    LEFT JOIN (
      SELECT a.plan_idx, SUM(aqtyx) aqtyx, SUM(ahcx) ahcx, SUM(awhx) awhx, max(ltix) ltix
      FROM (
        SELECT a.OUT_PLAN_ID plan_idx, SUM(a.OUT_PROD_QTY) aqtyx, 0 ahcx, 0 awhx, MAX(OUT_PROD_TIME) ltix
        FROM output_prod_good a 
        WHERE IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_DATE = '$date'
        GROUP BY a.OUT_PLAN_ID UNION ALL
        SELECT a.PLAN_ID plan_idx, 0, a.OUT_PROD_GOOD_AHC ahcx, 0, '00:00:00'
        FROM output_prod_good_hc a 
        WHERE LEFT(a.PLAN_ID, 8) = '". str_replace('-', '', $date)."' UNION ALL
        
        SELECT a.OUT_PLAN_ID plan_idx, 0 aqtyx, 0 ahcx, SUM(WH_ACT) awhx, '00:00:00'
        FROM (
          SELECT a.OUT_PLAN_ID,
          count_actual_wh(HOUR(a.FIRST_TIME), HOUR(a.LAST_TIME), a.OUT_PROD_DATE) WH_ACT
          FROM (
            SELECT 
              a.OUT_PLAN_ID,
              a.OUT_PROD_DATE,
              MIN(a.OUT_PROD_TIME) FIRST_TIME,
              MAX(a.OUT_PROD_TIME) LAST_TIME,
              TIMESTAMPDIFF(MINUTE, MIN(a.OUT_PROD_TIME), MAX(a.OUT_PROD_TIME)) WH_ACT, 0 HC_ACT
            FROM output_prod_good a 
            WHERE a.OUT_PROD_DATE = '$date'
            AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
            GROUP BY a.OUT_PLAN_ID, a.OUT_PROD_DATE
          ) a
        ) a GROUP BY a.OUT_PLAN_ID
    
      ) a GROUP BY a.plan_idx	
    ) b ON (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR), CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) = b.plan_idx
    LEFT JOIN line c ON a.PLAN_PROD_LINE_CODE = c.LINE_CODE
    LEFT JOIN toy_part d ON a.PLAN_PROD_PART = d.PART_NUM
    WHERE a.PLAN_PROD_DATE ='$date' "
    .($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE").""
    .(($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND c.LINE_CODE ='$line' " : "").""
    .(($line_all !="") ? " AND c.LINE_CODE IN (" . $line_all . ")" : "") . ""
    .(($style !="" && $style != "ALL") ? " AND UCASE(a.PLAN_PROD_PART) = '$style'" : "").""
    .(($group !="" && $group != "ALL") ? " AND UCASE(a.PLAN_PROD_GROUP_ORD) = '$group'" : "")."
    ORDER BY c.LINE_PREF, c.LINE_ORDR, a.PLAN_PROD_GROUP_ORD, a.PLAN_PROD_ORDR
    ";
  } else if ($section == 16) { // view daily transfer
  
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $style = $_GET["style"];
    $group = $_GET["group"];

    $strSql = "
    SELECT datex, HOUR(timex_min) firsth, HOUR(timex_max) lasth, (HOUR(timex_max) - HOUR(timex_min)) + 1 sequenh
    FROM (
      SELECT sx.datex, MIN(timex) timex_min, MAX(timex) timex_max
      FROM (
        SELECT b.SCAN_DATE datex, b.SCAN_TIME timex 
        FROM pack_brcd a 
        INNER JOIN pack_scan_tf b ON a.PACK_BRCD_NUM = b.SCAN_ID
        WHERE a.PACK_BRCD_DATE ='".$date."' AND b.SCAN_DATE BETWEEN '".$date."' AND DATE_ADD('".$date."', INTERVAL 14 DAY)
      ) sx
      GROUP BY sx.datex
    ) sx order by sx.datex;
    ";

    //echo $strSql;
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);

    // CASE WHEN sz.datex = '2024-06-25' AND sz.timex = 14 then lotx END `2024_06_25_14`,

    $str_sum = "SELECT sz.plan_id, SUM(sz.tfx) tfx";
    $str_col = "SELECT sz.plan_id, sz.qtyx tfx";

    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        for($x = $row['firsth']; $x <= $row['lasth']; $x++){
          //qty
          $str_sum = $str_sum . ", SUM(`D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`) `D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          $str_col = $str_col . ", CASE WHEN sz.datex='" . $row['datex'] . "' AND sz.timex=" . $x ." THEN sz.qtyx END `D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
        }
      }
    }
    //qty
    $str_col = $str_col . " FROM (";
    $str_col = $str_col ."
    SELECT sx.plan_id, sx.datex, sx.timex, SUM(qtyx) qtyx
    FROM (
      SELECT
      REPLACE(CONCAT(a.PACK_BRCD_DATE,a.PACK_BRCD_LINE,a.PACK_BRCD_PART,a.PACK_BRCD_GRP),'-','') plan_id, 
      b.SCAN_DATE datex, HOUR(b.SCAN_TIME) timex, a.PACK_BRCD_QTY qtyx
      FROM pack_brcd a 
      INNER JOIN pack_scan_tf b ON a.PACK_BRCD_NUM = b.SCAN_ID
      WHERE a.PACK_BRCD_DATE ='".$date."' AND b.SCAN_DATE BETWEEN '".$date."' AND DATE_ADD('".$date."', INTERVAL 14 DAY)
    ) sx GROUP BY sx.plan_id, sx.datex, sx.timex
    ";
    $str_col = $str_col . " ) sz";
    $str_col = $str_sum . ' FROM (' . $str_col . ') sz GROUP BY sz.plan_id';

    //last query
    $strSql = "
    SELECT c.LINE_PREF unitx, a.linex, c.LINE_DESC line_namex, c.LINE_NAME_SPV spvx, 
      a.groupx, a.partx, d.PART_NAME part_namex, 
      d.PART_TYPE part_typex, a.plan_id group_id, a.planx, IFNULL(b.actual, 0) actualx, a.fchx, a.plan_whx,
      e.*
    FROM (
      SELECT (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) plan_id, 
      a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_PART partx, a.PLAN_PROD_FCH fchx, 
      SUM(a.PLAN_PROD_QTY) planx, SUM(a.PLAN_PROD_WH) plan_whx
      FROM plan_prod_daily a WHERE a.PLAN_PROD_DATE = '" . $date . "'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
      GROUP BY (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')),
      a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_GROUP_ORD, a.PLAN_PROD_PART, a.PLAN_PROD_FCH
    ) a LEFT JOIN (
      SELECT plan_id, SUM(prodx) actual
      FROM (
        SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) plan_id, a.OUT_PROD_QTY prodx
        FROM output_prod_good a WHERE 
        IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE='N'
        AND a.OUT_PROD_DATE = '" . $date . "' UNION ALL       
        SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) plan_id, a.OUT_PROD_QTY prodx
        FROM output_prod_good a WHERE 
        IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D' AND a.OUT_PROD_TYPE='O'
        AND a.OUT_PROD_DATE = '" . $date . "'
      ) sa GROUP BY sa.plan_id
    ) b ON a.plan_id = b.plan_id
    LEFT JOIN line c ON a.linex = c.LINE_CODE
    LEFT JOIN toy_part d ON a.partx = d.PART_NUM
    LEFT JOIN (
    ". $str_col ."
    ) e on e.plan_id = REPLACE(CONCAT('" . $date . "',a.linex,a.partx,a.groupx),'-','')
    WHERE 1=1 " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND a.linex ='$line' " : "") . "
    " . (($line_all !="") ? " AND a.linex IN (" . $line_all . ")" : "") . "
    " . (($group !="" && $group != "ALL") ? " AND a.groupx ='$group' " : "") . "
    " . (($style !="" && $style != "ALL") ? " AND (UCASE(a.partx) LIKE '%".strtoupper($style)."%' OR UCASE(d.PART_NAME) LIKE '%".strtoupper($style)."%')" : "") . "
    ORDER BY c.LINE_PREF, c.LINE_ORDR, a.groupx, a.partx;
    ";
      
  } else if ($section == 17) { // view wip summary
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $style = $_GET["style"];
    $group = $_GET["group"];
    $balance = $_GET["balance"];
    
    $strBln = '';
    if ($balance == 'N'){
      $strBln = "AND (qty_ld - (qty_tf + qty_retg + qty_retr)) <> 0";
    } else {
      $strBln = "";
    }
    
    $start_date = '2023-10-16';
    $strSql = "
    SELECT
      sb.LINE_PREF unitx, 
      sa.line_code linex, 
      sb.LINE_DESC line_descx, 
      sb.LINE_NAME_SPV leadx, 
      part partx, 
      sc.PART_NAME part_descx, 
      groupx, qty_ld loadx, qty_tf trfx, 
      (qty_retg + qty_retr) retx, 
      qty_ld - (qty_tf + qty_retg + qty_retr) blx, IFNULL(date_max, '') date_max, IFNULL(se.PART_NUM, '') eotx 
    FROM (
      SELECT line_code, part, groupx, SUM(qty_ld) qty_ld, SUM(qty_tf) qty_tf, SUM(qty_retg) qty_retg, SUM(qty_retr) qty_retr
      FROM (
          SELECT
              a.out_plan_line_code line_code, a.out_plan_part part, a.out_plan_group groupx,
              SUM(a.out_plan_qty_ic) + SUM(a.out_plan_qty_adm) qty_ld, 0 qty_tf, 0 qty_retg, 0 qty_retr
          FROM material_ot_by_group a
          WHERE a.out_plan_date BETWEEN '$start_date' AND '$date'
          GROUP BY a.out_plan_line_code, a.out_plan_part, a.out_plan_group
          Union All
          SELECT
            a.ret_plan_line_code, a.ret_plan_part, a.ret_plan_group,
              0 qty_ld, 0 qty_tf, SUM(a.ret_plan_qtyg) qty_retg, SUM(a.ret_plan_qtyr) + SUM(a.ret_plan_qtyrfc) qty_retr
          FROM material_ret_by_group a
          WHERE a.ret_plan_date BETWEEN '$start_date' AND '$date'
          AND ret_confirm_flag = 1
          GROUP BY a.ret_plan_line_code, a.ret_plan_part, a.ret_plan_group
          Union All
          SELECT
              a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP,
              0 qty_ld, SUM(a.PACK_STOCK_QTY) qty_tf, 0 qty_retg, 0 qty_retr
          FROM pack_stock_tf_group a 
          WHERE a.PACK_STOCK_DATE BETWEEN '$start_date' AND '$date'
          GROUP BY a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP
      ) sa GROUP BY line_code, part, groupx
    ) sa
    LEFT JOIN line sb ON sb.LINE_CODE = sa.line_code
    LEFT JOIN toy_part sc ON sc.PART_NUM = sa.part
    LEFT JOIN (
      SELECT PACK_STOCK_LINE, PACK_STOCK_PART, PACK_STOCK_GROUP, MAX(PACK_STOCK_DATE) date_max
      FROM (
        SELECT a.PLAN_PROD_LINE_CODE PACK_STOCK_LINE, 
          a.PLAN_PROD_PART PACK_STOCK_PART, 
          IFNULL(a.PLAN_PROD_GROUP_ORD,'') PACK_STOCK_GROUP, 
          a.PLAN_PROD_DATE PACK_STOCK_DATE, IFNULL(b.recon_flag, 0) recon_flag
        FROM plan_prod_daily a 
        LEFT JOIN recon_flag b ON b.recon_date = a.PLAN_PROD_DATE 
        AND b.recon_line = a.PLAN_PROD_LINE_CODE 
        AND b.recon_part = a.PLAN_PROD_PART
        AND IFNULL(b.recon_group, '') = IFNULL(a.PLAN_PROD_GROUP_ORD, '')
        WHERE a.PLAN_PROD_DATE BETWEEN '$start_date' AND '$date'
      ) a 
      WHERE recon_flag = 0
      GROUP BY PACK_STOCK_LINE, PACK_STOCK_PART, PACK_STOCK_GROUP
    ) sd ON sa.line_code = sd.PACK_STOCK_LINE AND sa.part = sd.PACK_STOCK_PART AND sa.groupx = sd.PACK_STOCK_GROUP 
    LEFT JOIN (
      SELECT DISTINCT PART_DATE, PART_NUM FROM toy_part_eof WHERE PART_DATE = '$date'
    ) se ON sa.part = se.PART_NUM AND se.PART_DATE = '$date'
    WHERE sa.line_code NOT IN ('41','42','20') "
    .(($unit !="" && $unit != "ALL") ? " AND sb.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND sb.LINE_CODE ='$line' " : "").""
    .(($style !="" && $style != "ALL") ? " AND UCASE(sa.part) = '$style'" : "").""
    .(($group !="" && $group != "ALL") ? " AND UCASE(sa.groupx) = '$group'" : "").""
    .(($line_all !="") ? " AND sb.LINE_CODE IN (" . $line_all . ")" : "") . "
    ".$strBln."
    ORDER BY sb.LINE_PREF, sb.LINE_ORDR, sa.groupx, sa.part 
    ";

    //var_dump($strSql);

    // LAST TRANSFER BY TF
    // SELECT PACK_STOCK_LINE, PACK_STOCK_PART, PACK_STOCK_GROUP, MAX(PACK_STOCK_DATE) date_max
    // FROM (
    //   SELECT a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP,
    //   a.PACK_STOCK_DATE, IFNULL(b.recon_flag, 0) recon_flag
    //   FROM pack_stock_tf_group a 
    //   LEFT JOIN recon_flag b ON a.PACK_STOCK_DATE = b.recon_date AND a.PACK_STOCK_LINE = b.recon_line AND a.PACK_STOCK_GROUP = b.recon_group AND a.PACK_STOCK_PART = b.recon_part
    //   WHERE a.PACK_STOCK_DATE BETWEEN '$start_date' AND '$date'
    // ) a 
    // WHERE recon_flag = 0
    // GROUP BY PACK_STOCK_LINE, PACK_STOCK_PART, PACK_STOCK_GROUP

  } else if ($section == 18) { // view wip detail
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];

    $start_date = '2023-10-16';
    $strSql = "
    SELECT MIN(datex) datef, DATE_ADD(MAX(datex), INTERVAL 1 DAY) datet
    FROM (
      
      SELECT a.PLAN_PROD_DATE datex
      FROM plan_prod_daily a 
      LEFT JOIN recon_flag b ON a.PLAN_PROD_DATE = b.recon_date 
      AND a.PLAN_PROD_LINE_CODE = b.recon_line 
      AND a.PLAN_PROD_GROUP_ORD = b.recon_group 
      AND a.PLAN_PROD_PART = b.recon_part
      WHERE IFNULL(b.recon_flag, 0) = 0 AND a.PLAN_PROD_DATE BETWEEN '$start_date' AND '$date'
      AND UCASE(a.PLAN_PROD_GROUP_ORD) = '$group'"
      .(($line !="" && $line != "ALL") ? " AND a.PLAN_PROD_LINE_CODE ='$line' " : "").""
      .(($style !="" && $style != "ALL") ? " AND UCASE(a.PLAN_PROD_PART) = '$style'" : "")."
      UNION ALL
      
      SELECT a.out_plan_date datex
      FROM material_ot_by_group a
      LEFT JOIN recon_flag b ON a.out_plan_date = b.recon_date 
      AND a.out_plan_line_code = b.recon_line 
      AND a.out_plan_group = b.recon_group 
      AND a.out_plan_part = b.recon_part
      WHERE IFNULL(b.recon_flag, 0) = 0 AND a.out_plan_date BETWEEN '$start_date' AND '$date'
      AND UCASE(a.out_plan_group) = '$group' AND (IFNULL(out_plan_qty_ic, 0) + IFNULL(out_plan_qty_adm, 0)) <> 0" 
      .(($line !="" && $line != "ALL") ? " AND a.out_plan_line_code ='$line' " : "").""
      .(($style !="" && $style != "ALL") ? " AND UCASE(a.out_plan_part) = '$style'" : "")."
      UNION ALL
      
      SELECT
        a.ret_plan_date datex
      FROM material_ret_by_group a
      LEFT JOIN recon_flag b ON a.ret_plan_date = b.recon_date 
      AND a.ret_plan_line_code = b.recon_line 
      AND a.ret_plan_group = b.recon_group 
      AND a.ret_plan_part = b.recon_part
      WHERE IFNULL(b.recon_flag, 0) = 0 AND a.ret_plan_date BETWEEN '$start_date' AND '$date'
      AND UCASE(a.ret_plan_group) = '$group'"
      .(($line !="" && $line != "ALL") ? " AND a.ret_plan_line_code ='$line' " : "").""
      .(($style !="" && $style != "ALL") ? " AND UCASE(a.ret_plan_part) = '$style'" : "")."
      AND ret_confirm_flag = 1
      UNION ALL
            
      SELECT
        a.PACK_STOCK_DATE datex
      FROM pack_stock_tf_group a 
      LEFT JOIN recon_flag b ON a.PACK_STOCK_DATE = b.recon_date 
      AND a.PACK_STOCK_LINE = b.recon_line 
      AND a.PACK_STOCK_GROUP = b.recon_group 
      AND a.PACK_STOCK_PART = b.recon_part
      WHERE IFNULL(b.recon_flag, 0) = 0 AND a.PACK_STOCK_DATE BETWEEN '$start_date' AND '$date'
      AND UCASE(a.PACK_STOCK_GROUP) = '$group'"
      .(($line !="" && $line != "ALL") ? " AND a.PACK_STOCK_LINE ='$line' " : "").""
      .(($style !="" && $style != "ALL") ? " AND UCASE(a.PACK_STOCK_PART) = '$style'" : "")."
    ) a 
    ";

    //echo '<pre>'. $strSql . '</pre>';

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);

    //echo $row['datef'].'</br>';
    //echo $row['datet'].'</br>';

    $dateF = new DateTime($row['datef']);
    $dateT = new DateTime($row['datet']);
    $intv = DateInterval::createFromDateString('1 day');
    $period = new DatePeriod($dateF, $intv, $dateT);

    $strDate = ''; $incDate = 0;
    foreach ($period as $dateC) {
      //echo $dateC->format("Y-m-d");
      if ($incDate==0){
        $strDate .= "SELECT '".$dateC->format("Y-m-d")."' datex ";
      } else {
        $strDate .= "UNION ALL ";
        $strDate .= "SELECT '".$dateC->format("Y-m-d")."' datex ";
      }
      
      $incDate++; 
    }

    //echo $strDate;

    $strSql = "
    SELECT a.datex datel, IFNULL(b.linex,'') linex, IFNULL(b.groupx,'') groupx, 
    IFNULL(b.partx,'') partx, 
    IFNULL(b.rdayx, '0') rdayx, IFNULL(b.planx, '0') planx,
    IFNULL(b.loadx, '0') loadx, IFNULL(b.movex, '0') movex,
    IFNULL(b.retgx, '0') retgx, IFNULL(b.retrdcx, '0') retrdcx, IFNULL(b.retrfcx, '0') retrfcx, 
    IFNULL(b.tfx, '0') tfx, IFNULL(b.rejdcx, '0') rejdcx,
    IFNULL(b.rejfcx, '0') rejfcx, IFNULL(b.fcx, '0') fcx, IFNULL(b.lostx, '0') lostx,
    IFNULL(b.retflagx, '0') retflagx, IFNULL(b.remarkx,'') remarkx, IFNULL(c.ret_plan_no,'') retnox
    FROM (
      ".$strDate."
    ) a LEFT JOIN (
      SELECT datex, linex, groupx, partx, 
        SUM(rday) rdayx, SUM(planx) planx, SUM(loadx) loadx, 
        SUM(movex) movex, SUM(retg) retgx, SUM(retrdc) retrdcx, SUM(retrfc) retrfcx, SUM(tfx) tfx, 
        SUM(rejdcx) rejdcx, SUM(rejfcx) rejfcx, SUM(fcx) fcx, SUM(lostx) lostx,
        SUM(retflagx) retflagx, UCASE(IFNULL(GROUP_CONCAT(remarkx),'')) remarkx  
      FROM (
        SELECT
          a.PLAN_PROD_DATE datex,
          a.PLAN_PROD_LINE_CODE linex, 
          a.PLAN_PROD_GROUP_ORD groupx,
          a.PLAN_PROD_PART partx,
          a.PLAN_PROD_RD rday, 
          SUM(a.PLAN_PROD_QTY) planx, 0 loadx, 0 movex, 0 retg, 0 retrdc, 0 retrfc, 0 tfx, 
          0 rejdcx, 0 rejfcx, 0 fcx, 0 lostx, 0 retflagx, NULL remarkx  
        FROM plan_prod_daily a 
        WHERE a.PLAN_PROD_DATE BETWEEN '$start_date' AND '$date'
        AND UCASE(a.PLAN_PROD_GROUP_ORD) = '$group'"
        .(($line !="" && $line != "ALL") ? " AND a.PLAN_PROD_LINE_CODE ='$line' " : "").""
        .(($style !="" && $style != "ALL") ? " AND UCASE(a.PLAN_PROD_PART) = '$style'" : "")."
        GROUP BY a.PLAN_PROD_DATE, a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_GROUP_ORD, a.PLAN_PROD_PART, a.PLAN_PROD_RD UNION ALL
        
        SELECT
          a.out_plan_date datex,
          a.out_plan_line_code linex, 
          a.out_plan_group groupx,
          a.out_plan_part partx,
          0 rday, 0 planx, 
          SUM(a.out_plan_qty_ic) loadx, SUM(a.out_plan_qty_adm) movex, 0 retg, 0 retrdc, 0 retrfc, 0 tfx,
          SUM(a.out_plan_qty_rejdc) rejdcx, SUM(a.out_plan_qty_rejfc) rejfcx, SUM(a.out_plan_qty_fc) fcx, SUM(a.out_plan_qty_lost) lostx,
          0 retflagx, GROUP_CONCAT(out_plan_qty_rem) remarkx
        FROM material_ot_by_group a
        WHERE a.out_plan_date BETWEEN '$start_date' AND '$date'
        AND UCASE(a.out_plan_group) = '$group'"
        .(($line !="" && $line != "ALL") ? " AND a.out_plan_line_code ='$line' " : "").""
        .(($style !="" && $style != "ALL") ? " AND UCASE(a.out_plan_part) = '$style'" : "")."
        GROUP BY a.out_plan_date, a.out_plan_line_code, a.out_plan_group, a.out_plan_part UNION ALL
        
        SELECT
          a.ret_plan_date datex,
          a.ret_plan_line_code linex, 
          a.ret_plan_group groupx,
          a.ret_plan_part partx,
          0 rday, 0 planx, 0 loadx, 0 movex, 
          SUM(a.ret_plan_qtyg) retg, SUM(a.ret_plan_qtyr) retrdc, SUM(a.ret_plan_qtyrfc) retrfc, 0 tfx,
          0 rejdcx, 0 rejfcx, 0 fcx, 0 lostx, SUM(a.ret_confirm_flag) retflagx, NULL remarkx
        FROM material_ret_by_group a
        WHERE a.ret_plan_date BETWEEN '$start_date' AND '$date'
        AND UCASE(a.ret_plan_group) = '$group'"
        .(($line !="" && $line != "ALL") ? " AND a.ret_plan_line_code ='$line' " : "").""
        .(($style !="" && $style != "ALL") ? " AND UCASE(a.ret_plan_part) = '$style'" : "")."
        GROUP BY a.ret_plan_date, a.ret_plan_line_code, a.ret_plan_group, a.ret_plan_part UNION ALL
              
        SELECT
          a.PACK_STOCK_DATE datex, 
          a.PACK_STOCK_LINE linex,
          a.PACK_STOCK_GROUP groupx,
          a.PACK_STOCK_PART partx,
          0 rday, 0 planx, 0 loadx, 0 movex, 0 retg, 0 retrdc, 0 retrfc,
          SUM(a.PACK_STOCK_QTY) tfx, 0 rejdcx, 0 rejfcx, 0 fcx, 0 lost, 0 retflagx, NULL remarkx
        FROM pack_stock_tf_group a 
        WHERE a.PACK_STOCK_DATE BETWEEN '$start_date' AND '$date'
        AND UCASE(a.PACK_STOCK_GROUP) = '$group'"
        .(($line !="" && $line != "ALL") ? " AND a.PACK_STOCK_LINE ='$line' " : "").""
        .(($style !="" && $style != "ALL") ? " AND UCASE(a.PACK_STOCK_PART) = '$style'" : "")."
        GROUP BY a.PACK_STOCK_DATE, a.PACK_STOCK_LINE, a.PACK_STOCK_GROUP, a.PACK_STOCK_PART
      ) a 
      GROUP BY datex, linex, groupx, partx
    ) b on a.datex = b.datex
    LEFT JOIN material_ret_by_group c ON a.datex = c.ret_plan_date 
      AND b.linex = c.ret_plan_line_code AND b.partx = c.ret_plan_part AND b.groupx = c.ret_plan_group 
    ";
  } else if ($section == 19) { // add history quantity wip
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 
    
    $act = $_GET["act"];
    $date = $_GET["date"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];
    $val = $_GET["value"];

    //count note data
    $strSql = "
    SELECT COUNT(*) REC_COUNT FROM material_ot_by_group 
    WHERE out_plan_date='".$date."' 
    AND out_plan_line_code='".$line."' 
    AND out_plan_part='".$style."' 
    AND out_plan_group='".$group."';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    if ($act == 'RDC'){
      $col = "`out_plan_qty_rejdc`";
    } else if ($act == 'RFC'){
      $col = "`out_plan_qty_rejfc`";
    } else if ($act == 'FC'){
      $col = "`out_plan_qty_fc`";
    } else if ($act == 'LST'){
      $col = "`out_plan_qty_lost`";
    } else if ($act == 'RMK') {
      $col = "`out_plan_qty_rem`";
    }

    if ($act != 'RMK') {
      $val =(float)$Val;
    }

    //if not exsist add
    if ($rec_count == 0){
      //add hour
      $strSql = "
      INSERT INTO `material_ot_by_group` (
        `out_plan_date`, `out_plan_line_code`, `out_plan_part`, 
        `out_plan_group`, `out_plan_group_id`, `out_plan_rdays`, 
        ".$col.", 
        `out_plan_add_date`, `out_plan_add_id`
      ) VALUES (
        '".$date."', '".$line."', '".$style."', 
        '".$group."', 0, 0,
        '".$val."', 
        NOW(), ".$useridx."
      );
      ";
    } else {
      //empty hour
      $strSql = "
      UPDATE `material_ot_by_group` 
      SET ".$col."= '".$val."', out_plan_mod_date = NOW(), out_plan_mod_id ='".$useridx."'  
      WHERE out_plan_date='".$date."' 
      AND out_plan_line_code='".$line."' 
      AND out_plan_part='".$style."' 
      AND out_plan_group='".$group."';
      ";
    }

    //echo $strSql;
    //execute
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }
      
    $strSql = "SELECT '". $action ."' actionx";

  } else if ($section == 20) { // view bom part
  
    $style = $_GET["style"];
    $strSql = "
      SELECT a.PART_NUM partx, b.PART_NAME descx, b.PART_UNIT unitx, a.PART_MATL_CODE matx, c.MATL_NAME matdescx, c.MATL_CAT matcatx, c.MATL_UNIT matunitx, a.PART_MATL_QTY yieldx 
      FROM toy_part_matl a 
      LEFT JOIN toy_part b ON a.PART_NUM = b.PART_NUM
      LEFT JOIN material c ON a.PART_MATL_CODE = c.MATL_CODE
      WHERE a.PART_NUM ='" . $style . "' AND c.MATL_SCNT_FLAG = 1  ORDER BY c.MATL_CAT, c.MATL_CODE;
    ";
  } else if ($section == 21) { // add return

    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $jsfile = file_get_contents("php://input");
    $jsdata = json_decode($jsfile, true);
    
    $strSql = "
      SELECT '".$jsdata["date"]."' datex, 
      '".$jsdata['line']."' linex,
      '".$jsdata['group']."' groupx,
      '".$jsdata['style']."' stylex,
      '".$jsdata['datas']."' datax
      ;";

    //$action = 'TRUE';
    //$strSql = "SELECT '". $action ."' actionx";

  } else if ($section == 30) { // header wip count
    $date = $_GET["date"];
    $start_date = '2023-10-16';

    $strSql = "
    SELECT
      sb.LINE_PREF unitx, 
      sa.line_code linex, 
      sb.LINE_DESC line_descx, 
      sb.LINE_NAME_SPV leadx, 
      part partx, 
      sc.PART_NAME part_descx, 
      sa.groupx, IFNULL(sa.blx, 0) blx, IFNULL(sd.date_max, '') date_max, sa.flagx, IFNULL(se.countx,0) countx
    FROM (
      SELECT count_line_code line_code, count_part part, count_group groupx, b.blx, count_flag flagx 
      FROM material_raw_wip_count_head a 
      LEFT JOIN (
        SELECT line_code, part, groupx, SUM(qty_bl) blx
        FROM (
          SELECT
              a.out_plan_line_code line_code, a.out_plan_part part, a.out_plan_group groupx,
              (SUM(a.out_plan_qty_ic) + SUM(a.out_plan_qty_adm)) qty_bl
          FROM material_ot_by_group a
          WHERE a.out_plan_date BETWEEN '$start_date' AND '$date'
          GROUP BY a.out_plan_line_code, a.out_plan_part, a.out_plan_group
          UNION ALL
          SELECT
            a.ret_plan_line_code, a.ret_plan_part, a.ret_plan_group,
            (SUM(a.ret_plan_qtyg) + SUM(a.ret_plan_qtyr) + SUM(a.ret_plan_qtyrfc)) * -1 qty_bl
          FROM material_ret_by_group a
          WHERE a.ret_plan_date BETWEEN '$start_date' AND '$date'
          AND ret_confirm_flag = 1
          GROUP BY a.ret_plan_line_code, a.ret_plan_part, a.ret_plan_group
          Union All
          SELECT
              a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP,
              SUM(a.PACK_STOCK_QTY) * -1 qty_bl
          FROM pack_stock_tf_group a 
          WHERE a.PACK_STOCK_DATE BETWEEN '$start_date' AND '$date'
          GROUP BY a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP
        ) sa GROUP BY line_code, part, groupx
      ) b ON a.count_line_code = b.line_code AND a.count_group = b.groupx AND a.count_part = b.part 
      WHERE count_date ='".$date."'
    ) sa
    LEFT JOIN line sb ON sb.LINE_CODE = sa.line_code
    LEFT JOIN toy_part sc ON sc.PART_NUM = sa.part
    LEFT JOIN (
      SELECT a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP,
      MAX(a.PACK_STOCK_DATE) date_max
      FROM pack_stock_tf_group a 
      WHERE a.PACK_STOCK_DATE BETWEEN '$start_date' AND '$date'
      GROUP BY a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP
    ) sd ON sa.line_code = sd.PACK_STOCK_LINE AND sa.part = sd.PACK_STOCK_PART AND sa.groupx = sd.PACK_STOCK_GROUP
    LEFT JOIN (
      SELECT a.linex, partx, groupx, (fcg + fcr + dcs) countx 
      FROM (
        SELECT DISTINCT count_line_code linex, count_part partx, count_group groupx, IFNULL(count_part_fcg, 0) fcg, IFNULL(a.count_part_fcr, 0) fcr, IFNULL(a.count_part_dcs, 0) dcs 
        FROM material_raw_wip_count a 
        WHERE a.count_date = '$date'
      ) a
    ) se ON sa.line_code = se.linex AND sa.part = se.partx AND sa.groupx = se.groupx
    ORDER BY sb.LINE_PREF, sb.LINE_ORDR, sa.groupx, sc.PART_NUM 
    ";
  } else if ($section == 31) { // detail wip count
    
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];
    $balance = $_GET["balance"];
    
    $strBln = '';
    if ($balance == 'N'){
      $strBln = "AND (qty_ld - (qty_tf + qty_retg + qty_retr)) <> 0";
    } else {
      $strBln = "";
    }
    
    $start_date = '2023-10-16';
    $strSql = "
    SELECT
      sb.LINE_PREF unitx, 
      sa.line_code linex, 
      sb.LINE_DESC line_descx, 
      sb.LINE_NAME_SPV leadx, 
      part partx, 
      sc.PART_NAME part_descx, 
      groupx, sa.flagx, se.PART_MATL_QTY yieldx, sa.blx,
      sf.MATL_CODE matl_codex, sf.MATL_NAME matl_namex, sf.MATL_UNIT matl_unitx, sf.MATL_CAT matl_catx,
      sg.count_part_fcg hfcgx, sg.count_part_fcr hfcrx, sg.count_part_dcs hdcsx, sg.count_part_dcu hdcux,
      sg.count_fcg dfcgx, sg.count_fcr dfcrx, sg.count_dcs ddcsx, sg.count_dcu ddcux, UCASE(IFNULL(sh.USER_INISIAL, '')) userx
    FROM (
      SELECT 
        count_line_code line_code, 
        count_part part, 
        count_group groupx, 
        count_flag flagx,
        b.blx 
      FROM material_raw_wip_count_head a 
      LEFT JOIN (
        SELECT line_code, part, groupx, SUM(qty_bl) blx
        FROM (
          SELECT
              a.out_plan_line_code line_code, a.out_plan_part part, a.out_plan_group groupx,
              (SUM(a.out_plan_qty_ic) + SUM(a.out_plan_qty_adm)) qty_bl
          FROM material_ot_by_group a
          WHERE a.out_plan_date BETWEEN '$start_date' AND '$date'
          GROUP BY a.out_plan_line_code, a.out_plan_part, a.out_plan_group
          UNION ALL
          SELECT
            a.ret_plan_line_code, a.ret_plan_part, a.ret_plan_group,
            (SUM(a.ret_plan_qtyg) + SUM(a.ret_plan_qtyr) + SUM(a.ret_plan_qtyrfc)) * -1 qty_bl
          FROM material_ret_by_group a
          WHERE a.ret_plan_date BETWEEN '$start_date' AND '$date'
          AND ret_confirm_flag = 1
          GROUP BY a.ret_plan_line_code, a.ret_plan_part, a.ret_plan_group
          Union All
          SELECT
              a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP,
              SUM(a.PACK_STOCK_QTY) * -1 qty_bl
          FROM pack_stock_tf_group a 
          WHERE a.PACK_STOCK_DATE BETWEEN '$start_date' AND '$date'
          GROUP BY a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP
        ) sa GROUP BY line_code, part, groupx
      ) b ON a.count_line_code = b.line_code AND a.count_group = b.groupx AND a.count_part = b.part 
      WHERE count_date ='".$date."'
    ) sa
    LEFT JOIN line sb ON sb.LINE_CODE = sa.line_code
    LEFT JOIN toy_part sc ON sc.PART_NUM = sa.part
    LEFT JOIN toy_part_matl se ON sa.part = se.PART_NUM
    LEFT JOIN material sf on se.PART_MATL_CODE = sf.MATL_CODE
    LEFT JOIN material_raw_wip_count sg ON sg.count_line_code = sa.line_code 
      AND sg.count_part = sa.part AND sg.count_group = sa.groupx AND sg.count_matl = se.PART_MATL_CODE
      AND sg.count_date = '".$date."'
    LEFT JOIN xref_user_web sh ON sh.USER_ID = IFNULL(sg.count_mod_id, sg.count_add_id)
    WHERE sa.line_code NOT IN ('20') AND sf.MATL_SCNT_FLAG=1"
    .(($unit !="" && $unit != "ALL") ? " AND sb.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND sb.LINE_CODE ='$line' " : "").""
    .(($style !="" && $style != "ALL") ? " AND UCASE(sa.part) = '$style'" : "").""
    .(($group !="" && $group != "ALL") ? " AND UCASE(sa.groupx) = '$group'" : "")."
    ".$strBln."
    ORDER BY sb.LINE_PREF, sb.LINE_ORDR, sa.groupx, sa.part, sf.MATL_CAT 
    ";
  } else if ($section == 32) { // add detail wip count
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 
    
    $jsfile = file_get_contents("php://input");
    $jsdata = json_decode($jsfile, true);

    $date = $_POST["date"];
    $unit = $_POST["unit"];
    $line = $_POST["line"];
    $style = $_POST["style"];
    $group = $_POST["group"];
    $matl = $_POST["matl"];
    $cold = $_POST["cold"];
    
    if ($cold == 'col_gdd_fc') {
      $curColH = 'count_part_fcg';
      $curColD = 'count_fcg';
    } else if ($cold == 'col_rej_fc') {
      $curColH = 'count_part_fcr';
      $curColD = 'count_fcr';
    } else if ($cold == 'col_set_dc') {
      $curColH = 'count_part_dcs';
      $curColD = 'count_dcs';
    } else if ($cold == 'col_unset_dc') {
      $curColH = 'count_part_dcu';
      $curColD = 'count_dcu';
    }

    $colh_val = $_POST["colh_val"];
    $cold_val = $_POST["cold_val"];

    //count note data
    $strSql = "
      SELECT COUNT(*) REC_COUNT 
      FROM material_raw_wip_count WHERE count_date='".$date."' 
      AND count_line_code='".$line."' 
      AND count_part='".$style."' 
      AND count_group='".$group."'
      AND count_matl='".$matl."';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    //if not exsist add
    if ($rec_count == 0){
      //insert
      $strSql="
      INSERT INTO `material_raw_wip_count` (
        `count_date`, `count_line_code`, `count_part`, 
        `count_group`, `count_matl`, 
        `".$curColH."`, `".$curColD."`,
        `count_add_id`, `count_add_date`
      ) VALUES (
        '".$date."', '".$line."', '".$style."', 
        '".$group."', '".$matl."', 
        '".$colh_val."', '".$cold_val."',
        '".$useridx."', NOW()
      );
      ";
    }else {
      //update
      $strSql="
      UPDATE `material_raw_wip_count` 
      SET 
        `".$curColH."`='".$colh_val."', 
        `".$curColD."`='".$cold_val."',
        `count_mod_id`='".$useridx."', `count_mod_date`= NOW()
      WHERE count_date='".$date."' 
        AND count_line_code='".$line."' 
        AND count_part='".$style."' 
        AND count_group='".$group."'
        AND count_matl='".$matl."';
      ";
    }
    
    //echo $strSql;

    if (mysqli_query($conn, $strSql)) {
      
      $strSql = "
      UPDATE material_raw_wip_count_head SET count_flag=1 
      WHERE count_date='".$date."' 
      AND count_line_code='".$line."' 
      AND count_part='".$style."' 
      AND count_group='".$group."';
      ";
      //echo $strSql;
      $res = mysqli_query($conn, $strSql);

      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }

    $strSql = "SELECT ". $action ." actionx;";
  } else if ($section == 33) { // add part list
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 
    
    $jsfile = file_get_contents("php://input");
    $jsdata = json_decode($jsfile, true);

    $date = $_POST["date"];
    $line = $_POST["line"];
    $group = $_POST["group"];
    $style = $_POST["style"];
    
    //count note data
    $strSql = "
      SELECT COUNT(*) REC_COUNT 
      FROM material_raw_wip_count_head WHERE count_date='".$date."' 
      AND count_line_code='".$line."' 
      AND count_part='".$style."' 
      AND count_group='".$group."';
    ";

    
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    //if not exsist add
    if ($rec_count == 0){
      //insert
      $strSql="
      INSERT INTO `material_raw_wip_count_head` (
        `count_date`, `count_line_code`, `count_part`, 
        `count_group`, `count_flag`, 
        `count_add_id`, `count_add_date`
      ) VALUES (
        '".$date."', '".$line."', '".$style."', 
        '".$group."', 0, 
        '".$useridx."', NOW()
      );
      ";
      
      //echo $strSql;
      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }
    } else {
      $action = 'FALSE';
    } 

    $strSql = "SELECT '". $action ."' actionx;";
  } else if ($section == 34) { // import part list
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 
    

    $date = $_GET["date"];
    $start_date = '2023-10-16';
    $strSql = "
    INSERT INTO `material_raw_wip_count_head` (
      `count_date`, 
      `count_line_code`, 
      `count_part`, 
      `count_group`, 
      `count_balance`, 
      `count_flag`, `count_add_id`, `count_add_date`
    )  
    SELECT '$date' datex, linex, partx, groupx, IFNULL(blx, 0) blx, 0 flagx, '".$useridx."' uidx, NOW() dateaddx 
    FROM (
      SELECT
        sa.line_code linex,
        part partx, 
        groupx,
        qty_ld - (qty_tf + qty_retg + qty_retr) blx, 
        IFNULL(ccountx, 0) ccountx 
      FROM (
        SELECT line_code, part, groupx, SUM(qty_ld) qty_ld, SUM(qty_tf) qty_tf, SUM(qty_retg) qty_retg, SUM(qty_retr) qty_retr
        FROM (
            SELECT
                a.out_plan_line_code line_code, a.out_plan_part part, a.out_plan_group groupx,
                SUM(a.out_plan_qty_ic) + SUM(a.out_plan_qty_adm) qty_ld, 0 qty_tf, 0 qty_retg, 0 qty_retr
            FROM material_ot_by_group a
            WHERE a.out_plan_date BETWEEN '$start_date' AND '$date'
            GROUP BY a.out_plan_line_code, a.out_plan_part, a.out_plan_group
            Union All
            SELECT
              a.ret_plan_line_code, a.ret_plan_part, a.ret_plan_group,
                0 qty_ld, 0 qty_tf, SUM(a.ret_plan_qtyg) qty_retg, SUM(a.ret_plan_qtyr) + SUM(a.ret_plan_qtyrfc) qty_retr
            FROM material_ret_by_group a
            WHERE a.ret_plan_date BETWEEN '$start_date' AND '$date'
            AND ret_confirm_flag = 1
            GROUP BY a.ret_plan_line_code, a.ret_plan_part, a.ret_plan_group
            Union All
            SELECT
                a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP,
                0 qty_ld, SUM(a.PACK_STOCK_QTY) qty_tf, 0 qty_retg, 0 qty_retr
            FROM pack_stock_tf_group a 
            WHERE a.PACK_STOCK_DATE BETWEEN '$start_date' AND '$date'
            GROUP BY a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP
        ) sa GROUP BY line_code, part, groupx
      ) sa
      LEFT JOIN line sb ON sb.LINE_CODE = sa.line_code
      LEFT JOIN toy_part sc ON sc.PART_NUM = sa.part
      LEFT JOIN (
        SELECT count_line_code clinex, count_part cpartx, count_group cgroupx, 1 ccountx
        FROM material_raw_wip_count_head 
        WHERE count_date = '$date'
      ) sd ON sa.line_code = sd.clinex AND sa.part = sd.cpartx AND sa.groupx = sd.cgroupx 
      WHERE sa.line_code NOT IN ('41','42','20') 
      AND (qty_ld - (qty_tf + qty_retg + qty_retr)) <> 0
    ) ga WHERE ccountx <> 1";

    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }

    $strSql = "SELECT '". $action ."' actionx;";

  } else if ($section == 35) { // LIST KOREKSI PRODUCTION QTY
    
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];

    $strSql = "
      SELECT 
        a.OUT_PROD_ID idx, a.OUT_PLAN_ID planidx, a.OUT_PROD_TIME timex, a.OUT_PROD_QTY outx, IFNULL(b.PLAN_PROD_LINE_CODE, 'UNSCHEADULE') linex, 
        b.PLAN_PROD_PART partx, IFNULL(b.PLAN_PROD_GROUP_ORD, '') groupx, b.PLAN_PROD_QTY planx, IFNULL(b.PLAN_PROD_ORDR, 1000) ordx,
        c.LINE_DESC linedx, IFNULL(d.PART_NAME, 'UNSCHEADULE') partnx, c.LINE_PREF prefx, e.USER_INISIAL admx, b.PLAN_PROD_FLAG flagx
      FROM output_prod_good a 
      LEFT JOIN plan_prod_daily b ON a.OUT_PLAN_ID = (REPLACE(CONCAT(CAST(b.PLAN_PROD_DATE AS CHAR), CAST(b.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(b.PLAN_PROD_PART AS CHAR), CAST(b.PLAN_PROD_FLAG AS CHAR), CAST(b.PLAN_PROD_GROUP AS CHAR)),'-',''))
      LEFT JOIN line c ON b.PLAN_PROD_LINE_CODE = c.LINE_CODE
      LEFT JOIN toy_part d ON d.PART_NUM = b.PLAN_PROD_PART
      LEFT JOIN xref_user_web e on e.USER_ID = a.OUT_PROD_ADD_ID
      WHERE a.OUT_PROD_DATE ='$date' AND b.PLAN_PROD_DATE ='$date'"
      .(($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "").""
      .(($line !="" && $line != "ALL") ? " AND c.LINE_CODE ='$line' " : "").""
      .(($style !="" && $style != "ALL") ? " AND UCASE(a.OUT_PROD_PART) = '$style'" : "").""
      .(($group !="" && $group != "ALL") ? " AND UCASE(IFNULL(b.PLAN_PROD_GROUP_ORD, '')) = '$group'" : "")."
      ORDER BY c.LINE_PREF, c.LINE_ORDR, b.PLAN_PROD_GROUP_ORD, a.OUT_PLAN_ID, a.OUT_PROD_TIME
    ";   
  } else if ($section == 36) { // ADD KOREKSI PRODUCTION QTY
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $data_id = $_POST["data_id"];
    $data_qty = doubleval($_POST["data_qty"]);

    $strSql = "
      UPDATE output_prod_good SET OUT_PROD_QTY='$data_qty' 
      WHERE OUT_PROD_ID='$data_id';
    ";

    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }

    $strSql = "SELECT ". $action ." actionx;";
  
  } else if ($section == 37) { // DEL PRODUCTION QTY
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $data_id = $_POST["data_id"];

    $strSql = "
      DELETE FROM output_prod_good WHERE OUT_PROD_ID='$data_id';
    ";

    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }

    $strSql = "SELECT ". $action ." actionx, '$data_id' idx;";

  } else if ($section == 38) { //ADD PROD LEAD

    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $prod_id = $_GET["prod_id"];
    $prod_lead = $_GET["prod_lead"];

    $strSql ="
    SELECT COUNT(*) REC_COUNT
    FROM output_prod_good_lead a
    WHERE a.PLAN_ID='". $prod_id ."';
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    if ($rec_count <> 0){
      //update
      $strSql ="
      UPDATE output_prod_good_lead SET 
      LEADER_NAME = '".$prod_lead."',
      MOD_ID = '".$useridx."',
      MOD_DATE = NOW()
      WHERE PLAN_ID='". $prod_id ."';
      ";

    } else {
      //insert
      $strSql = "
      INSERT INTO `output_prod_good_lead` (
        `PLAN_ID`, `LEADER_NAME`, `ADD_ID`, `ADD_DATE`
      ) VALUES (
        '". $prod_id ."', '". $prod_lead ."', '".$useridx."', NOW() 
      );
      ";
    }

    // action succes
    //echo $strSql;
    $action = '';
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    // action false
    } else {
      $action = 'FALSE';
    }

    $strSql = "
    SELECT '". $action ."' action_stat,
    '" . $prod_id . "' prod_id,
    '" . $prod_lead . "' prod_lead;
    ";

  } else if ($section == 90) { // get ref style
    $strSql = "
      SELECT PART_NUM partx, PART_NAME part_namex 
      FROM toy_part ORDER BY PART_NAME ASC; 
    ";
  }
}
//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
