<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

/*
require 'vendor/autoload.php';
use Firebase\JWT\JWT;
*/

$input = file_get_contents("php://input");
$output = json_decode($input, true);

$username = $output["username"];
$password = $output["password"];
$token = '';

$options = [
  'cost' => 10
];

if ($username == '' && $password == '') {
  echo json_encode([
    "success"=>false,
    "message"=>"Username / password tidak boleh kosong."
  ]);
} else {
  
  $query = "
  SELECT USER_ID, UCASE(USER_INISIAL) USER_INISIAL, USER_NAME, USER_PASS, IFNULL(USER_UNIT,'') USER_UNIT, IFNULL(USER_LEVEL,'') USER_LEVEL, IFNULL(USER_LINE,'') USER_LINE 
  FROM xref_user_web WHERE USER_NAME='".$username."' LIMIT 1
  ";

  $query_run = mysqli_query($conn, $query);

  if(mysqli_num_rows($query_run) > 0) {
    // verify data
    $row = mysqli_fetch_array(@$query_run);
    $password_hased = $row['USER_PASS'];
    $password_periv = password_verify($password, $password_hased);
    $user_line = '';
    
    if ($row['USER_LINE'] == ''){
      $user_line = "";
    } else {
      $user_line = "AND a.LINE_CODE IN (".$row['USER_LINE'].")";
    }

    if ($password_periv == true){
      $token = $password_hased;

      /*$token = JWT::encode(
        array(
          'iat'		=>	time(),
          'nbf'		=>	time(),
          'exp'		=>	time() + 3600,
          'data'	=> array(
          'user_id'	=>	$data['USER_ID'],
          'user_name'	=>	$data['USER_NAME']
          )
        ),
        $ACCES_TOKEN,
        'HS256'
      );*/

      $query = "
      SELECT a.* FROM xref_menu_web_new a 
      LEFT JOIN xref_menu_web_aces_new b ON a.menu_id = b.menu_id 
      WHERE b.menu_act_view = 1 AND b.menu_user_id = ".$row['USER_ID']."
      ORDER BY a.menu_order ASC;
      ";
      //echo $query;

      $res_menu = mysqli_query($conn, $query);
      $rows_menu = [];
      if (mysqli_num_rows($res_menu) > 0) {
        while ($row_menu = mysqli_fetch_assoc($res_menu)) {
          # code...
          $rows_menu[] = $row_menu;
        }
      }else{
        $rows_menu["empty"] = "empty";
      }

      $query = "SELECT a.LINE_CODE, a.LINE_DESC FROM `line` a WHERE a.LINE_DESC <> 'N/A' AND a.LINE_CODE <> '20' ".$user_line." ORDER BY a.LINE_ORDR ASC;";
      $res_line = mysqli_query($conn, $query);
      $rows_line = [];
      if (mysqli_num_rows($res_line) > 0) {
        while ($row_line = mysqli_fetch_assoc($res_line)) {
          # code...
          $rows_line[] = $row_line;
        }
      }else{
        $rows_line["empty"] = "empty";
      }

      echo json_encode([
          "success"=>true,
          "message"=>"Ok",
          "id"=>$row['USER_ID'],
          "name"=>$row['USER_INISIAL'],
          "unit"=>$row['USER_UNIT'],
          "level"=>$row['USER_LEVEL'],
          "token" => $token,
          "menu" => $rows_menu,
          "line" => $rows_line
        ]);  
    }else{
      echo json_encode([
        "success"=>false,
        "message"=>"Username atau password tidak valid.",
        "token" => ''
      ]);
    }
    
  }else{
    echo json_encode([
      "success"=>false,
      "message"=>"Username tidak ditemukan.",
      "token" => ''
    ]);
  }
 
}