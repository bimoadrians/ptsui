<?php
session_start();
//error_reporting(E_ALL & ~E_NOTICE);
//error_reporting(E_ALL);
error_reporting(E_ERROR);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  //prod list
  if ($section == 1) { //Prod Pef
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
      $strTabPar2 = "'". str_replace('-', '', $date_f)."' AND '". str_replace('-', '', $date_t)."'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
      $strTabPar2 = "REPLACE(DATE_ADD('$week_t', INTERVAL -6 DAY),'-','') AND '". str_replace('-', '', $week_t)."'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
      $strTabPar2 = "'".$year."".$month."01' AND '".$year."".$month."31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
      $strTabPar2 = "'".$year."0101' AND '".$year."1231'";
    }

    $strSqlHc = "
      SELECT LINEC, SCH_HC SCH_HC_H, ACT_HC ACT_HC_H 
      FROM (
        SELECT SUBSTR(GROUP_ID, 9, 2) LINEC, IFNULL(SUM(SCH_HC),0) SCH_HC, IFNULL(SUM(ACT_HC),0) ACT_HC 
        FROM (
          SELECT DISTINCT GROUP_ID, SCH_HC, ACT_HC
          FROM (
            SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 10), 
            IF(
              LOCATE('N', a.OUT_PLAN_ID, 19) = 0, 
              RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - LOCATE('O', a.OUT_PLAN_ID, 19)), 
              RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - LOCATE('N', a.OUT_PLAN_ID, 19))
            )) GROUP_ID, 
            a.PLAN_PROD_OPT SCH_HC, 0 ACT_HC 
            FROM plan_prod_daily_view_board a 
            WHERE a.PLAN_PROD_DATE BETWEEN $strTabPar1
          ) a UNION ALL
          
          SELECT DISTINCT GROUP_ID, SCH_HC, ACT_HC 
          FROM ( 
            SELECT CONCAT(LEFT(a.PLAN_ID, 10), 
            IF(
              LOCATE('N', a.PLAN_ID, 19) = 0, 
              RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - LOCATE('O', a.PLAN_ID, 19)), 
              RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - LOCATE('N', a.PLAN_ID, 19))
            )) GROUP_ID, 
            0 SCH_HC, a.OUT_PROD_GOOD_AHC ACT_HC
            FROM output_prod_good_hc a 
            WHERE LEFT(a.PLAN_ID,8) BETWEEN $strTabPar2
            AND a.PLAN_ID IN (
              SELECT DISTINCT OUT_PLAN_ID 
              FROM plan_prod_daily_view_board a 
              WHERE a.PLAN_PROD_DATE BETWEEN $strTabPar1
            )
          ) a
        ) sa LEFT JOIN line sb ON SUBSTR(GROUP_ID, 9, 2) = sb.LINE_CODE
        WHERE 1=1 "
          .(($unit !="" && $unit != "ALL") ? " AND sb.LINE_PREF ='$unit' " : "").""
          .(($line !="" && $line != "ALL") ? " AND sb.LINE_CODE ='$line' " : "").""
          .(($line_all !="") ? " AND sb.LINE_CODE IN (" . $line_all . ")" : "") . "
        GROUP BY SUBSTR(GROUP_ID, 9, 2)
      ) a
    ";

    $strSqlFho = "
    SELECT linex, IFNULL(sb.LINE_DESC,sb.LINE_DESCX) linedx, SUM(twhx) twhx, SUM(outx) outx, ROUND((SUM(outx)/SUM(twhx))*100, 0) prcx
    FROM (
      SELECT datex, planidx, linex, SUM(dwhx) dwhx, SUM(whx) whx, SUM(twhx) twhx, SUM(outx) outx, IFNULL(GROUP_CONCAT(flagx), '') flagx
      FROM (
        SELECT a.PLAN_PROD_DATE datex,
        (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), 
          CAST(a.PLAN_PROD_LINE_CODE AS CHAR), 
          CAST(a.PLAN_PROD_PART AS CHAR), 
          CAST(a.PLAN_PROD_FLAG AS CHAR), 
          CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) planidx, a.PLAN_PROD_LINE_CODE linex, CASE WHEN WEEKDAY(a.PLAN_PROD_DATE)=5 THEN 5 ELSE 7 END dwhx, a.PLAN_PROD_WH whx, 
          CASE WHEN a.PLAN_PROD_WH < 1 THEN a.PLAN_PROD_QTY ELSE ROUND((a.PLAN_PROD_QTY / a.PLAN_PROD_WH),0) END twhx, 0 outx,
          NULL flagx
        FROM plan_prod_daily a 
        WHERE a.PLAN_PROD_DATE BETWEEN $strTabPar1 
        UNION ALL
        SELECT a.OUT_PROD_DATE datex, a.OUT_PLAN_ID planidx, a.OUT_PROD_LINE_CODE linex, 0 dwhx, 0 whx, 0 twhx, a.OUT_PROD_QTY outx, 'Y' flagx
        FROM output_prod_good a 
        WHERE a.OUT_PROD_DATE BETWEEN $strTabPar1 AND 
        HOUR(a.OUT_PROD_TIME) = 8 AND 
        IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
      ) a GROUP BY datex, planidx, linex
    ) sa 
    LEFT JOIN line sb ON sa.linex = sb.LINE_CODE
    WHERE flagx = 'Y' OR whx>=dwhx "
    .(($unit !="" && $unit != "ALL") ? " AND sb.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND sb.LINE_CODE ='$line' " : "").""
    .(($line_all !="") ? " AND sb.LINE_CODE IN (" . $line_all . ")" : "") . "
    GROUP BY linex, sb.LINE_DESC
    ";

    $strSql ="
    SELECT a.LINEC, b.LINE_PREF, b.LINE_DESC, b.LINE_NAME_SPV, 
        a.LINEC, a.PARTC, c.PART_NAME, a.FCH, a.GRP, 
        0 SCH_HC, 
        IFNULL(SUM(a.SCH_WH), 0) SCH_WH, 
        IFNULL(SUM(a.SCH_QTY), 0) SCH_QTY, 
        IFNULL(SUM(a.SCH_EH), 0) SCH_EH,
        IFNULL(SUM(a.SCH_AH), 0) SCH_AH,
        0 ACT_HC, 
        IFNULL(SUM(a.ACT_WH), 0) ACT_WH, 
        IFNULL(SUM(a.ACT_QTY), 0) ACT_QTY, 
        IFNULL(SUM(a.ACT_EH), 0) ACT_EH, 
        IFNULL(SUM(a.ACT_AH), 0) ACT_AH, 
        IFNULL(SUM(a.ACT_DSA), 0) ACT_DSA,
        d.SCH_HC_H, d.ACT_HC_H, e.prcx FHO_PRC, e.twhx FHO_TWH, e.outx FHO_AWH,
        LOTX, SSX, GOODx, DEFX
      FROM (
        SELECT a.PLAN_PROD_LINE_CODE LINEC, 
          a.PLAN_PROD_PART PARTC, 
          a.PLAN_PROD_FCH FCH,
          a.PLAN_PROD_GROUP_ORD GRP,
          a.PLAN_PROD_OPT SCH_HC,
          (a.PLAN_PROD_WH * 60) SCH_WH,
          a.PLAN_PROD_WH * PLAN_PROD_OPT SCH_AH,
          a.PLAN_PROD_QTY SCH_QTY,
          ROUND((a.PLAN_PROD_FCH * a.PLAN_PROD_QTY)/1000,3) SCH_EH,
          b.HC_ACT ACT_HC,
          b.WH_ACT ACT_WH, 
          b.ACT ACT_QTY, 
          ROUND((a.PLAN_PROD_FCH * b.ACT)/1000,3) ACT_EH,
          (b.HC_ACT * b.WH_ACT)/60 ACT_AH,
          IF(b.ACT >= a.PLAN_PROD_QTY,1,0) ACT_DSA,
          b.LOTX, b.SSX, b.GOODX, b.DEFX
        FROM plan_prod_daily a 
        LEFT JOIN (
          SELECT a.PROD_ID, SUM(a.ACT) ACT, SUM(a.WH_ACT) WH_ACT, SUM(HC_ACT) HC_ACT, SUM(lotx) LOTX, SUM(ssx) SSX, SUM(goodx) GOODX, SUM(defx) DEFX 
          FROM (
            SELECT 
              a.OUT_PLAN_ID PROD_ID, SUM(a.OUT_PROD_QTY) ACT, 0 WH_ACT, 0 HC_ACT, 0 lotx, 0 ssx, 0 goodx, 0 defx
            FROM output_prod_good a 
            WHERE a.OUT_PROD_DATE BETWEEN $strTabPar1
            AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
            GROUP BY a.OUT_PLAN_ID UNION ALL

            SELECT a.OUT_PLAN_ID, 0 ACT, SUM(WH_ACT) WH_ACT, 0 HC_ACT, 0 lotx, 0 ssx, 0 goodx, 0 defx 
            FROM (
              SELECT a.OUT_PLAN_ID,
              count_actual_wh(HOUR(a.FIRST_TIME), HOUR(a.LAST_TIME), a.OUT_PROD_DATE) * 60 WH_ACT
              FROM (
                SELECT 
                  a.OUT_PLAN_ID,
                  a.OUT_PROD_DATE,
                  MIN(a.OUT_PROD_TIME) FIRST_TIME,
                  MAX(a.OUT_PROD_TIME) LAST_TIME,
                  TIMESTAMPDIFF(MINUTE, MIN(a.OUT_PROD_TIME), MAX(a.OUT_PROD_TIME)) WH_ACT, 0 HC_ACT
                FROM output_prod_good a 
                WHERE a.OUT_PROD_DATE BETWEEN $strTabPar1
                AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
                GROUP BY a.OUT_PLAN_ID, a.OUT_PROD_DATE
              ) a
            ) a GROUP BY a.OUT_PLAN_ID UNION ALL

            SELECT 
              a.PLAN_ID, 0 SCH, 0 WH_ACT, a.OUT_PROD_GOOD_AHC HC_ACT, 0 lotx, 0 ssx, 0 goodx, 0 defx
            FROM output_prod_good_hc a 
            WHERE LEFT(a.PLAN_ID,8) BETWEEN $strTabPar2 UNION ALL

            SELECT planidx, 0 SCH, 0 WH_ACT, 0 HC_ACT, lotx, ssx, goodx, defx 
            FROM (
              SELECT lboidx, planidx, SUM(lotx) lotx, SUM(ssx) ssx, SUM(goodx) goodx, SUM(defx) defx, (SUM(goodx) + SUM(defx)) chekx 
              FROM (
                SELECT 
                a.QC_LBO_ID lboidx, a.QC_LBO_PLAN_ID planidx, 0 lotx, 0 ssx, 0 goodx, COUNT(b.LBO_DEFECT_CODE) defx
                FROM qc_lbo_input a 
                LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
                LEFT JOIN defect_lbo c ON b.LBO_DEFECT_CODE = c.DEFECT_CODE
                WHERE a.QC_LBO_DATE BETWEEN $strTabPar1 AND 
                b.LBO_CATEGORY ='DEFECT' AND
                c.DEFECT_CAT = 'AESTHETIC' AND 
                a.QC_LBO_INSPECT_TYPE = 'N'
                GROUP BY a.QC_LBO_ID, a.QC_LBO_PLAN_ID UNION ALL
                
                SELECT 
                a.QC_LBO_ID lboidx, a.QC_LBO_PLAN_ID planidx, 0 lotx, 0 ssx, COUNT(b.LBO_CATEGORY) goodx, 0 defx
                FROM qc_lbo_input a 
                LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
                LEFT JOIN defect_lbo c ON b.LBO_DEFECT_CODE = c.DEFECT_CODE
                WHERE a.QC_LBO_DATE BETWEEN $strTabPar1 AND 
                b.LBO_CATEGORY ='GOOD' AND
                a.QC_LBO_INSPECT_TYPE = 'N'
                GROUP BY a.QC_LBO_ID, a.QC_LBO_PLAN_ID UNION ALL
                
                SELECT a.QC_LBO_ID lboidx, a.QC_LBO_PLAN_ID planidx, SUM(a.QC_LBO_LOT) lotx, SUM(a.QC_LBO_SS) ssx, 0 goodx, 0 defx 
                FROM qc_lbo_input a WHERE a.QC_LBO_DATE BETWEEN $strTabPar1 AND a.QC_LBO_INSPECT_TYPE = 'N'
                GROUP BY a.QC_LBO_ID, a.QC_LBO_PLAN_ID
              ) a GROUP BY lboidx, planidx
            ) a WHERE chekx <> 0

          ) a GROUP BY a.PROD_ID
        ) b ON (REPLACE(CONCAT(CAST(A.PLAN_PROD_DATE AS CHAR), CAST(A.PLAN_PROD_LINE_CODE AS CHAR),
        CAST(A.PLAN_PROD_PART AS CHAR), CAST(A.PLAN_PROD_FLAG AS CHAR), CAST(A.PLAN_PROD_GROUP AS CHAR)),'-','')) = b.PROD_ID
        WHERE a.PLAN_PROD_DATE BETWEEN $strTabPar1
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
      ) a
      LEFT JOIN line b ON a.LINEC = b.LINE_CODE
      LEFT JOIN toy_part c ON a.PARTC = c.PART_NUM
      LEFT JOIN (
      ". $strSqlHc ."
      ) d on a.LINEC = d.LINEC
      LEFT JOIN (
      ". $strSqlFho ."
      ) e on a.LINEC = e.linex
      WHERE 1=1 "
      .(($unit !="" && $unit != "ALL") ? " AND b.LINE_PREF ='$unit' " : "").""
      .(($line !="" && $line != "ALL") ? " AND b.LINE_CODE ='$line' " : "").""
      .(($line_all !="") ? " AND b.LINE_CODE IN (" . $line_all . ")" : "") . "
      GROUP BY a.LINEC, b.LINE_PREF, b.LINE_DESC, b.LINE_NAME_SPV, 
      a.LINEC, a.PARTC, c.PART_NAME, a.FCH, a.GRP
      ORDER BY b.LINE_PREF, b.LINE_ORDR, a.GRP
    ";

    //var_dump($strSql);
    
  } else if ($section == 2) { //Quality Pef LBO

    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $cat = $_GET["cat"];

    $def = $_GET["def"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
    }

    //defect query
    $strSql = "SELECT * FROM defect_lbo a ORDER BY a.DEFECT_CAT, a.DEFECT_NAME ASC;";
    $strSqlDef = "";
    $strSqlDefSum = "";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $strSqlDef .= ", CASE WHEN b.LBO_DEFECT_CODE = ". $row['DEFECT_CODE']." THEN 1 ELSE 0 END `def".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_CODE']."`";
        $strSqlDefSum .= ", SUM(def".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_CODE'].") `def".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_CODE']."`";
      }
    }

    $strSql = "
      SELECT ga.*, gb.PART_NAME partnx, gb.PART_TYPE parttx, IFNULL(gc.LINE_DESC, gc.LINE_DESCX) linedx, gc.LINE_PREF prefx, gc.LINE_NAME_SPV leadx 
      FROM (
        SELECT linex, partx, COUNT(lotx) lotnx, SUM(lotx) lotx, 
        SUM(ssx) ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx, 
        SUM(deftx) deftx, SUM(accx) accx, SUM(rejx) rejx
        ".$strSqlDefSum." 
        FROM (
          SELECT MID(planidx, 9, 2) linex, sa.*, (defax + deffx) deftx, 
            CASE WHEN (defax + deffx) > sc.lbo_sampl_a THEN '0' ELSE '1' END accx,
            CASE WHEN (defax + deffx) > sc.lbo_sampl_a THEN '1' ELSE '0' END rejx
          FROM (
            SELECT lboidx, planidx, partx, iflagx, lotx, ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx
            ".$strSqlDefSum."
            FROM (
              SELECT
                a.QC_LBO_ID lboidx, a.QC_LBO_PLAN_ID planidx, a.QC_LBO_PART partx,
                a.QC_LBO_INSPECT_TYPE iflagx, a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx,
                CASE WHEN b.LBO_CATEGORY = 'GOOD' THEN 1 ELSE 0 END goodx, 
                CASE WHEN c.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END defax, 
                CASE WHEN c.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END deffx
                ". $strSqlDef ."
              FROM qc_lbo_input a 
              LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
              LEFT JOIN defect_lbo c ON b.LBO_DEFECT_CODE = c.DEFECT_CODE
              WHERE a.QC_LBO_DATE BETWEEN $strTabPar1 
              ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND a.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
              ".(($def !="" && $def != "ALL") ? " AND b.LBO_DEFECT_CODE ='$def' " : "")."
              AND a.QC_LBO_INSPECT_TYPE = 'N'
            ) a GROUP BY lboidx, planidx, partx, iflagx, lotx, ssx
          ) sa 
          LEFT JOIN toy_part sb ON sa.partx = sb.PART_NUM
          LEFT JOIN qc_lbo_smpl sc ON IFNULL(sc.lbo_smpl_ins, 'N') = sa.iflagx  AND sc.lbo_smpl_type = IFNULL(sb.PART_TYPE, 'MNL')
          AND sa.lotx BETWEEN sc.lbo_smpl_lot_size_min AND sc.lbo_smpl_lot_size_max
          WHERE (goodx + defax + deffx) <> 0"
          .(($cat !="" && $cat != "ALL") ? " AND sb.PART_TYPE ='$cat' " : "")."
        ) sa 
        GROUP BY linex, partx
      ) ga 
      LEFT JOIN toy_part gb ON ga.partx = gb.PART_NUM
      LEFT JOIN line gc ON ga.linex = gc.LINE_CODE
      WHERE 1=1 "
      .(($unit !="" && $unit != "ALL") ? " AND gc.LINE_PREF ='$unit' " : "").""
      .(($line !="" && $line != "ALL") ? " AND gc.LINE_CODE ='$line' " : "").""
      .(($line_all !="") ? " AND gc.LINE_CODE IN (" . $line_all . ")" : "") . "
      ORDER BY gc.LINE_PREF, gc.LINE_ORDR, gb.PART_NUM
    ";
    //var_dump($strSql);
  } else if ($section == 3) { //Quality Pef TTI

    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $cat = $_GET["cat"];
    $style = '';

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
    }

    $strSql = "
    SELECT c.LINE_PREF unitx, c.LINE_CODE linex, c.LINE_DESC linedx, 
      c.LINE_NAME_SPV leadx, d.PART_NUM partx, d.PART_NAME partdx, d.PART_TYPE parttx,
      b.PLAN_PROD_GROUP_ORD groupx, 
      SUM(a.DEF_QTY_1) DEF_QTY_1, SUM(a.DEF_QTY_2) DEF_QTY_2, SUM(a.DEF_QTY_3) DEF_QTY_3, SUM(a.DEF_QTY_4) DEF_QTY_4, SUM(a.DEF_QTY_5) DEF_QTY_5, SUM(a.DEF_QTY_6) DEF_QTY_6, SUM(a.DEF_QTY_7) DEF_QTY_7, 
      (SUM(a.DEF_QTY_1) + SUM(a.DEF_QTY_2) + SUM(a.DEF_QTY_3) + SUM(a.DEF_QTY_4) + SUM(a.DEF_QTY_5) + SUM(a.DEF_QTY_6) + SUM(a.DEF_QTY_7)) DEF_TOT,
      (SUM(a.DEF_QTY_1) + SUM(a.DEF_QTY_2) + SUM(a.DEF_QTY_3) + SUM(a.DEF_QTY_4) + SUM(a.DEF_QTY_5) + SUM(a.DEF_QTY_6) + SUM(a.DEF_QTY_7)) + SUM(a.REJ_QTY) + SUM(a.PRD_QTY) CHK_QTY,
      SUM(a.REJ_QTY) REJ_QTY, SUM(a.PRD_QTY) PRD_QTY
    FROM (
      SELECT a.OUT_PLAN_ID, 
        SUM(DEF_QTY_1) DEF_QTY_1, 
        SUM(DEF_QTY_2) DEF_QTY_2, 
        SUM(DEF_QTY_3) DEF_QTY_3,
        SUM(DEF_QTY_4) DEF_QTY_4, 
        SUM(DEF_QTY_5) DEF_QTY_5, 
        SUM(DEF_QTY_6) DEF_QTY_6,
        SUM(DEF_QTY_7) DEF_QTY_7,
        SUM(REJ_QTY) REJ_QTY, 
        SUM(PRD_QTY) PRD_QTY 
      FROM (
        SELECT a.OUT_PLAN_ID, 
          IF(a.OUT_DEF_CODE = 1, SUM(a.OUT_DEF_QTY), 0) DEF_QTY_1, 
          IF(a.OUT_DEF_CODE = 2, SUM(a.OUT_DEF_QTY), 0) DEF_QTY_2,
          IF(a.OUT_DEF_CODE = 3, SUM(a.OUT_DEF_QTY), 0) DEF_QTY_3,
          IF(a.OUT_DEF_CODE = 4, SUM(a.OUT_DEF_QTY), 0) DEF_QTY_4,
          IF(a.OUT_DEF_CODE = 5, SUM(a.OUT_DEF_QTY), 0) DEF_QTY_5,
          IF(a.OUT_DEF_CODE = 6, SUM(a.OUT_DEF_QTY), 0) DEF_QTY_6,
          IF(a.OUT_DEF_CODE = 7, SUM(a.OUT_DEF_QTY), 0) DEF_QTY_7,
          0 REJ_QTY, 0 PRD_QTY   
        FROM output_prod_defect a 
        WHERE a.OUT_DEF_DATE BETWEEN $strTabPar1 AND IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D'"
        .(($line !="" && $line != "ALL") ? " AND a.OUT_DEF_LINE_CODE ='$line' " : "").""
        .(($style !="" && $style != "ALL") ? " AND UCASE(a.OUT_DEF_PART) = '$style'" : "")."
        GROUP BY a.OUT_PLAN_ID, a.OUT_DEF_CODE UNION ALL
        
        SELECT a.OUT_PLAN_ID, 0 DEF_QTY_1, 0 DEF_QTY_2, 0 DEF_QTY_3, 0 DEF_QTY_4, 0 DEF_QTY_5, 0 DEF_QTY_6, 0 DEF_QTY_7, 0 REJ_QTY, SUM(a.OUT_PROD_QTY) PRD_QTY 
        FROM output_prod_good a 
        WHERE a.OUT_PROD_DATE BETWEEN $strTabPar1 AND IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D'"
        .(($line !="" && $line != "ALL") ? " AND a.OUT_PROD_LINE_CODE ='$line' " : "").""
        .(($style !="" && $style != "ALL") ? " AND UCASE(a.OUT_PROD_PART) = '$style'" : "")."
        GROUP BY a.OUT_PLAN_ID UNION ALL
        
        SELECT a.OUT_PLAN_ID, 0 DEF_QTY_1, 0 DEF_QTY_2, 0 DEF_QTY_3, 0 DEF_QTY_4, 0 DEF_QTY_5, 0 DEF_QTY_6, 0 DEF_QTY_7, SUM(a.OUT_REJ_QTY) REJ_QTY, 0 PRD_QTY   
        FROM output_prod_reject a 
        WHERE a.OUT_REJ_DATE BETWEEN $strTabPar1 AND IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D'"
        .(($line !="" && $line != "ALL") ? " AND a.OUT_REJ_LINE_CODE ='$line' " : "").""
        .(($style !="" && $style != "ALL") ? " AND UCASE(a.OUT_REJ_PART) = '$style'" : "")."
        GROUP BY a.OUT_PLAN_ID
      ) a GROUP BY OUT_PLAN_ID
    ) a 
    LEFT JOIN plan_prod_daily b ON a.OUT_PLAN_ID = (
      REPLACE(CONCAT(CAST(b.PLAN_PROD_DATE AS CHAR), 
      CAST(b.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(b.PLAN_PROD_PART AS CHAR), 
      CAST(b.PLAN_PROD_FLAG AS CHAR), 
      CAST(b.PLAN_PROD_GROUP AS CHAR)),'-','')
    )
    LEFT JOIN line c ON b.PLAN_PROD_LINE_CODE = c.LINE_CODE
    LEFT JOIN toy_part d ON b.PLAN_PROD_PART = d.PART_NUM
    WHERE b.PLAN_PROD_DATE BETWEEN $strTabPar1
    ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND b.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE").""
    .(($line !="" && $line != "ALL") ? " AND b.PLAN_PROD_LINE_CODE ='$line' " : "").""
    .(($style !="" && $style != "ALL") ? " AND UCASE(b.PLAN_PROD_PART) = '$style'" : "")
    .(($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "").""
    .(($cat !="" && $cat != "ALL") ? " AND d.PART_TYPE ='$cat' " : "").""
    .(($line_all !="") ? " AND b.PLAN_PROD_LINE_CODE IN (" . $line_all . ")" : "") . "
    GROUP BY c.LINE_PREF, c.LINE_CODE, c.LINE_DESC, 
      c.LINE_NAME_SPV, d.PART_NUM, d.PART_NAME,
      b.PLAN_PROD_GROUP_ORD
    ORDER BY c.LINE_PREF, c.LINE_ORDR, b.PLAN_PROD_GROUP_ORD;
    ";

    //echo $strSql;
  } else if ($section == 4) { //Quality pef Period
    
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $cat = $_GET["cat"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    $strGrouph = "SELECT datex, SUM(lotx) lotx, SUM(ssx) ssx, SUM(goodx) goodx, SUM(defx) defx, SUM(rejx) rejx, SUM(defax) defax, SUM(deffx) deffx ";
    $strGroupd = "GROUP BY datex";

    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
      $strGrouph = "SELECT MONTH(datex) datex, SUM(lotx) lotx, SUM(ssx) ssx, SUM(goodx) goodx, SUM(defx) defx, SUM(rejx) rejx, SUM(defax) defax, SUM(deffx) deffx ";
      $strGroupd = "GROUP BY MONTH(datex)";
    }

    //sql date
    $strSql = "
    SELECT sa.*
    FROM (
      ".$strGrouph."
      FROM (
        SELECT idx, datex, linex, groupx, partx, lotx, ssx, SUM(goodx) goodx, SUM(defx) defx, SUM(rejx) rejx, SUM(defax) defax, SUM(deffx) deffx
        FROM (
          SELECT b.QC_LBO_ID idx, b.QC_LBO_DATE datex, b.QC_LBO_LINE linex, IFNULL(b.QC_LBO_GROUP,'') groupx, b.QC_LBO_PART partx, b.QC_LBO_LOT lotx, b.QC_LBO_SS ssx, 
            CASE WHEN a.LBO_CATEGORY = 'GOOD' THEN 1 ELSE 0 END goodx,
            CASE WHEN a.LBO_CATEGORY = 'DEFECT' THEN 1 ELSE 0 END defx,
            CASE WHEN a.LBO_CATEGORY = 'REJECT'	 THEN 1 ELSE 0 END rejx,
            CASE WHEN c.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END defax,
            CASE WHEN c.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END deffx 
          FROM qc_lbo_input_detail a 
          LEFT JOIN qc_lbo_input b ON a.QC_LBO_ID = b.QC_LBO_ID
          LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
          LEFT JOIN line d ON b.QC_LBO_LINE = d.LINE_CODE
          LEFT JOIN toy_part e ON b.QC_LBO_PART = e.PART_NUM
          WHERE b.QC_LBO_DATE BETWEEN $strTabPar1
          ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND b.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
          AND IFNULL(b.QC_LBO_INSPECT_TYPE,'N') = 'N' "
          .(($unit !="" && $unit != "ALL") ? " AND d.LINE_PREF ='$unit' " : "").""
          .(($line !="" && $line != "ALL") ? " AND d.LINE_CODE ='$line' " : "").""
          .(($cat !="" && $cat != "ALL") ? " AND e.PART_TYPE ='$cat' " : "").""
          .(($line_all !="") ? " AND d.LINE_CODE IN (" . $line_all . ")" : "") . "
        ) a GROUP BY idx, datex, linex, groupx, partx, lotx, ssx
      ) a 
      ".$strGroupd."
    ) sa 
    WHERE 1=1 
    ORDER BY sa.datex;
    ";
  
  } else if ($section == 5) { //Prod pef period
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $cat = $_GET["cat"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    $strGrouph = "SELECT datex, linex, linedx, leadx, unitx, ordx, SUM(pehx) pehx, SUM(pahx) pahx, SUM(aehx) aehx, SUM(aahx) aahx ";
    $strGroupd = "GROUP BY datex, linex, linedx, leadx, unitx, ordx";

    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
      $strTabPar2 = "'". str_replace('-', '', $date_f)."' AND '". str_replace('-', '', $date_t)."'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
      $strTabPar2 = "REPLACE(DATE_ADD('$week_t', INTERVAL -6 DAY),'-','') AND '". str_replace('-', '', $week_t)."'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
      $strTabPar2 = "'".$year."".$month."01' AND '".$year."".$month."31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
      $strTabPar2 = "'".$year."0101' AND '".$year."1231'";
      $strGrouph = "SELECT MONTH(datex) datex, linex, linedx, leadx, unitx, ordx, SUM(pehx) pehx, SUM(pahx) pahx, SUM(aehx) aehx, SUM(aahx) aahx ";
      $strGroupd = "GROUP BY MONTH(datex), linex, linedx, leadx, unitx, ordx";
    }

    $strSql = "
    $strGrouph 
    FROM (
      SELECT sa.*, IFNULL(sb.LINE_DESC, sb.LINE_DESCX) linedx, sb.LINE_NAME_SPV leadx, sb.LINE_PREF unitx, sb.LINE_ORDR ordx, (fchx*pqtyx)/1000 pehx, (phcx * pwhx) pahx, (fchx * aqtyx)/1000 aehx, (ahcx * rawhx) aahx
      FROM (
        SELECT sa.*, CASE WHEN pwhx < 1 THEN pwhx ELSE awhx END rawhx 
        FROM (
          SELECT plan_idx, datex, GROUP_CONCAT(linex) linex, GROUP_CONCAT(groupx) groupx, GROUP_CONCAT(partx) partx, 
            SUM(fchx) fchx, SUM(phcx) phcx, SUM(peffx) peffx, SUM(pwhx) pwhx, SUM(pqtyx) pqtyx, SUM(awhx) awhx, SUM(aqtyx) aqtyx, SUM(ahcx) ahcx, SUM(fawhx) fawhx
          FROM (
          SELECT
            (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
            CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) plan_idx,
            a.PLAN_PROD_DATE datex, 
            a.PLAN_PROD_LINE_CODE linex,
            IFNULL(a.PLAN_PROD_GROUP_ORD, '') groupx, 
            a.PLAN_PROD_PART partx, 
            a.PLAN_PROD_FCH fchx, 
            a.PLAN_PROD_OPT phcx, 
            a.PLAN_PROD_EFF peffx, 
            a.PLAN_PROD_WH pwhx,
            a.PLAN_PROD_QTY pqtyx,
            0 awhx, 0 aqtyx, 0 ahcx, 0 fawhx
          FROM plan_prod_daily a 
          WHERE a.PLAN_PROD_DATE 
          BETWEEN $strTabPar1 UNION ALL
          
          SELECT plan_idx, datex, NULL linex, NULL groupx, NULL partx, 0 fpchx, 0 phcx, 0 peffx, 0 pwhx, 0 pqtyx, 
            CASE WHEN HOUR(TIMEDIFF(max_out, min_out)) = 0 THEN 1 ELSE HOUR(TIMEDIFF(max_out, min_out)) END awhx, aqtyx, 0 ahcx, HOUR(min_out) fawhx
          FROM (
          SELECT a.OUT_PLAN_ID plan_idx, 
          a.OUT_PROD_DATE datex, MIN(a.OUT_PROD_TIME) min_out, MAX(a.OUT_PROD_TIME) max_out, SUM(OUT_PROD_QTY) aqtyx 
          FROM output_prod_good a WHERE a.OUT_PROD_DATE BETWEEN $strTabPar1 AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
          GROUP BY OUT_PLAN_ID
          ) a UNION ALL
          
          SELECT a.PLAN_ID plan_idx, 
            CAST(CONCAT(LEFT(a.PLAN_ID, 4), '-', MID(a.PLAN_ID, 5, 2), '-', MID(a.PLAN_ID, 7, 2)) AS DATE) datex,
            NULL linex, NULL groupx, NULL partx, 0 fpchx, 0 phcx, 0 peffx, 0 pwhx, 0 pqtyx, 0 awhx, 0 aqtyx, 
            a.OUT_PROD_GOOD_AHC ahcx, 0 fawhx 
          FROM output_prod_good_hc a WHERE LEFT(a.PLAN_ID,8) BETWEEN $strTabPar2
          ) sa GROUP BY plan_idx
        ) sa
      ) sa LEFT JOIN line sb on sa.linex = sb.LINE_CODE 
      WHERE IFNULL(sa.linex,'') <> ''"
      .(($unit !="" && $unit != "ALL") ? " AND sb.LINE_PREF ='$unit' " : "").""
      .(($line !="" && $line != "ALL") ? " AND sb.LINE_CODE ='$line' " : "").""
      .(($line_all !="") ? " AND sb.LINE_CODE IN (" . $line_all . ")" : "") . "
    ) sa $strGroupd
    ORDER BY unitx, ordx;
    ";
  
  } else if ($section == 6) { //audit - sharp tools
    
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];
    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    $strGrouph = "";
    $strGroupd = "ORDER BY unitx, ordx, leadx";

    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
    }

    $strSql = "
    $strGrouph
    SELECT datex, linex, unitx, 
    CASE 
      WHEN linex = 'A1' THEN 'IC' 
      WHEN linex = 'A2' THEN 'MECHANIC'
      WHEN linex = 'A3' THEN 'PACKING (FC)'
      ELSE linedx
    END linedx, 
    leadx, acn, 
    a1y, b1y, c1y, d1y, a1n, b1n, c1n, d1n, IFNULL(r1, '') r1, 
    a2y, b2y, c2y, d2y, a2n, b2n, c2n, d2n, IFNULL(r2, '') r2 
    FROM (
      SELECT datex, linex, IFNULL(sb.LINE_PREF, 'C') unitx, sb.LINE_DESC linedx, IFNULL(sb.LINE_ORDR, 100) ordx, leadx, SUM(acn) acn, 
        SUM(a1y) a1y, SUM(b1y) b1y, SUM(c1y) c1y, SUM(d1y) d1y, SUM(a1n) a1n, SUM(b1n) b1n, SUM(c1n) c1n, SUM(d1n) d1n, GROUP_CONCAT(r1 SEPARATOR '<br>') r1,
        SUM(a2y) a2y, SUM(b2y) b2y, SUM(c2y) c2y, SUM(d2y) d2y, SUM(a2n) a2n, SUM(b2n) b2n, SUM(c2n) c2n, SUM(d2n) d2n, GROUP_CONCAT(r2 SEPARATOR '<br>') r2
      FROM (
        SELECT a.audit_date datex, a.audit_line linex, a.audit_lead leadx, a.audit_group groupx, a.audit_part partx, a.audit_part_name partnx, 1 acn, 
          IFNULL(a.audit_value_y, 0) a1y, IFNULL(a.audit_value_n, 0) a1n, 
          IFNULL(a.audit_value_y2, 0) a2y, IFNULL(a.audit_value_n2,0) a2n, 
          0 b1y, 0 b1n, 0 b2y, 0 b2n,
          0 c1y, 0 c1n, 0 c2y, 0 c2n, 
          0 d1y, 0 d1n, 0 d2y, 0 d2n, 
          CASE WHEN TRIM(a.audit_remark) = '' THEN NULL ELSE TRIM(a.audit_remark) END r1,
          CASE WHEN TRIM(a.audit_remark2) = '' THEN NULL ELSE TRIM(a.audit_remark2) END r2   
        FROM audit_sharp_tools a 
        WHERE a.audit_date BETWEEN $strTabPar1 AND a.audit_code = 'A' UNION ALL
        
        SELECT a.audit_date, a.audit_line, a.audit_lead, a.audit_group, a.audit_part, a.audit_part_name, 0 acn,
          0 a1y, 0 a1n, 0 a2y, 0 a2n,
          IFNULL(a.audit_value_y, 0) b1y, IFNULL(a.audit_value_n, 0) b1n,  
          IFNULL(a.audit_value_y2, 0) b2y, IFNULL(a.audit_value_n2,0) b2n, 
          0 c1y, 0 c1n, 0 c2y, 0 c2n, 
          0 d1y, 0 d1n, 0 d2y, 0 d2n,
          CASE WHEN TRIM(a.audit_remark) = '' THEN NULL ELSE TRIM(a.audit_remark) END a1r,
          CASE WHEN TRIM(a.audit_remark2) = '' THEN NULL ELSE TRIM(a.audit_remark2) END a2r 
        FROM audit_sharp_tools a 
        WHERE a.audit_date BETWEEN $strTabPar1 AND a.audit_code = 'B' UNION ALL	
        
        SELECT a.audit_date, a.audit_line, a.audit_lead, a.audit_group, a.audit_part, a.audit_part_name, 0 acn,
          0 a1y, 0 a1n, 0 a2y, 0 a2n, 
          0 b1y, 0 b1n, 0 b2y, 0 b2n, 
          IFNULL(a.audit_value_y, 0) c1y, IFNULL(a.audit_value_n, 0) c1n,
          IFNULL(a.audit_value_y2, 0) c2y, IFNULL(a.audit_value_n2,0) c2n,
          0 d1y, 0 d1n, 0 d2y, 0 d2n,
          CASE WHEN TRIM(a.audit_remark) = '' THEN NULL ELSE TRIM(a.audit_remark) END a1r,
          CASE WHEN TRIM(a.audit_remark2) = '' THEN NULL ELSE TRIM(a.audit_remark2) END a2r 
        FROM audit_sharp_tools a 
        WHERE a.audit_date BETWEEN $strTabPar1 AND a.audit_code = 'C' UNION ALL	
        
        SELECT a.audit_date, a.audit_line, a.audit_lead, a.audit_group, a.audit_part, a.audit_part_name, 0 acn,
          0 a1y, 0 a1n, 0 a2y, 0 a2n, 
          0 b1y, 0 b1n, 0 b2y, 0 b2n,
          0 c1y, 0 c1n, 0 c2y, 0 c2n, 
          IFNULL(a.audit_value_y, 0) d1y, IFNULL(a.audit_value_n, 0) d1n,
          IFNULL(a.audit_value_y2, 0) d2y, IFNULL(a.audit_value_n2,0) d2n,
          CASE WHEN TRIM(a.audit_remark) = '' THEN NULL ELSE TRIM(a.audit_remark) END a1r,
          CASE WHEN TRIM(a.audit_remark2) = '' THEN NULL ELSE TRIM(a.audit_remark2) END a2r  
        FROM audit_sharp_tools a 
        WHERE a.audit_date BETWEEN $strTabPar1 AND a.audit_code = 'D'
      ) sa LEFT JOIN line sb ON sa.linex = sb.LINE_CODE
      WHERE 1=1 "
      .($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND sa.datex NOT IN $GLOB_AUDIT_DATE").""
      .(($unit !="" && $unit != "ALL") ? " AND sb.LINE_PREF ='$unit' " : "").""
      .(($line !="" && $line != "ALL") ? " AND sb.LINE_CODE ='$line' " : "").""
      .(($line_all !="") ? " AND sb.LINE_CODE IN (" . $line_all . ")" : "") . "
      GROUP BY datex, linex, sb.LINE_PREF, sb.LINE_DESC, sb.LINE_ORDR, leadx
    ) sa 
    WHERE (a1y + b1y + c1y + d1y + a2y + b2y + c2y + d2y) <> 0 
    $strGroupd
    ";

  } else if ($section == 7) { //audit - sharp tools period
    
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];
    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];

    $week_t = $year .'-'. str_replace('/', '-', $week);
    
    $strTabPar1 = "";
    $strTabPar2 = "";
    $strGrouph = '';
    $strGroupd = '';

    if ($line != '' && $line != 'ALL') {
      $strGrouph = "
      SELECT datex, linex, leadx, SUM(acn) acn, 
        SUM(a1y) a1y, SUM(b1y) b1y, SUM(c1y) c1y, SUM(d1y) d1y,
        SUM(a1n) a1n, SUM(b1n) b1n, SUM(c1n) c1n, SUM(d1n) d1n, 
        SUM(a2y) a2y, SUM(b2y) b2y, SUM(c2y) c2y, SUM(d2y) d2y,
        SUM(a2n) a2n, SUM(b2n) b2n, SUM(c2n) c2n, SUM(d2n) d2n
      FROM (
      ";
      $strGroupd = "
      ) sa 
      GROUP BY datex, linex, leadx
      ORDER BY linex, leadx, datex
      ";
    } else {
      $strGrouph = "
      SELECT datex, SUM(acn) acn, 
        SUM(a1y) a1y, SUM(b1y) b1y, SUM(c1y) c1y, SUM(d1y) d1y,
        SUM(a1n) a1n, SUM(b1n) b1n, SUM(c1n) c1n, SUM(d1n) d1n, 
        SUM(a2y) a2y, SUM(b2y) b2y, SUM(c2y) c2y, SUM(d2y) d2y,
        SUM(a2n) a2n, SUM(b2n) b2n, SUM(c2n) c2n, SUM(d2n) d2n
      FROM (
      ";
      $strGroupd = "
      ) sa 
      GROUP BY datex
      ORDER BY datex
      ";
    }

    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
      if ($line != '' && $line != 'ALL') {
        $strGrouph = "
        SELECT MONTH(datex) datex, linex, leadx, SUM(acn) acn, 
          SUM(a1y) a1y, SUM(b1y) b1y, SUM(c1y) c1y, SUM(d1y) d1y,
          SUM(a1n) a1n, SUM(b1n) b1n, SUM(c1n) c1n, SUM(d1n) d1n, 
          SUM(a2y) a2y, SUM(b2y) b2y, SUM(c2y) c2y, SUM(d2y) d2y,
          SUM(a2n) a2n, SUM(b2n) b2n, SUM(c2n) c2n, SUM(d2n) d2n
        FROM (
        ";
        $strGroupd = "
        ) sa 
        GROUP BY MONTH(datex), linex, leadx
        ORDER BY linex, leadx, datex
        ";
      } else {
        $strGrouph = "
        SELECT MONTH(datex) datex, SUM(acn) acn, 
          SUM(a1y) a1y, SUM(b1y) b1y, SUM(c1y) c1y, SUM(d1y) d1y,
          SUM(a1n) a1n, SUM(b1n) b1n, SUM(c1n) c1n, SUM(d1n) d1n, 
          SUM(a2y) a2y, SUM(b2y) b2y, SUM(c2y) c2y, SUM(d2y) d2y,
          SUM(a2n) a2n, SUM(b2n) b2n, SUM(c2n) c2n, SUM(d2n) d2n
        FROM (
        ";
        $strGroupd = "
        ) sa 
        GROUP BY MONTH(datex)
        ORDER BY datex
        ";
      }
    }

    $strSql = "
    $strGrouph
      SELECT datex, linex, unitx, 
      CASE 
        WHEN linex = 'A1' THEN 'IC' 
        WHEN linex = 'A2' THEN 'MECHANIC'
        WHEN linex = 'A3' THEN 'PACKING (FC)'
        ELSE linedx
      END linedx, 
      leadx, acn, a1y, b1y, c1y, d1y, a1n, b1n, c1n, d1n, IFNULL(r1, '') r1, a2y, b2y, c2y, d2y, a2n, b2n, c2n, d2n, IFNULL(r2, '') r2 
      FROM (
        SELECT datex, linex, IFNULL(sb.LINE_PREF, 'C') unitx, sb.LINE_DESC linedx, IFNULL(sb.LINE_ORDR, 100) ordx, leadx, SUM(acn) acn, 
          SUM(a1y) a1y, SUM(b1y) b1y, SUM(c1y) c1y, SUM(d1y) d1y, SUM(a1n) a1n, SUM(b1n) b1n, SUM(c1n) c1n, SUM(d1n) d1n, GROUP_CONCAT(r1 SEPARATOR '<br>') r1,
          SUM(a2y) a2y, SUM(b2y) b2y, SUM(c2y) c2y, SUM(d2y) d2y, SUM(a2n) a2n, SUM(b2n) b2n, SUM(c2n) c2n, SUM(d2n) d2n, GROUP_CONCAT(r2 SEPARATOR '<br>') r2
        FROM (
          SELECT a.audit_date datex, a.audit_line linex, a.audit_lead leadx, a.audit_group groupx, a.audit_part partx, a.audit_part_name partnx, 1 acn, 
            IFNULL(a.audit_value_y, 0) a1y, IFNULL(a.audit_value_n, 0) a1n, 
            IFNULL(a.audit_value_y2, 0) a2y, IFNULL(a.audit_value_n2,0) a2n, 
            0 b1y, 0 b1n, 0 b2y, 0 b2n,
            0 c1y, 0 c1n, 0 c2y, 0 c2n, 
            0 d1y, 0 d1n, 0 d2y, 0 d2n, 
            CASE WHEN TRIM(a.audit_remark) = '' THEN NULL ELSE TRIM(a.audit_remark) END r1,
            CASE WHEN TRIM(a.audit_remark2) = '' THEN NULL ELSE TRIM(a.audit_remark2) END r2   
          FROM audit_sharp_tools a 
          WHERE a.audit_date BETWEEN $strTabPar1 AND a.audit_code = 'A' UNION ALL
          
          SELECT a.audit_date, a.audit_line, a.audkt_lead, a.audit_group, a.audit_part, a.audit_part_name, 0 acn,
            0 a1y, 0 a1n, 0 a2y, 0 a2n,
            IFNULL(a.audit_value_y, 0) b1y, IFNULL(a.audit_value_n, 0) b1n,  
            IFNULL(a.audit_value_y2, 0) b2y, IFNULL(a.audit_value_n2,0) b2n, 
            0 c1y, 0 c1n, 0 c2y, 0 c2n, 
            0 d1y, 0 d1n, 0 d2y, 0 d2n,
            CASE WHEN TRIM(a.audit_remark) = '' THEN NULL ELSE TRIM(a.audit_remark) END a1r,
            CASE WHEN TRIM(a.audit_remark2) = '' THEN NULL ELSE TRIM(a.audit_remark2) END a2r 
          FROM audit_sharp_tools a 
          WHERE a.audit_date BETWEEN $strTabPar1 AND a.audit_code = 'B' UNION ALL	
          
          SELECT a.audit_date, a.audit_line, a.audit_lead, a.audit_group, a.audit_part, a.audit_part_name, 0 acn,
            0 a1y, 0 a1n, 0 a2y, 0 a2n, 
            0 b1y, 0 b1n, 0 b2y, 0 b2n, 
            IFNULL(a.audit_value_y, 0) c1y, IFNULL(a.audit_value_n, 0) c1n,
            IFNULL(a.audit_value_y2, 0) c2y, IFNULL(a.audit_value_n2,0) c2n,
           0 d1y, 0 d1n, 0 d2y, 0 d2n,
            CASE WHEN TRIM(a.audit_remark) = '' THEN NULL ELSE TRIM(a.audit_remark) END a1r,
            CASE WHEN TRIM(a.audit_remark2) = '' THEN NULL ELSE TRIM(a.audit_remark2) END a2r 
          FROM audit_sharp_tools a 
          WHERE a.audit_date BETWEEN $strTabPar1 AND a.audit_code = 'C' UNION ALL	
          
          SELECT a.audit_date, a.audit_line, a.audit_lead, a.audit_group, a.audit_part, a.audit_part_name, 0 acn,
            0 a1y, 0 a1n, 0 a2y, 0 a2n, 
            0 b1y, 0 b1n, 0 b2y, 0 b2n,
            0 c1y, 0 c1n, 0 c2y, 0 c2n, 
            IFNULL(a.audit_value_y, 0) d1y, IFNULL(a.audit_value_n, 0) d1n,
            IFNULL(a.audit_value_y2, 0) d2y, IFNULL(a.audit_value_n2,0) d2n,
            CASE WHEN TRIM(a.audit_remark) = '' THEN NULL ELSE TRIM(a.audit_remark) END a1r,
            CASE WHEN TRIM(a.audit_remark2) = '' THEN NULL ELSE TRIM(a.audit_remark2) END a2r  
          FROM audit_sharp_tools a 
          WHERE a.audit_date BETWEEN $strTabPar1 AND a.audit_code = 'D'
        ) sa LEFT JOIN line sb ON sa.linex = sb.LINE_CODE
        WHERE 1=1 "
        .($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND sa.datex NOT IN $GLOB_AUDIT_DATE").""
        .(($unit !="" && $unit != "ALL") ? " AND sb.LINE_PREF ='$unit' " : "").""
        .(($line !="" && $line != "ALL") ? " AND sb.LINE_CODE ='$line' " : "").""
        .(($line_all !="") ? " AND sb.LINE_CODE IN (" . $line_all . ")" : "") . "
        GROUP BY datex, linex, sb.LINE_PREF, sb.LINE_DESC, sb.LINE_ORDR, leadx
      ) sa 
      WHERE (a1y + b1y + c1y + d1y + a2y + b2y + c2y + d2y) <> 0 
    $strGroupd
    ";

  
  } else if ($section == 8) { //summary transfer
    
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $date_type = $_GET["date_type"];


    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
      $date = $date_f;
      $date_to = $date_t;
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
      $date = date('Y-m-d', strtotime($week_t . ' -6 day'));
      $date_to = $week_t;
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
      $date = "$year-$month-01";
      $date_to = date('Y-m-t', strtotime($date));
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
    }

    $sqlh1 = 'SELECT sb.LINE_PREF unitx, linex, sb.LINE_DESC linedx, partx, sc.PART_NAME partdx, sc.PART_FCH_BUYER fchx, groupx, SUM(planx) planx, SUM(admx) admx, SUM(tlbox) tlbox, SUM(tfcx) tfcx';
    $sqlh2 = 'SELECT linex, partx, groupx, IFNULL(planx, 0) planx, IFNULL(admx, 0) admx, IFNULL(tlbox, 0) tlbox, IFNULL(tfcx, 0) tfcx';

    while ($date <= $date_to)
    {
      $sqlh1 .= "
      , SUM(`" . str_replace('-', '_', $date) . "_pl`) `D_" . str_replace('-', '_', $date) . "_pl`
      , SUM(`" . str_replace('-', '_', $date) . "_ad`) `D_" . str_replace('-', '_', $date) . "_ad`
      , SUM(`" . str_replace('-', '_', $date) . "_tl`) `D_" . str_replace('-', '_', $date) . "_tl`
      , SUM(`" . str_replace('-', '_', $date) . "_tf`) `D_" . str_replace('-', '_', $date) . "_tf`";
      $sqlh2 .= "
        , CASE WHEN datex='$date' THEN IFNULL(planx, 0) END `" . str_replace('-', '_', $date) . "_pl`, CASE WHEN datex='$date' THEN IFNULL(admx, 0) END `" . str_replace('-', '_', $date) . "_ad`
        , CASE WHEN datex='$date' THEN IFNULL(tlbox, 0) END `" . str_replace('-', '_', $date) . "_tl`, CASE WHEN datex='$date' THEN IFNULL(tfcx, 0) END `" . str_replace('-', '_', $date) . "_tf`";
      $date = date('Y-m-d', strtotime($date . ' +1 day'));
    }

    $str_tf = "";
    if ($date_type == 'T'){
      $str_tf = "
        SELECT a.PACK_STOCK_DATE, a.PACK_STOCK_LINE, a.PACK_STOCK_PART, IFNULL(a.PACK_STOCK_GROUP,''), 0 planx, 0 admx, 0 lbox, SUM(a.PACK_STOCK_QTY) fcx 
        FROM pack_stock_tf_group a 
        WHERE a.PACK_STOCK_DATE BETWEEN $strTabPar1
        AND a.PACK_STOCK_LINE NOT IN ('41','42')
        GROUP BY a.PACK_STOCK_DATE, a.PACK_STOCK_LINE, a.PACK_STOCK_PART, a.PACK_STOCK_GROUP
      ";  
    } else {
      $str_tf = "
      SELECT a.SCAN_BRCD_DATE, a.SCAN_LINE, a.SCAN_PART, groupx, 0 planx, 0 admx, 0 lbox, SUM(fcx) fcx 
      FROM (
        SELECT a.SCAN_BRCD_DATE, a.SCAN_LINE, a.SCAN_PART, IFNULL(a.SCAN_GROUP,'') groupx, 0 planx, 0 admx, 0 lbox, CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(SCAN_ID,'.', 2),'.',-1) AS SIGNED) fcx 
        FROM pack_scan_tf a 
        WHERE a.SCAN_BRCD_DATE BETWEEN $strTabPar1
        AND a.SCAN_LINE NOT IN ('41','42')
      ) a GROUP BY a.SCAN_BRCD_DATE, a.SCAN_LINE, a.SCAN_PART, a.groupx
      ";
    }
 
    $strSql="
    $sqlh1
    FROM (
      $sqlh2
      FROM (
        SELECT datex, linex, partx, groupx, SUM(planx) planx, SUM(admx) admx, SUM(lbox) tlbox, SUM(fcx) tfcx 
        FROM (
          SELECT a.PLAN_PROD_DATE datex, a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_PART partx, IFNULL(a.PLAN_PROD_GROUP_ORD,'') groupx, SUM(a.PLAN_PROD_QTY) planx, 0 admx, 0 lbox, 0 fcx
          FROM plan_prod_daily a 
          WHERE a.PLAN_PROD_DATE BETWEEN $strTabPar1
          GROUP BY a.PLAN_PROD_DATE, a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_PART, IFNULL(a.PLAN_PROD_GROUP_ORD,'') UNION ALL
          
          #adm output
          SELECT a.OUT_PROD_DATE, a.OUT_PROD_LINE_CODE, a.OUT_PROD_PART, IFNULL(a.OUT_PROD_GROUP, ''), 0 planx, SUM(a.OUT_PROD_QTY) admx, 0 lbox, 0 fcx
          FROM output_prod_good a 
          WHERE a.OUT_PROD_DATE BETWEEN $strTabPar1
          AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
          GROUP BY a.OUT_PROD_DATE, a.OUT_PROD_LINE_CODE, a.OUT_PROD_PART, a.OUT_PROD_GROUP UNION ALL
          
          #transfer lbo
          SELECT ". ($date_type == "T" ? "a.transfer_date" : "a.transfer_barcode_date") .", a.transfer_line, a.transfer_part, IFNULL(a.transfer_group,''), 0 planx, 0 admx, SUM(a.transfer_qty) lbox, 0 fcx 
          FROM qc_lbo_transfer a 
          WHERE ". ($date_type == "T" ? "a.transfer_date" : "a.transfer_barcode_date") ." BETWEEN $strTabPar1
          AND a.transfer_line NOT IN ('41','42')
          GROUP BY ". ($date_type == "T" ? "a.transfer_date" : "a.transfer_barcode_date") .", a.transfer_line, a.transfer_part, a.transfer_group UNION ALL
          
          #transfer fc
          $str_tf
        ) sa 
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "WHERE sa.datex NOT IN $GLOB_AUDIT_DATE")." 
        GROUP BY datex, linex, partx, groupx
      ) sa WHERE (IFNULL(planx, 0) + IFNULL(admx, 0) + IFNULL(tlbox, 0) + IFNULL(tfcx, 0)) <> 0
    ) sa 
    LEFT JOIN line sb on sa.linex = sb.LINE_CODE
    LEFT JOIN toy_part sc on sa.partx = sc.PART_NUM
    WHERE 1=1 "
    .(($unit !="" && $unit != "ALL") ? " AND sb.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND sb.LINE_CODE ='$line' " : "").""
    .(($line_all !="") ? " AND sb.LINE_CODE IN (" . $line_all . ")" : "") . "
    GROUP BY sb.LINE_PREF, linex, sb.LINE_DESC, partx, sc.PART_NAME, sc.PART_FCH_BUYER, groupx
    ORDER BY sb.LINE_PREF, sb.LINE_ORDR, groupx, partx
    ";
    //echo '<pre>'. $strSql . '</pre>';

  } else if ($section == 9) { //MATERIAL INSPECT
    
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $vendor = $_GET["vendor"];
    $cat = $_GET["cat"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    $strGroup1 = "a.inspect_date";
    $strGroup2 = "a.inspect_date";

    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
      $strGroup1 = "MONTH(a.inspect_date)";
      $strGroup2 = "MONTH(a.inspect_date)";
    }

    $strSql ="
    SELECT $strGroup1 datex, IFNULL(a.inspect_style, 'N/A') stylex, IFNULL(c.PART_NAME, 'N/A') stylenx, a.inspect_vendor vendx, 
      a.inspect_pn matlx, b.MATL_NAME matlnx, a.inspect_qc_name qcnamex, 
      COUNT(a.inspect_lot) lotx, SUM(a.inspect_lot_qty) lotqx, SUM(a.pass_sort) lotsx, SUM(a.lot_sort) lotsqx,
      SUM(a.inspect_ss) ssx, SUM(a.inspect_reject) rejx, SUM(a.inspect_pass_qty) rejsx,
      SUM(a.inspect_def1) def1, SUM(a.inspect_def2) def2, SUM(a.inspect_def3) def3, SUM(a.inspect_def4) def4, SUM(a.inspect_def5) def5, SUM(a.inspect_def6) def6, SUM(a.inspect_def7) def7,
      SUM(a.inspect_def8) def8, SUM(a.inspect_def9) def9, SUM(a.inspect_def10) def10, SUM(a.inspect_def11) def11, SUM(a.inspect_def12) def12, SUM(a.inspect_def13) def13, SUM(a.inspect_def14) def14,
      SUM(a.inspect_def15) def15, SUM(a.inspect_def16) def16, SUM(a.inspect_def17) def17, SUM(a.inspect_def18) def18, SUM(a.inspect_def19) def19, SUM(a.inspect_def20) def20, SUM(a.inspect_def21) def21
    FROM (
      SELECT a.*, CASE WHEN a.inspect_pass = 'Y' THEN 0 ELSE a.inspect_lot_qty END lot_sort, CASE WHEN a.inspect_pass = 'Y' THEN 0 ELSE 1 END pass_sort
      FROM qc_matl_insp a 
      WHERE a.inspect_date BETWEEN $strTabPar1"
      .($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.inspect_date NOT IN $GLOB_AUDIT_DATE")."" 
      .(($vendor !="" && $vendor != "ALL") ? " AND a.inspect_vendor ='$vendor' " : "")."
    ) a 
    LEFT JOIN material b ON a.inspect_pn = b.MATL_CODE
    LEFT JOIN toy_part c ON a.inspect_style = c.PART_NUM"
    .(($cat !="" && $cat != "ALL") ? " AND c.PART_TYPE ='$cat' " : "")."
    GROUP BY $strGroup2, a.inspect_style, c.PART_NAME, a.inspect_vendor, a.inspect_pn, b.MATL_NAME, a.inspect_qc_name;
    ";
    
  } else if ($section == 10) { //MATERIAL INSPECTION PERIOD
    
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $vendor = $_GET["vendor"];
    $cat = $_GET["cat"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    $strGrouph = "SELECT vendx, datex, SUM(lotx) lotx, SUM(ssx) ssx, SUM(rejx) rejx";
    $strGroupd = "GROUP BY vendx, datex";

    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
      $strGrouph = "SELECT MONTH(datex) datex, vendx, SUM(lotx) lotx, SUM(ssx) ssx, SUM(rejx) rejx";
      $strGroupd = "GROUP BY vendx, MONTH(datex)";
    }

    //sql date
    $strSql = "
    SELECT sa.*
    FROM (
      ".$strGrouph."
      FROM (
        SELECT a.inspect_date datex, IFNULL(a.inspect_vendor, '') vendx, inspect_lot_qty lotx, inspect_ss ssx, inspect_reject rejx 
        FROM qc_matl_insp a 
        WHERE a.inspect_date BETWEEN $strTabPar1"
        .($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.inspect_date NOT IN $GLOB_AUDIT_DATE")."" 
        .(($vendor !="" && $vendor != "ALL") ? " AND a.inspect_vendor ='$vendor' " : "")."
      ) a 
      ".$strGroupd."
    ) sa 
    WHERE 1=1 
    ORDER BY sa.vendx, sa.datex;
    ";
    //echo '<pre>'. $strSql . '</pre>';
  } else if ($section == 11) { //PP STAGE INSPECTION
    
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $cat = $_GET["cat"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
    }

    //defect query
    $strSql = "SELECT * FROM defect_lbo a ORDER BY a.DEFECT_CAT, a.DEFECT_ORDER ASC;";
    $strSqlDef = "";
    $strSqlDefSum = "";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $strSqlDef .= ", CASE WHEN b.inspect_defect = ". $row['DEFECT_CODE']." THEN b.inspect_qty ELSE 0 END `def".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_CODE']."`";
        $strSqlDefSum .= ", SUM(def".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_CODE'].") `def".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_CODE']."`";
      }
    }

    $strSql = "
      SELECT ga.*, gb.PART_NAME partnx, gb.PART_TYPE parttx, IFNULL(gc.LINE_DESC, gc.LINE_DESCX) linedx, gc.LINE_PREF prefx, gc.LINE_NAME_SPV leadx 
      FROM (
        SELECT linex, partx, COUNT(lotx) lotnx, SUM(lotx) lotx, 
        SUM(ssx) ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx, 
        SUM(deftx) deftx, SUM(accx) accx, SUM(rejx) rejx
        ".$strSqlDefSum." 
        FROM (
          SELECT planidx linex, sa.*, (defax + deffx) deftx, 
            0 accx,
            0 rejx
          FROM (
            SELECT lboidx, planidx, partx, iflagx, lotx, ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx
            ".$strSqlDefSum."
            FROM (
              SELECT a.inspect_lot_id lboidx, c.inspect_line planidx, c.inspect_style partx,
                'N' iflagx, a.inspect_lot_ss lotx, a.inspect_lot_ss ssx,  
                CASE WHEN b.inspect_flag = 'GOOD' THEN b.inspect_qty ELSE 0 END goodx,
                CASE WHEN d.DEFECT_CAT = 'AESTHETIC' THEN b.inspect_qty ELSE 0 END defax, 
                CASE WHEN d.DEFECT_CAT = 'FUNCTION' THEN b.inspect_qty ELSE 0 END deffx
                ". $strSqlDef ."
              FROM qc_pp_insp_lot a
              LEFT JOIN qc_pp_insp_lot_det b ON a.inspect_lot_id = b.inspect_lot_id
              LEFT JOIN qc_pp_insp c ON a.inspect_id = c.inspect_id
              LEFT JOIN defect_lbo d ON b.inspect_defect = d.DEFECT_CODE
              WHERE c.inspect_date BETWEEN $strTabPar1 
              ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND a.inspect_date NOT IN $GLOB_AUDIT_DATE")."
            ) a GROUP BY lboidx, planidx, partx, iflagx, lotx, ssx
          ) sa 
          LEFT JOIN toy_part sb ON sa.partx = sb.PART_NUM
          WHERE (goodx + defax + deffx) <> 0"
          .(($cat !="" && $cat != "ALL") ? " AND sb.PART_TYPE ='$cat' " : "")."
        ) sa 
        GROUP BY linex, partx
      ) ga 
      LEFT JOIN toy_part gb ON ga.partx = gb.PART_NUM
      LEFT JOIN line gc ON ga.linex = gc.LINE_CODE
      WHERE 1=1 "
      .(($unit !="" && $unit != "ALL") ? " AND gc.LINE_PREF ='$unit' " : "").""
      .(($line !="" && $line != "ALL") ? " AND gc.LINE_CODE ='$line' " : "").""
      .(($line_all !="") ? " AND gc.LINE_CODE IN (" . $line_all . ")" : "") . "
      ORDER BY gc.LINE_PREF, gc.LINE_ORDR, gb.PART_NUM
    ";
    //echo '<pre>'. $strSql . '</pre>';
  
  
  } else if ($section == 12) { //LBO DEF
    
    $tab = $_GET["tab"];
    $year = $_GET["year"];
    $month = $_GET["month"];
    $week = $_GET["week"];

    $date_f = $_GET["date_f"];
    $date_t = $_GET["date_t"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $cat = $_GET["cat"];

    $def = $_GET["def"];

    $week_t = $year .'-'. str_replace('/', '-', $week);

    $strTabPar1 = "";
    $strTabPar2 = "";
    
    if ($tab == 'D') {
      $strTabPar1 = "'$date_f' AND '$date_t'";
    } else if ($tab == 'W'){
      $strTabPar1 = "DATE_ADD('$week_t', INTERVAL -6 DAY) AND '$week_t'";
    } else if ($tab == 'M'){
      $strTabPar1 = "'".$year."-".$month."-01' AND '".$year."-".$month."-31'";
    } else if ($tab == 'Y'){
      $strTabPar1 = "'".$year."-01-01' AND '".$year."-12-31'";
    }

    $strSql = "
    SELECT sa.*, sb.*, IFNULL(defqx, 0) defqx 
    FROM (
      SELECT DISTINCT linex, linedx, lineox, linepx, leadx
      FROM (
        SELECT a.QC_LBO_PLAN_ID planx, a.QC_LBO_LINE linex, d.LINE_DESC linedx, d.LINE_ORDR lineox, d.LINE_PREF linepx, 
          a.QC_LBO_PART partx, a.QC_LBO_GROUP groupx, b.LBO_DEFECT_CODE defcx, e.DEFECT_NAME defnx,
          1 defqx, IFNULL(c.LEADER_NAME, d.LINE_NAME_SPV) leadx
        FROM qc_lbo_input a 
        LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
        LEFT JOIN output_prod_good_lead c ON a.QC_LBO_PLAN_ID = c.PLAN_ID
        LEFT JOIN line d ON a.QC_LBO_LINE = d.LINE_CODE
        LEFT JOIN defect_lbo e ON b.LBO_DEFECT_CODE = e.DEFECT_CODE
        LEFT JOIN toy_part f ON a.QC_LBO_PART = f.PART_NUM
        WHERE a.QC_LBO_DATE BETWEEN $strTabPar1 
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND a.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
        ".(($def !="" && $def != "ALL") ? " AND b.LBO_DEFECT_CODE ='$def' " : "")."
        ".(($cat !="" && $cat != "ALL") ? " AND f.PART_TYPE ='$cat' " : "")."
        AND a.QC_LBO_INSPECT_TYPE = 'N'
        AND b.LBO_CATEGORY = 'DEFECT'
      ) a 
    ) sa 
    LEFT JOIN (	
      SELECT DISTINCT b.LBO_DEFECT_CODE defcx, e.DEFECT_NAME defnx
      FROM qc_lbo_input a 
      LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
      LEFT JOIN defect_lbo e ON b.LBO_DEFECT_CODE = e.DEFECT_CODE
      LEFT JOIN toy_part f ON a.QC_LBO_PART = f.PART_NUM
      WHERE a.QC_LBO_DATE BETWEEN $strTabPar1 
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND a.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
      ".(($def !="" && $def != "ALL") ? " AND b.LBO_DEFECT_CODE ='$def' " : "")."
      ".(($cat !="" && $cat != "ALL") ? " AND f.PART_TYPE ='$cat' " : "")."
      AND a.QC_LBO_INSPECT_TYPE = 'N'
      AND b.LBO_CATEGORY = 'DEFECT'
    ) sb ON 1=1
    LEFT JOIN (
      SELECT linex, linedx, leadx, defcx, defnx, SUM(defqx) defqx 
      FROM (
        SELECT a.QC_LBO_PLAN_ID planx, a.QC_LBO_LINE linex, d.LINE_DESC linedx, 
          a.QC_LBO_PART partx, a.QC_LBO_GROUP groupx, b.LBO_DEFECT_CODE defcx, e.DEFECT_NAME defnx,
          1 defqx, IFNULL(c.LEADER_NAME, d.LINE_NAME_SPV) leadx
        FROM qc_lbo_input a 
        LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
        LEFT JOIN output_prod_good_lead c ON a.QC_LBO_PLAN_ID = c.PLAN_ID
        LEFT JOIN line d ON a.QC_LBO_LINE = d.LINE_CODE
        LEFT JOIN defect_lbo e ON b.LBO_DEFECT_CODE = e.DEFECT_CODE
        LEFT JOIN toy_part f ON a.QC_LBO_PART = f.PART_NUM
        WHERE a.QC_LBO_DATE BETWEEN $strTabPar1 
         ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND a.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
        ".(($def !="" && $def != "ALL") ? " AND b.LBO_DEFECT_CODE ='$def' " : "")."
        ".(($cat !="" && $cat != "ALL") ? " AND f.PART_TYPE ='$cat' " : "")."
        AND a.QC_LBO_INSPECT_TYPE = 'N'
        AND b.LBO_CATEGORY = 'DEFECT'
      ) a GROUP BY linex, linedx, leadx, defcx, defnx
    ) sc ON sc.linex = sa.linex AND sc.leadx = sa.leadx AND sc.defcx = sb.defcx 
    WHERE 1=1"
    .(($unit !="" && $unit != "ALL") ? " AND sa.linepx ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND sa.linex ='$line' " : "").""
    .(($line_all !="") ? " AND sa.linex IN (" . $line_all . ")" : "") . "
    ORDER BY sa.linepx, sa.lineox, leadx, defnx;
    ";

  } else if ($section == 90) { //GET DEFECT LBO
    $strSql ="
    SELECT DEFECT_CODE codex, UCASE(DEFECT_NAME) namex, DEFECT_CAT catx, DEFECT_ORDER orderx FROM defect_lbo ORDER BY DEFECT_CAT, DEFECT_ORDER;
    ";
  } else if ($section == 91) {  //GET VENDOR
    $strSql ="
    SELECT vendor_id codex, UCASE(vendor_name) namex FROM defect_matl_vendor;
    ";
  }
}

//echo '<pre>'. $strSql . '</pre>';
$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
