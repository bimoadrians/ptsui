<?php
  
  //global var
  $GLOB_AUDIT_FLAG = "OFF";
  $GLOB_AUDIT_DATE = "('2025-01-29')";

  //server
  $host_db    = "192.168.10.105";
  //$host_db    = "103.145.177.157";
  $user_db    = "egipublic";
  $pass_db    = "Asd159789.";
  $nama_db    = "db_sahabat_unggul";
  $port_db    = "3306";

  //server hr
  $host_db_hr = "192.168.10.105";
  //$host_db_hr = "103.145.177.157";
  $user_db_hr = "egipublic";
  $pass_db_hr = "Asd159789.";
  $nama_db_hr = "sui_hr_sistem";
  $port_db_hr = "3306";

  //server hr under age
  $host_db_hr_ua = "192.168.10.105";
  //$host_db_hr_ua = "103.145.177.157";
  $user_db_hr_ua = "egipublic";
  $pass_db_hr_ua = "Asd159789.";
  $nama_db_hr_ua = "sui_hr_sistem_under_age";
  $port_db_hr_ua = "3306";

  $ACCES_TOKEN = 'asd123159789asdasdqwerty';

  $conn = mysqli_connect($host_db, $user_db, $pass_db, $nama_db, $port_db);
  $conn_hr = mysqli_connect($host_db_hr, $user_db_hr, $pass_db_hr, $nama_db_hr, $port_db_hr);
  $conn_hr_ua = mysqli_connect($host_db_hr_ua, $user_db_hr_ua, $pass_db_hr_ua, $nama_db_hr_ua, $port_db_hr_ua);
  
  // Change character set to utf8
  mysqli_set_charset($conn,"utf8");

  function checkLogin($userx, $passx, $connx){
    $query = "
      SELECT USER_ID, USER_NAME, USER_PASS, IFNULL(USER_UNIT,'') USER_UNIT, IFNULL(USER_LEVEL,'') USER_LEVEL 
      FROM xref_user_web WHERE USER_NAME='".$userx."' LIMIT 1
    ";
    
    $result = mysqli_query($connx, $query);
    if(mysqli_num_rows($result) > 0) {
      // verify data
      $row = mysqli_fetch_array(@$result);
      $password_hased = $row['USER_PASS'];
      $password_periv = password_verify($passx, $password_hased);
      
      if ($password_periv == true){
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  function checkAcces($menux, $userx, $connx){
    $query = "
      SELECT a.menu_act_view, a.menu_act_mod, a.menu_act_del 
      FROM xref_menu_web_aces_new a 
      LEFT JOIN xref_menu_web_new b on a.menu_id = b.menu_id
      WHERE b.menu_path = '$menux' AND a.menu_user_id = $userx;
    ";

    $result = mysqli_query($connx, $query);
    if(mysqli_num_rows($result) > 0) {
      // verify data
      $row = mysqli_fetch_array(@$result);
      return $row;
    } else {
      return [];
    }
  }
 