<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  if ($section == 1){ //view list absent verify
    $date = $_GET['date'];
    $unit = $_GET["unit"];

    $strSql = "
    SELECT * FROM (
      SELECT a.id idx, a.nik nikx, a.nama namax, 'TA' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name labx,  
        CAST( IFNULL(CAST(a.keluar AS DATE), DATE_ADD('$date',INTERVAL 1 DAY)) AS DATE) outx,
        IFNULL(b.keterangan, 'A') ketx, c.`order` ordx, IFNULL(f.keterangan_absen_baru, '') ketnx, IFNULL(f.approved, '') apprx
      FROM karyawans a 
      LEFT JOIN absens b ON b.tanggal = '$date' AND a.id = b.id_karyawan
      LEFT JOIN sub_departemens c ON a.id_sub_departemen = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      LEFT JOIN absens_req_koreksi f ON f.status_karyawan = 'tetap' AND f.id_karyawan = a.id AND f.tanggal = '$date'
      WHERE CAST( IFNULL(CAST(a.keluar AS DATE), DATE_ADD('$date',INTERVAL 1 DAY)) AS DATE) >= '$date' 
      AND IFNULL(b.keterangan, 'A') = 'A' 
      " . (($unit !="" && $unit != "ALL") ? " AND c.`unit` ='$unit' " : "") . "
      UNION ALL

      SELECT a.id, a.nik, a.nama, 'TR' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name labx,
        IFNULL(a.tgl_keluar, DATE_ADD('$date',INTERVAL 1 DAY)) outx,
        IFNULL(b.flag, 'A') ketx, c.`order`, IFNULL(f.keterangan_absen_baru, '') ketnx, IFNULL(f.approved, '') apprx 
      FROM karyawans_tr a 
      LEFT JOIN karyawans_tr_absen b ON b.date_absen = '$date' AND a.id = b.id
      LEFT JOIN sub_departemens c ON a.id_sub_dept = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      LEFT JOIN absens_req_koreksi f ON f.status_karyawan = 'training' AND f.id_karyawan = a.id AND f.tanggal = '$date'
      WHERE IFNULL(a.tgl_keluar, DATE_ADD('$date',INTERVAL 1 DAY)) >= '$date'
      AND IFNULL(b.flag, 'A') = 'A' 
      " . (($unit !="" && $unit != "ALL") ? " AND c.`unit` ='$unit' " : "") . "
    ) a
    ORDER BY a.labx DESC, a.ordx, a.namax, a.subx;
    ";
  } else if ($section == 2){ //add absent verify
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $absen_date = $_POST['absen_date'];
    $absen_type = $_POST['absen_type'];
    $absen_id = $_POST['absen_id'];
    $absen_old = $_POST['absen_old'];
    $absen_new = $_POST['absen_new'];
    $absen_hr = $_POST['absen_hr'];
    $absen_ket = $_POST['absen_ket'];
    $msgx = '';

    if ($absen_type == 'TA'){
      $absen_type = 'tetap';
    }else{
      $absen_type = 'training';
    }

    $strSql = "
      SELECT COUNT(*) REC_COUNT, IFNULL(approved, 0) APPR
      FROM absens_req_koreksi a 
      WHERE a.id_karyawan=$absen_id AND 
      status_karyawan='$absen_type' AND 
      tanggal='$absen_date';";
    
    $res = mysqli_query($conn_hr, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];
    $rec_appr = $row['APPR'];

    //if not exsist add
    if ($rec_count == 0){
      $strSql = "
      INSERT INTO `absens_req_koreksi` (
        `id_karyawan`, `tanggal`, `status_karyawan`, 
        `keterangan_absen_awal`, `keterangan_absen_baru`, `jam_masuk`, 
        `remark`, `approved`, `add_id`, `add_date`
      ) VALUES (
        $absen_id, '$absen_date', '$absen_type', 
        '$absen_old', '$absen_new', '$absen_hr', 
        '$absen_ket', 0, $useridx, NOW()
      );
      ";
      
      if (mysqli_query($conn_hr, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }

    } else {
      if ($rec_appr == "0")  {
        $strSql = "
        UPDATE `absens_req_koreksi` SET 
          `keterangan_absen_baru`='$absen_new',
          `jam_masuk`='$absen_hr',
          `remark`='$absen_ket',
          `mod_id`=$useridx,
          `mod_date`=NOW()
        WHERE id_karyawan=$absen_id AND 
        status_karyawan='$absen_type' AND 
        tanggal='$absen_date';";

        if (mysqli_query($conn_hr, $strSql)) {
          $action = 'TRUE';
        } else {
          $action = 'FALSE';
        }
      } else {
        $action = "ERROR APPR";
        $msgx = "Data verifikasi yang sudah di approve tidak bisa diubah.";
      }
    }
    
    $strSql = "SELECT '$action' actionx, '".$_POST['absen_type']."-$absen_id' rowx, '".$_POST['absen_new']."' newx, '$msgx' msgx;";
  
  } else if ($section == 3){ //view list mutasi
    $date = $_GET['date'];
    $unit = $_GET['unit'];
    $line = $_GET['line'];

    $strSql = "
    SELECT * FROM (
      SELECT a.id idx, a.nik nikx, a.nama namax, 'TA' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c. id subidx, c.nama subx, d.nama jabx, e.labor_name labx,  
        CAST( IFNULL(CAST(a.keluar AS DATE), DATE_ADD('$date',INTERVAL 1 DAY)) AS DATE) outx,
        c.`order` ordx, IFNULL(b.id, '0') reqx, IFNULL(b.approved, '') apprx
      FROM karyawans a 
      LEFT JOIN mutasis_req b ON DATE(b.request_date) = '$date' AND a.id = b.id_karyawan AND request_source='tetap'
      LEFT JOIN sub_departemens c ON a.id_sub_departemen = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      LEFT JOIN absens_req_koreksi f ON f.status_karyawan = 'tetap' AND f.id_karyawan = a.id AND f.tanggal = '$date'
      WHERE CAST( IFNULL(CAST(a.keluar AS DATE), DATE_ADD('$date',INTERVAL 1 DAY)) AS DATE) >= '$date' 
      AND a.id_sistem_upah <> 2 AND e.labor_name ='PDL'
      " . (($unit !="" && $unit != "ALL") ? " AND c.`unit` ='$unit' " : "") . "
      " . (($line !="" && $line != "ALL") ? " AND c.`id` ='$line' " : "") . "
      UNION ALL

      SELECT a.id, a.nik, a.nama, 'TR' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c. id subidx, c.nama subx, d.nama jabx, e.labor_name labx,
        IFNULL(a.tgl_keluar, DATE_ADD('$date',INTERVAL 1 DAY)) outx,
        c.`order`, IFNULL(b.id, '0') reqx, IFNULL(b.approved, '') apprx
      FROM karyawans_tr a 
      LEFT JOIN mutasis_req b ON DATE(b.request_date) = '$date' AND a.id = b.id_karyawan AND request_source='training'
      LEFT JOIN sub_departemens c ON a.id_sub_dept = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      LEFT JOIN absens_req_koreksi f ON f.status_karyawan = 'training' AND f.id_karyawan = a.id AND f.tanggal = '$date'
      WHERE IFNULL(a.tgl_keluar, DATE_ADD('$date',INTERVAL 1 DAY)) >= '$date'
      " . (($unit !="" && $unit != "ALL") ? " AND c.`unit` ='$unit' " : "") . "
      " . (($line !="" && $line != "ALL") ? " AND c.`id` ='$line' " : "") . "
    ) a
    ORDER BY a.ordx, a.namax;
    ";
  
  } else if ($section == 4){ //add mut absen
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $mut_date = $_POST['mut_date'];
    $mut_type = $_POST['mut_type'];
    $mut_id = $_POST['mut_id'];
    $mut_old = $_POST['mut_old'];
    $mut_new = $_POST['mut_new'];
    $msgx = '';

    if ($mut_type == 'TA'){
      $mut_type = 'tetap';
    }else{
      $mut_type = 'training';
    }

    $strSql = "
      SELECT COUNT(*) REC_COUNT, IFNULL(approved, 0) APPR
      FROM mutasis_req a 
      WHERE a.id_karyawan=$mut_id AND 
      request_source='$mut_type' AND 
      DATE(request_date)='$mut_date';";
    
    //echo $strSql;
    $res = mysqli_query($conn_hr, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];
    $rec_appr = $row['APPR'];

    //if not exsist add
    if ($rec_count == 0){
      $strSql = "
      INSERT INTO `mutasis_req` (
        `id_karyawan`, `request_date`, `request_source`, 
        `id_old_sub_departemen`, `id_new_sub_departemen`,
        `approved`, `add_id`, `add_date`
      ) VALUES (
        $mut_id, '$mut_date', '$mut_type', 
        '$mut_old', '$mut_new', 0, $useridx, NOW()
      );
      ";
      
      if (mysqli_query($conn_hr, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }

    } else {
      if ($rec_appr == "0")  {
        $strSql = "
        UPDATE `mutasis_req` SET 
          `id_new_sub_departemen`='$mut_new',
          `mod_id`=$useridx,
          `mod_date`=NOW()
        WHERE id_karyawan=$mut_id AND 
        request_source='$mut_type' AND 
        DATE(request_date)='$mut_date';";

        if (mysqli_query($conn_hr, $strSql)) {
          $action = 'TRUE';
        } else {
          $action = 'FALSE';
        }
      } else {
        $action = "ERROR APPR";
        $msgx = "Data mutasi yang sudah di approve tidak bisa diubah."; 
      }
    }
    
    $strSql = "SELECT '$action' actionx, '".$_POST['mut_type']."-$mut_id' rowx, '".$_POST['mut_new']."' newx, '$msgx' msgx;";
  } else if ($section == 5){ //view list overtime

    $date = $_GET['date'];
    $unit = $_GET['unit'];
    $line = $_GET['line'];

    $strSql = "
    SELECT
      (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR), CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) planx, 
      b.LINE_PREF unitx, a.PLAN_PROD_LINE_CODE linex, b.LINE_ID_SUB_DEP line_subx, b.LINE_DESC line_namex, 
      a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_PART partx, c.PART_NAME part_namex, a.PLAN_PROD_WH hrx, a.PLAN_PROD_OPT optx, b.LINE_ORDR ordx
    FROM plan_prod_daily a 
    LEFT JOIN line b ON a.PLAN_PROD_LINE_CODE = b.LINE_CODE
    LEFT JOIN toy_part c ON a.PLAN_PROD_PART = c.PART_NUM
    WHERE a.PLAN_PROD_DATE = '$date' 
    AND a.PLAN_PROD_FLAG = 'O'" 
    .(($unit !="" && $unit != "ALL") ? " AND b.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND b.LINE_CODE ='$line' " : "")."
    ORDER BY b.LINE_PREF, b.LINE_ORDR;
    ";

    $strSql_prod = "SELECT '' planx, '' unitx, '' linex, 0 line_subx, '' line_namex, '' groupx, '' partx, '' part_namex, 0 hrx, 0 optx, 0 ordx ";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $strSql_prod .= "
        UNION ALL
        SELECT '".$row['planx']."' planx,'".$row['unitx']."' unitx, '".$row['linex']."' linex, '".$row['line_subx']."' line_subx, '".$row['line_namex']."' line_namex, 
        '".$row['groupx']."' groupx, '".$row['partx']."' partx, '".$row['part_namex']."' part_namex, ".$row['hrx']." hrx, ".$row['optx']." optx, ".$row['ordx']." ordx    
        ";
      }
    }

    $strSql = "
    SELECT * FROM (
      $strSql_prod
    ) a left join (
      SELECT b.request_planx plan_reqx, b.* 
      FROM request_overtime b
      WHERE request_date ='$date'
    ) b on a.planx = b.plan_reqx
    WHERE planx <> ''
    ORDER BY a.ordx, a.groupx, b.request_part, b.request_jab, b.request_name;
    ";
    
    //var_dump($strSql);

  } else if ($section == 6){ //save overtime
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $req_date = $_POST['req_date'];
    $req_plan = $_POST['req_plan'];
    $req_unit = $_POST['req_unit'];
    $req_line = $_POST['req_line'];
    $req_line_sub = $_POST['req_line_sub'];
    $req_line_name = $_POST['req_line_name'];
    $req_group = $_POST['req_group'];
    $req_part = $_POST['req_part'];
    $req_part_desc = $_POST['req_part_desc'];
    $req_hour = $_POST['req_hour'];
    $req_idk = $_POST['req_idk'];
    $req_source = $_POST['req_source'];
    $req_nik = $_POST['req_nik'];
    $req_name = str_replace("'","`", $_POST['req_name']) ;
    $req_jab = $_POST['req_jab'];
    
    $msgx = '';

    if ($req_source == 'TA'){
      $req_source = 'tetap';
    }else{
      $req_source = 'training';
    }

    $strSql = "
      SELECT IFNULL(COUNT(*),0) rec_count FROM request_overtime 
      WHERE request_date='$req_date' 
      AND request_source='$req_source'
      AND request_id_karyawan=$req_idk;
    ";

    $res = mysqli_query($conn_hr, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['rec_count'];

    if ($rec_count == 0) {
    $strSql = "
      INSERT INTO `request_overtime` (
        `request_date`, `request_planx`, `request_unit`, 
        `request_line`, `request_line_sub`, `request_line_name`, `request_group`, 
        `request_part`, `request_part_desc`, `request_hour`, 
        `request_source`, `request_id_karyawan`, `request_nik`, 
        `request_name`, `request_jab`, `request_add_date`, `request_add_id`
      ) VALUES (
        '$req_date', '$req_plan', '$req_unit', 
        '$req_line', $req_line_sub, '$req_line_name', '$req_group', 
        '$req_part', '$req_part_desc', $req_hour, 
        '$req_source', $req_idk, '$req_nik', 
        '$req_name', '$req_jab', NOW(), $useridx
      );
      ";

      //echo '<pre>'. $strSql . '</pre>';

      if (mysqli_query($conn_hr, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }

    } else {
      $action = 'FALSE';
    }
    
    $strSql = "
      SELECT '$action' actionx, '$msgx' msgx, 
      '".$_POST['req_source']."' typex, 
      '$req_idk' idx,
      '$req_nik' nikx, 
      '$req_name' namex,
      '$req_jab' jabx

    ";
  
  } else if ($section == 7){ //delete ovt list
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $req_date = $_POST['req_date'];
    $req_idk = $_POST['req_idk'];
    $req_source = $_POST['req_src'];
       
    $msgx = '';

    if ($req_source == 'TA'){
      $req_source = 'tetap';
    }else{
      $req_source = 'training';
    }

    $strSql = "
    DELETE FROM `request_overtime` 
    WHERE `request_date`='$req_date' 
    AND `request_source`='$req_source'
    AND `request_id_karyawan`='$req_idk';
    ";
    
    if (mysqli_query($conn_hr, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }
    $strSql = "SELECT '$action' actionx, '$msgx' msgx, '".$_POST['req_src']."-".$req_idk."' rowx;";
  
  } else if ($section == 8){ //REG ONLINE KARYAWAN - LIST

    $data_conf = $_GET['data_conf'];
    $strSql = "
      SELECT a.*, TIMESTAMPDIFF(YEAR, `tgl_lahir`, CURDATE()) usia, IFNULL(flag_conf, 0) flagx 
      FROM oline_recruitmen a 
      WHERE 1=1
      ". ($data_conf == 'ALL' ? "" : "AND IFNULL(flag_conf, 0)=$data_conf") ."
      ORDER BY tanggal ASC
    ";
  } else if ($section == 9){ //REG ONLINE - UPDATE CONFIRM
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $data_id = $_POST['data_id'];
    $data_val = (int)$_POST['data_val'];    

    $msgx = '';
    $strSql = "
      UPDATE `oline_recruitmen` SET flag_conf=$data_val WHERE `id`='$data_id';
    ";
    
    if (mysqli_query($conn_hr, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }
    $strSql = "SELECT '$action' actionx, '$msgx' msgx, '$data_val' valx;";

  } else if ($section == 10){ //REG ONLINE - DELETE
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $data_id = $_POST['data_id'];
    $data_row = $_POST['data_row'];    

    $msgx = '';
    $strSql = "
      DELETE FROM `oline_recruitmen` WHERE `id`='$data_id';
    ";
    
    if (mysqli_query($conn_hr, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }
    $strSql = "SELECT '$action' actionx, '$msgx' msgx, '$data_row' rowx;";

  } else if ($section == 11){ //history keluar factory
    $date = $_GET['date'];
    $datet = $_GET['datet'];

    $strSql = "
    SELECT * FROM (
      SELECT a.LOG_NIK nikx, b.nama namex, c.nama subx, d.nama jabx, COUNT(*) countx, GROUP_CONCAT(DISTINCT DATE_FORMAT(a.LOG_TIME, '%H:%i') SEPARATOR ', ') timex  
      FROM scan_logs a
      INNER JOIN karyawans b ON a.LOG_NIK = b.nik
      LEFT JOIN sub_departemens c ON b.id_sub_departemen = c.id
      LEFT JOIN jabatans d ON b.id_jabatan = d.id 
      WHERE a.LOG_DATE BETWEEN '$date' AND '$datet'
      GROUP BY a.LOG_NIK, b.nama, c.nama, d.nama UNION ALL
      SELECT a.LOG_NIK nikx, b.nama namex, c.nama subx, d.nama jabx, COUNT(*) countx, GROUP_CONCAT(DISTINCT DATE_FORMAT(a.LOG_TIME, '%H:%i') SEPARATOR ', ') timex  
      FROM scan_logs a
      INNER JOIN karyawans_tr b ON a.LOG_NIK = b.nik
      LEFT JOIN sub_departemens c ON b.id_sub_dept = c.id
      LEFT JOIN jabatans d ON b.id_jabatan = d.id 
      WHERE a.LOG_DATE BETWEEN '$date' AND '$datet'
      GROUP BY a.LOG_NIK, b.nama, c.nama, d.nama
    ) a ORDER BY countx DESC
    ";

  } else if ($section == 12){ //audit needle view
    
    $date = $_GET['date'];
    $unit = $_GET['unit'];
    $line = $_GET['line'];
    $line_all = $_GET["line_all"];

    $strSql = "
    SELECT LINE_PREF unitx, LINE_CODE linex, LINE_DESC linedx, LINE_ID_SUB_DEP linesubx, LINE_NAME_SPV spvx, LINE_ORDR ordx
    FROM line b 
    WHERE LINE_ACTIVE_FLAG='Y'" 
    .(($unit !="" && $unit != "ALL") ? " AND b.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND b.LINE_CODE ='$line' " : "").""
    .(($line_all !="") ? " AND b.LINE_CODE IN (" . $line_all . ")" : "") . "
    ORDER BY b.LINE_PREF, b.LINE_ORDR;
    ";

    $strSql_prod = "SELECT '' unitx, '' linex, '' linedx, '' linesubx, '' spvx, 0 ordx";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $strSql_prod .= "
        UNION ALL
        SELECT '".$row['unitx']."' unitx, 
        '".$row['linex']."' linex, 
        '".$row['linedx']."' linedx, 
        '".$row['linesubx']."' linesubx, 
        '".$row['spvx']."' spvx, 
        ".$row['ordx']." ordx   
        ";
      }
    }

    $strSql = "
    SELECT * FROM (
      SELECT * FROM (
        $strSql_prod      
      ) a left join (
        SELECT `audit_id`, `audit_date`, `audit_line`, `audit_line_desc`, `audit_line_sub`, `audit_lead`, 
        `audit_src`, `audit_nik`, `audit_name`, IFNULL(`audit_needs`, '') audit_needs, IFNULL(`audit_neede`, '') audit_neede, 
        IFNULL(`audit_trims`, '') audit_trims, IFNULL(`audit_trime`, '') audit_trime, `audit_tied_c1`, 
        `audit_tied_c2`, `audit_tied_t1`, `audit_tied_t2`, 
        `add_date`, `add_id`, `mod_date`, `mod_id` 
        FROM audit_needle b
        WHERE audit_date ='$date'
      ) b on a.linex = b.audit_line
      WHERE linex <> ''
    ) sa ORDER BY sa.unitx, sa.ordx, sa.audit_id
    ";
  
  } else if ($section == 13){ //audit needle save

    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $aud_date = $_POST['aud_date'];
    $aud_unit = $_POST['aud_unit'];
    $aud_line = $_POST['aud_line'];
    $aud_line_desc = $_POST['aud_line_desc'];
    $aud_line_sub = $_POST['aud_line_sub'];
    $aud_line_name = $_POST['aud_line_name'];
    $aud_line_lead = $_POST['aud_line_lead'];
    $aud_source = $_POST['aud_source'];
    $aud_nik = $_POST['aud_nik'];
    $aud_name = str_replace("'","\'", $_POST['aud_name']) ;
    $aud_jab = $_POST['aud_jab'];
    
    $msgx = '';

    if ($aud_source == 'TA'){
      $aud_source = 'TETAP';
    }else{
      $aud_source = 'TRAINING';
    }

    $strSql = "
      SELECT IFNULL(COUNT(*),0) rec_count 
      FROM audit_needle 
      WHERE audit_date='$aud_date' 
      AND audit_src='$aud_source'
      AND audit_nik='$aud_nik';
    ";

    //echo '<pre>'. $strSql . '</pre>';

    $res = mysqli_query($conn_hr, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['rec_count'];

    if ($rec_count == 0) {
    $strSql = "
      INSERT INTO `audit_needle` (
        `audit_date`, `audit_line`, `audit_line_desc`, 
        `audit_line_sub`, `audit_lead`,`audit_src`,
        `audit_nik`, `audit_name`, 
        `audit_needs`, `audit_neede`, 
        `audit_trims`, `audit_trime`, 
        `audit_tied_c1`, `audit_tied_c2`, 
        `audit_tied_t1`, `audit_tied_t2`,
        `add_date`, `add_id`
      ) VALUES (
        '$aud_date', '$aud_line', '$aud_line_name', 
        '$aud_line_sub', '$aud_line_lead', '$aud_source', 
        '$aud_nik', '$aud_name', 
        1, NULL, 
        1, NULL, 
        0, 0,
        NULL, NULL,
        NOW(), $useridx
      );
      ";

      //echo '<pre>'. $strSql . '</pre>';

      if (mysqli_query($conn_hr, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }

    } else {
      $action = 'FALSE';
    }
    
    $strSql = "
      SELECT '$action' actionx, '$msgx' msgx, 
      '".$_POST['req_source']."' typex, 
      `audit_id`, `audit_date`, `audit_line`, `audit_line_desc`, `audit_line_sub`, `audit_lead`, 
      `audit_src`, `audit_nik`, `audit_name`, IFNULL(`audit_needs`, '') audit_needs, IFNULL(`audit_neede`, '') audit_neede, 
      IFNULL(`audit_trims`, '') audit_trims, IFNULL(`audit_trime`, '') audit_trime, `audit_tied_c1`, 
      `audit_tied_c2`, `audit_tied_t1`, `audit_tied_t2`, 
      `add_date`, `add_id`, `mod_date`, `mod_id`
      FROM audit_needle a 
      WHERE audit_date='$aud_date' 
      AND audit_src='$aud_source'
      AND audit_nik='$aud_nik'; 

    ";
    
  } else if ($section == 14){ //audit needle del
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $aud_date = $_POST['aud_date'];
    $aud_id = $_POST['aud_id'];
    $aud_src = $_POST['aud_src'];
       
    $msgx = '';

    $strSql = "
    DELETE FROM `audit_needle` 
    WHERE `audit_date`='$aud_date' 
    AND `audit_id`='$aud_id';
    ";

    //echo '<pre>'. $strSql . '</pre>';
    
    if (mysqli_query($conn_hr, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }
    $strSql = "SELECT '$action' actionx, '$msgx' msgx, '".$_POST['aud_src']."-".$aud_id."' rowx;";
  
  } else if ($section == 15){ //audit needle mod
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $aud_id = $_POST['aud_id'];
    $aud_col = $_POST['aud_col'];
    $aud_val = (int)$_POST['aud_val'];
    $aud_add = "";
       
    $msgx = '';

    if ($aud_col == 'needs'){
      $aud_col = "audit_needs";
    } else if ($aud_col == 'neede'){
      $aud_col = "audit_neede";
    } else if ($aud_col == 'trims'){
      $aud_col = "audit_trims";
    } else if ($aud_col == 'trime'){
      $aud_col = "audit_trime";
    } else if ($aud_col == 'tied1'){
      $aud_col = "audit_tied_c1";
      $aud_add = "`audit_tied_t1`=NOW(),";
    } else if ($aud_col == 'tied2'){
      $aud_col = "audit_tied_c2";
      $aud_add = "`audit_tied_t2`=NOW(),";
    }

    $strSql = "
    UPDATE `audit_needle` SET 
    `$aud_col`= $aud_val, $aud_add
    `mod_date`= NOW(),    
    `mod_id`='$useridx'
    WHERE `audit_id`='$aud_id';
    ";

    if (mysqli_query($conn_hr, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }
    
    //$strSql = "SELECT '$action' actionx, '$msgx' msgx, '".$_POST['aud_src']."-".$aud_id."' rowx;";
    $strSql = "SELECT '$action' actionx, '$msgx' msgx;";
  
  } else if ($section == 16){ //line attendance - view
    
    $date = $_GET['date'];
    $line = $_GET['line'];

    // $strSql = "
    //   SELECT a.*, b.nama, c.nama jab 
    //   FROM scan_log_line a 
    //   LEFT JOIN view_empl_all b ON a.scan_nik = b.nik AND a.scan_flag_empl = b.epl
    //   LEFT JOIN jabatans c ON b.id_jab = c.id
    //   WHERE scan_tgl = '$date' AND scan_line_id = '$line' AND IFNULL(scan_time_out,'') = '';
    // ";

    $strSql = "
    SELECT a.*, b.*, sb.timex, c.nama, d.nama jab, IFNULL(h.ket, 'N/A') ket
    FROM (
        SELECT a.scan_nik nikx, MAX(a.scan_tgl) tglx
        FROM scan_log_line a WHERE a.scan_tgl <= '$date'
        GROUP BY a.scan_nik
    ) a
      LEFT JOIN (	
      SELECT a.scan_nik nikx, a.scan_tgl tglx, MAX(a.scan_time_in) timex
      FROM scan_log_line a WHERE a.scan_tgl <= '$date'
      GROUP BY a.scan_nik, a.scan_tgl 	
    ) sb ON a.nikx = sb.nikx AND a.tglx = sb.tglx      
    LEFT JOIN scan_log_line b ON a.nikx = b.scan_nik AND a.tglx = b.scan_tgl AND sb.timex = b.scan_time_in
    LEFT JOIN view_empl_all c ON a.nikx = c.nik AND b.scan_flag_empl = c.epl
    LEFT JOIN jabatans d ON c.id_jab = d.id
    LEFT JOIN temp_absen h ON h.tgl = '$date' AND h.eflag = c.epl AND h.nik = c.nik
    WHERE 1=1 
    AND c.keluar > '$date'
    AND scan_line_id = '$line'
    ORDER BY a.tglx, sb.timex;
    ";
  } else if ($section == 17){ //line attendance - add
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    }
    
    $action = 'FALSE';
    $actFlag = '';
    $nik = $_POST['nik'];
    $line = $_POST['line'];
    $lined = $_POST['lined'];

    $strSql = "
      SELECT COUNT(*) recc, epl
      FROM view_empl_all a 
      WHERE nik = '$nik';
    ";

    $res = mysqli_query($conn_hr, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $empl_count = $row['recc'];
    $empl_flag = $row['epl'];

    if ($empl_count > 0) {
    
      $strSql = "
        SELECT COUNT(*) recc
        FROM scan_log_line a 
        WHERE a.scan_tgl = CURDATE() 
        AND scan_nik = '$nik' AND scan_tgl=CURDATE() AND scan_time_in = CURTIME();
      ";      
      //echo '<pre>'. $strSql . '</pre>';

      $res = mysqli_query($conn_hr, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $rec_count = $row['recc'];

      if ($rec_count == 0) {
        // insert
        $strSql = "
          INSERT INTO `scan_log_line` (
          `scan_nik`, `scan_tgl`, `scan_line_id`, `scan_line_desc`, `scan_time_in`, 
          `scan_flag_empl`, `scan_flag_pay`, `add_date`, `add_id`
          ) VALUES (
          '$nik', CURDATE(), '$line', '$lined', CURTIME(),
          '$empl_flag', 1, NOW(), $useridx
          );
        ";
      }
     
      if (mysqli_query($conn_hr, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }

    } else {
      $action = 'NO EMPL';
    }
    
    $strSql = "
      SELECT * FROM (
	        SELECT '$action' actx
      ) a LEFT JOIN (
        SELECT a.*, b.nama, c.nama jab
        FROM scan_log_line a 
        LEFT JOIN view_empl_all b ON a.scan_nik = b.nik AND a.scan_flag_empl = b.epl
        LEFT JOIN jabatans c ON b.id_jab = c.id
        WHERE scan_tgl = CURDATE() AND scan_line_id = '$line' AND scan_nik='$nik'
      ) b ON 1=1;
    ";
    
  } else if ($section == 18){ //line attendance sum - view 
    $date = $_GET['date'];
    $unit = $_GET['unit'];
    $line = $_GET['line'];
    $nik = strtoupper($_GET['nik']);

    $strSql = "
    SELECT a.*, b.*, c.nama, d.nama jab 
    FROM (
        SELECT a.scan_nik nikx, a.scan_tgl tglx, MAX(a.scan_time_in) timex 
        FROM scan_log_line a WHERE a.scan_tgl = '$date'
        GROUP BY a.scan_nik, a.scan_tgl
    ) a 
    LEFT JOIN scan_log_line b ON a.nikx = b.scan_nik AND a.tglx = b.scan_tgl AND a.timex = b.scan_time_in
    LEFT JOIN view_empl_all c ON a.nikx = c.nik AND b.scan_flag_empl = c.epl
    LEFT JOIN jabatans d ON c.id_jab = d.id
    LEFT JOIN view_lines e ON e.LINE_CODE = b.scan_line_id
    WHERE b.scan_tgl = '$date'"
    .(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND b.scan_line_id ='$line' " : "").""
    .(($nik !="") ? " AND (UPPER(a.nikx) LIKE '%$nik%' OR UPPER(c.nama) LIKE '%$nik%')" : "")."
    ORDER by e.LINE_PREF, e.LINE_ORDR, a.timex;
    ";
    //echo '<pre>'. $strSql . '</pre>';
  
  } else if ($section == 19){ //line attendance sum - view v2

    $date = $_GET['date'];
    $unit = $_GET['unit'];
    $line = $_GET['line'];
    $nik = strtoupper($_GET['nik']);   

    //Generate absen
    $strSql = "CALL `add_temp_absen`('$date');";
    $res = mysqli_query($conn_hr, $strSql);

    //Get plan HC
    $strSql = "
      SELECT LINEC, SCH_HC SCH_HC_H, ACT_HC ACT_HC_H 
      FROM (
        SELECT SUBSTR(GROUP_ID, 9, 2) LINEC, IFNULL(SUM(SCH_HC),0) SCH_HC, IFNULL(SUM(ACT_HC),0) ACT_HC 
        FROM (
          SELECT DISTINCT GROUP_ID, SCH_HC, ACT_HC
          FROM (
            SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 10), 
            IF(
              LOCATE('N', a.OUT_PLAN_ID, 19) = 0, 
              RIGHT(a.OUT_PLAN_ID, LGNGTH(a.OUT_PLAN_ID) - LOCATE('O', a.OUT_PLAN_ID, 19)), 
              RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - LOCATE('N', a.OUT_PLAN_ID, 19))
            )) GROUP_ID, 
            a.PLAN_PROD_OPT SCH_HC, 0 ACT_HC 
            FROM plan_prod_daily_view_board a 
            WHERE a.PLAN_PROD_DATE ='$date'
          ) a UNION ALL
          
          SELECT DISTINCT GROUP_ID, SCH_HC, ACT_HC 
          FROM ( 
            SELECT CONCAT(LEFT(a.PLAN_ID, 10), 
            IF(
              LOCATE('N', a.PLAN_ID, 19) = 0, 
              RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - LOCATE('O', a.PLAN_ID, 19)), 
              RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - LOCATE('N', a.PLAN_ID, 19))
            )) GROUP_ID, 
            0 SCH_HC, a.OUT_PROD_GOOD_AHC ACT_HC
            FROM output_prod_good_hc a 
            WHERE LEFT(a.PLAN_ID,8) ='$date'
            AND a.PLAN_ID IN (
              SELECT DISTINCT OUT_PLAN_ID 
              FROM plan_prod_daily_view_board a 
              WHERE a.PLAN_PROD_DATE ='$date'
           )
          ) a
        ) sa LEFT JOIN line sb ON SUBSTR(GROUP_ID, 9, 2) = sb.LINE_CODE
        WHERE 1=1
        GROUP BY SUBSTR(GROUP_ID, 9, 2)
      ) a;
    ";

    $strSqlHc = "";
    $strSqlHc .= "SELECT 'xx' linex, '0' phcx, '0' ahcx";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $strSqlHc .= "
          UNION ALL SELECT '".$row['LINEC']."' linex, '".$row['SCH_HC_H']."' phcx, '".$row['ACT_HC_H']."' ahcx";
      }
    }

    //echo '<pre>'. $strSqlHc . '</pre>';

    $strSql = "
    SELECT a.nikx, a.flagx scan_flag_empl, a.tglx, b.timex, c.scan_line_id, e.LINE_DESC scan_line_desc, d.*, 
      e.LINE_PREF prefx, e.LINE_DESC linedx, f.nama jab, g.labor_name labx, i.nama subx,
      IFNULL(h.ket, 'N/A') ket, g.phcx, g.ahcx
    FROM (
      SELECT a.scan_nik nikx, a.scan_flag_empl flagx, MAX(a.scan_tgl) tglx
      FROM scan_log_line a WHERE a.scan_tgl <= '$date'
      GROUP BY a.scan_nik, scan_flag_empl
    ) a 
   LEFT JOIN (	
      SELECT a.scan_nik nikx, a.scan_tgl tglx, MAX(a.scan_time_in) timex
      FROM scan_log_line a WHERE a.scan_tgl <= '$date'
      GROUP BY a.scan_nik, a.scan_tgl 	
    ) b ON a.nikx = b.nikx AND a.tglx = b.tglx
    LEFT JOIN scan_log_line c ON c.scan_tgl = a.tglx AND a.nikx = c.scan_nik AND c.scan_time_in = b.timex
    LEFT JOIN view_empl_all d ON a.nikx = d.nik AND a.flagx = d.epl
    LEFT JOIN view_lines e ON c.scan_line_id = e.LINE_CODE
    LEFT JOIN jabatans f ON d.id_jab = f.id
    LEFT JOIN labor_type g ON f.labor_id = g.labor_id
    LEFT JOIN temp_absen h ON h.tgl = '$date' AND h.eflag = d.epl AND h.nik = d.nik
    LEFT JOIN (
    ". $strSqlHc ."
    ) g on c.scan_line_id = g.linex
    LEFT JOIN sub_departemens i ON i.id = d.id_sub
    WHERE d.keluar > '$date'"
    .(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND c.scan_line_id ='$line' " : "").""
    .(($nik !="") ? " AND (UPPER(d.nikx) LIKE '%$nik%' OR UPPER(d.nama+ LIKE '%$nik%')" : "")."
    ORDER BY e.LINE_PREF, e.LINE_ORDR, a.tglx, b.timex  
    ";

    //echo '<pre>'. $strSql . '</pre>';

  } else if ($section == 90){ //view list sub. department
    $strSql = "
      SELECT a.id subidx, a.nama subx 
      FROM sub_departemens a WHERE IFNULL(unit, '') <> '' AND a.nama <> '-'
      ORDER BY `order`;
      ;";
  } else if ($section == 91){ //view list karyawan hadir overtime
    $date = $_GET['date'];
    $line_sub = $_GET['line_sub'];

    $strSql = "
    SELECT * FROM (
      SELECT a.id idx, a.nik nikx, a.nama namax, 'TA' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name labx, c.`order` ordx  
      FROM karyawans a 
      LEFT JOIN absens b ON b.tanggal = '$date' AND a.id = b.id_karyawan
      LEFT JOIN sub_departemens c ON a.id_sub_departemen = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      WHERE CAST( IFNULL(CAST(a.keluar AS DATE), DATE_ADD('$date',INTERVAL 1 DAY)) AS DATE) >= '$date' 
      AND c.id = '$line_sub'
      AND IFNULL(b.keterangan, 'A') = 'H' 
      AND a.id NOT IN (
        SELECT request_id_karyawan idx 
        FROM request_overtime na WHERE na.request_date='$date' AND na.request_source='tetap' 
      ) UNION ALL

      SELECT a.id, a.nik, a.nama, 'TR' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name, c.`order` ordx 
      FROM karyawans_tr a 
      LEFT JOIN karyawans_tr_absen b ON b.date_absen = '$date' AND a.id = b.id
      LEFT JOIN sub_departemens c ON a.id_sub_dept = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      WHERE IFNULL(a.tgl_keluar, DATE_ADD('$date',INTERVAL 1 DAY)) >= '$date'
      AND c.id = '$line_sub'
      AND IFNULL(b.flag, 'A') = 'H' 
      AND a.id NOT IN (
        SELECT request_id_karyawan idx 
        FROM request_overtime na WHERE na.request_date='$date' AND na.request_source='training' 
      )
    ) a
    ORDER BY a.labx DESC, a.ordx, a.subx, a.jabx, a.namax;
    ";
  } else if ($section == 92){ //view all list karyawan
    $date = $_GET['date'];

    $strSql = "
    SELECT * FROM (
      SELECT a.id idx, a.nik nikx, a.nama namax, 'TA' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name labx, c.`order` ordx  
      FROM karyawans a 
      LEFT JOIN absens b ON b.tanggal = '$date' AND a.id = b.id_karyawan
      LEFT JOIN sub_departemens c ON a.id_sub_departemen = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      WHERE CAST( IFNULL(CAST(a.keluar AS DATE), DATE_ADD('$date',INTERVAL 1 DAY)) AS DATE) >= '$date' 
      AND IFNULL(b.keterangan, 'A') = 'H' 
      AND a.id NOT IN (
        SELECT request_id_karyawan idx 
        FROM request_overtime na WHERE na.request_date='$date' AND na.request_source='tetap' 
      ) UNION ALL

      SELECT a.id, a.nik, a.nama, 'TR' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name, c.`order` ordx 
      FROM karyawans_tr a 
      LEFT JOIN karyawans_tr_absen b ON b.date_absen = '$date' AND a.id = b.id
      LEFT JOIN sub_departemens c ON a.id_sub_dept = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      WHERE IFNULL(a.tgl_keluar, DATE_ADD('$date',INTERVAL 1 DAY)) >= '$date'
      AND IFNULL(b.flag, 'A') = 'H' 
      AND a.id NOT IN (
        SELECT request_id_karyawan iddx 
        FROM request_overtime na WHERE na.request_date='$date' AND na.request_source='training' 
      )
    ) a
    ORDER BY a.labx DESC, a.ordx, a.subx, a.jabx, a.namax;
    ";
  } else if ($section == 93){ //audit needle list karyawan
    $date = $_GET['date'];
    $line_sub = $_GET['line_sub'];

    $strSql = "
    SELECT * FROM (
      SELECT a.id idx, a.nik nikx, a.nama namax, 'TA' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name labx, c.`order` ordx  
      FROM karyawans a 
      LEFT JOIN absens b ON b.tanggal = '$date' AND a.id = b.id_karyawan
      LEFT JOIN sub_departemens c ON a.id_sub_departemen = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      WHERE CAST( IFNULL(CAST(a.keluar AS DATE), DATE_ADD('$date',INTERVAL 1 DAY)) AS DATE) >= '$date' 
      AND c.id = '$line_sub'
      AND IFNULL(b.keterangan, 'A') = 'H' 
      AND a.nik NOT IN (
        SELECT audit_nik nikx 
        FROM audit_needle na WHERE na.audit_date='$date' AND na.audit_src='TETAP' 
      ) UNION ALL

      SELECT a.id, a.nik, a.nama, 'TR' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name, c.`order` ordx 
      FROM karyawans_tr a 
      LEFT JOIN karyawans_tr_absen b ON b.date_absen = '$date' AND a.id = b.id
      LEFT JOIN sub_departemens c ON a.id_sub_dept = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      WHERE IFNULL(a.tgl_keluar, DATE_ADD('$date',INTERVAL 1 DAY)) >= '$date'
      AND c.id = '$line_sub'
      AND IFNULL(b.flag, 'A') = 'H' 
      AND a.nik NOT IN (
        SELECT audit_nik nikx 
        FROM audit_needle na WHERE na.audit_date='$date' AND na.audit_src='TRAINING' 
      )
    ) a
    ORDER BY a.labx DESC, a.ordx, a.subx, a.jabx, a.namax;
    ";
  }
}
//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {

  $res = mysqli_query($conn_hr, $strSql);
  if (mysqli_num_rows($res) > 0) {
    
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
