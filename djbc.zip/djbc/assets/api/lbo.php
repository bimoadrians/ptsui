<?php
session_start();
//error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ERROR);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$auth = checkLogin($userx, $passx, $conn);
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  //prod list
  if ($section == 1){ //view prod list
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $strSql = "
    SELECT a.linex, c.LINE_DESC line_namex, c.LINE_NAME_SPV spvx, 
      a.groupx, a.partx, d.PART_NAME part_namex, 
      d.PART_TYPE part_typex, a.plan_id group_id, a.plan, IFNULL(b.actual, 0) actual, 
      IFNULL(b.lotn, 0) lotn, IFNULL(b.lot_qtyn, 0) lot_qtyn, IFNULL(b.accn, 0) accn, IFNULL(b.rejn, 0) rejn,
      IFNULL(b.lott, 0) lott, IFNULL(b.lot_qtyt, 0) lot_qtyt, IFNULL(b.acct, 0) acct, IFNULL(b.rejt, 0) rejt 
    FROM (
      SELECT (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) plan_id, 
      a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_PART partx, SUM(a.PLAN_PROD_QTY) plan
      FROM plan_prod_daily a WHERE a.PLAN_PROD_DATE = '" . $date . "'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
      GROUP BY (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')),
      a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_GROUP_ORD, a.PLAN_PROD_PART
    ) a LEFT JOIN (
      SELECT plan_id, SUM(actual) actual, SUM(lotn) lotn, SUM(lot_qtyn) lot_qtyn, SUM(accn) accn, SUM(rejn) rejn, SUM(lott) lott, SUM(lot_qtyt) lot_qtyt, SUM(acct) acct, SUM(rejt) rejt 
      FROM (
        #PROD QTY
        SELECT plan_id, SUM(prodx) actual, 0 lotn, 0 lot_qtyn, 0 accn, 0 rejn, 0 lott, 0 lot_qtyt, 0 acct, 0 rejt 
        FROM (
          SELECT a.OUT_PLAN_ID, REPLACE(REPLACE(a.OUT_PLAN_ID,'N',''),'O','') plan_id, SUM(a.OUT_PROD_QTY) prodx
          FROM output_prod_good a WHERE 
          IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D'
          AND a.OUT_PROD_DATE = '" . $date . "'
          GROUP BY a.OUT_PLAN_ID 
        ) a GROUP BY plan_id UNION ALL
        #LOT QTY NORMAL
        SELECT sa.plan_id, 0 actual, COUNT(lotx) lotx, SUM(lotx) lot_qtyx, SUM(accx) accx, (COUNT(lotx) - SUM(accx)) rejx, 0 lott, 0 lot_qtyt, 0 acct, 0 rejt
        FROM (
        SELECT sa.lbo_id, plan_id, partx, lotx, ssx, gddx, defx,  IF(IFNULL(defx,0)>IFNULL(sc.lbo_sampl_a, 0), 0, 1) accx
        FROM (
          SELECT lbo_id, plan_id, partx, lotx, ssx, SUM(gddx) gddx, SUM(defx) defx 
          FROM (
            SELECT CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N','')) plan_id, a.QC_LBO_ID lbo_id, a.QC_LBO_PART partx,  
            a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, IF(b.LBO_CATEGORY='GOOD',1,0) gddx, IF(b.LBO_CATEGORY='DEFECT', 1, 0) defx
            FROM qc_lbo_input a 
            LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
            WHERE LEFT(a.QC_LBO_PLAN_ID, 8) = '" . str_replace("-", "", $date) . "' AND a.QC_LBO_INSPECT_TYPE = 'N' 
            AND INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N') <> 0
            UNION ALL
            SELECT CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O','')) plan_id, a.QC_LBO_ID lbo_id, a.QC_LBO_PART partx,  
            a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, IF(b.LBO_CATEGORY='GOOD',1,0) gddx, IF(b.LBO_CATEGORY='DEFECT', 1, 0) defx
            FROM qc_lbo_input a 
            LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
            WHERE LEFT(a.QC_LBO_PLAN_ID, 8) = '" . str_replace("-", "", $date) . "' AND a.QC_LBO_INSPECT_TYPE = 'N'
            AND INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O') <> 0
          ) a GROUP BY lbo_id, plan_id, partx, lotx, ssx
        ) sa 
        LEFT JOIN toy_part sb ON sa.partx = sb.PART_NUM
        LEFT JOIN qc_lbo_smpl sc ON IFNULL(sb.PART_TYPE, 'MNL') = sc.lbo_smpl_type AND sc.lbo_smpl_ins = 'N'
        AND sa.lotx BETWEEN sc.lbo_smpl_lot_size_min AND sc.lbo_smpl_lot_size_max
        ) sa GROUP BY sa.plan_id UNION ALL
        
        #LOT QTY TIGHT
        SELECT sa.plan_id, 0 actual, 0 lotn, 0 lot_qtyn, 0 accn, 0 rejn, COUNT(lotx) lott, SUM(lotx) lot_qtyt, SUM(accx) acct, (COUNT(lotx) - SUM(accx)) rejt
        FROM (
        SELECT sa.lbo_id, plan_id, partx, lotx, ssx, gddx, defx,  IF(IFNULL(defx,0)>IFNULL(sc.lbo_sampl_a, 0), 0, 1) accx
        FROM (
          SELECT lbo_id, plan_id, partx, lotx, ssx, SUM(gddx) gddx, SUM(defx) defx 
          FROM (
            SELECT CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N','')) plan_id, a.QC_LBO_ID lbo_id, a.QC_LBO_PART partx,  
            a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, IF(b.LBO_CATEGORY='GOOD',1,0) gddx, IF(b.LBO_CATEGORY='DEFECT', 1, 0) defx
            FROM qc_lbo_input a 
            LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
            WHERE LEFT(a.QC_LBO_PLAN_ID, 8) = '" . str_replace("-", "", $date) . "' AND a.QC_LBO_INSPECT_TYPE = 'T'
            AND INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N') <> 0
            UNION ALL
            SELECT CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O','')) plan_id, a.QC_LBO_ID lbo_id, a.QC_LBO_PART partx,  
            a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, IF(b.LBO_CATEGORY='GOOD',1,0) gddx, IF(b.LBO_CATEGORY='DEFECT', 1, 0) defx
            FROM qc_lbo_input a 
            LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
            WHERE LEFT(a.QC_LBO_PLAN_ID, 8) = '" . str_replace("-", "", $date) . "' AND a.QC_LBO_INSPECT_TYPE = 'T'
            AND INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O') <> 0
          ) a GROUP BY lbo_id, plan_id, partx, lotx, ssx
        ) sa 
        LEFT JOIN toy_part sb ON sa.partx = sb.PART_NUM
        LEFT JOIN qc_lbo_smpl sc ON IFNULL(sb.PART_TYPE, 'MNL') = sc.lbo_smpl_type AND sc.lbo_smpl_ins = 'T'
        AND sa.lotx BETWEEN sc.lbo_smpl_lot_size_min AND sc.lbo_smpl_lot_size_max
        ) sa GROUP BY sa.plan_id
      ) a GROUP BY plan_id
    ) b ON a.plan_id = b.plan_id
    LEFT JOIN line c ON a.linex = c.LINE_CODE
    LEFT JOIN toy_part d ON a.partx = d.PART_NUM
    WHERE 1=1
    " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
    ORDER BY c.LINE_ORDR, a.groupx, a.partx;
    ";

  } else if ($section == 2){ //view lot list
    $lbo_id = $_GET['param_id'];
    $strSql = "
    SELECT a.QC_LBO_ID lbo_idx, a.QC_LBO_DATE lbo_datex, a.QC_LBO_TIME lbo_timex, 
      a.QC_LBO_INSPECT_TYPE lbo_insx, a.QC_LBO_LOT lbo_lotx, a.QC_LBO_SS lbo_ssx, a.QC_LBO_LOTX lbo_lotex, a.QC_LBO_LOTS lbo_lotexs,
      b.lbo_gdx, b.lbo_defa, b.lbo_deff, CONCAT(d.lbo_sampl_a, '/', d.lbo_sampl_r) arx, 
      IF((IFNULL(b.lbo_gdx, 0)+IFNULL(b.lbo_defa, 0)+IFNULL(b.lbo_deff, 0))=0,'Not checked yet', IF((IFNULL(b.lbo_defa, 0)+IFNULL(b.lbo_deff, 0))>d.lbo_sampl_a, 'Rejected','Accepted')) lbo_acc_statx
    FROM (
      SELECT a.QC_LBO_ID, a.QC_LBO_PART partx, a.QC_LBO_DATE, a.QC_LBO_TIME, a.QC_LBO_INSPECT_TYPE, a.QC_LBO_LOT, a.QC_LBO_SS, a.QC_LBO_LOTX, a.QC_LBO_LOTS 
      FROM qc_lbo_input a 
      WHERE INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N') <> 0 AND CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N','')) = '".$lbo_id."'
      UNION ALL
      SELECT a.QC_LBO_ID, a.QC_LBO_PART partx, a.QC_LBO_DATE, a.QC_LBO_TIME, a.QC_LBO_INSPECT_TYPE, a.QC_LBO_LOT, a.QC_LBO_SS, a.QC_LBO_LOTX, a.QC_LBO_LOTS 
      FROM qc_lbo_input a 
      WHERE INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O') <> 0 AND CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O','')) = '".$lbo_id."'
    ) a LEFT JOIN (
      #GET TOTAL CHECK
      SELECT a.QC_LBO_ID, SUM(gddx) lbo_gdx, SUM(defa) lbo_defa, SUM(deff) lbo_deff 
      FROM (
        SELECT a.QC_LBO_ID, b.LBO_CATEGORY, b.LBO_DEFECT_CODE, 
          IF(b.LBO_CATEGORY='GOOD', 1, 0) gddx,
          IF(c.DEFECT_CAT='AESTHETIC', 1, 0) defa,
          IF(c.DEFECT_CAT='FUNCTION', 1, 0) deff
        FROM qc_lbo_input a 
        LEFT JOIN qc_lbo_input_detail b 
        LEFT JOIN defect_lbo c ON b.LBO_DEFECT_CODE = c.DEFECT_CODE
        ON a.QC_LBO_ID = b.QC_LBO_ID
        WHERE INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N') <> 0 AND CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N','')) = '".$lbo_id."' 
        UNION ALL
        SELECT a.QC_LBO_ID, b.LBO_CATEGORY, b.LBO_DEFECT_CODE, 
          IF(b.LBO_CATEGORY='GOOD', 1, 0) gddx,
          IF(c.DEFECT_CAT='AESTHETIC', 1, 0) defa,
          IF(c.DEFECT_CAT='FUNCTION', 1, 0) deff
        FROM qc_lbo_input a 
        LEFT JOIN qc_lbo_input_detail b 
        LEFT JOIN defect_lbo c ON b.LBO_DEFECT_CODE = c.DEFECT_CODE
        ON a.QC_LBO_ID = b.QC_LBO_ID
        WHERE INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O') <> 0 AND CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O','')) = '".$lbo_id."'
      ) a GROUP BY a.QC_LBO_ID
    ) b ON a.QC_LBO_ID = b.QC_LBO_ID
    LEFT JOIN toy_part c ON a.partx = c.PART_NUM
    LEFT JOIN qc_lbo_smpl d ON IFNULL(c.PART_TYPE, 'MNL') = d.lbo_smpl_type AND d.lbo_smpl_ins = IFNULL(a.QC_LBO_INSPECT_TYPE, 'N')
    AND a.QC_LBO_LOT BETWEEN d.lbo_smpl_lot_size_min AND d.lbo_smpl_lot_size_max
    ORDER BY a.QC_LBO_DATE, a.QC_LBO_TIME
    ";
  } else if ($section == 3){ //view lot detail
    $lot_id = $_GET['param_id'];
    $strSql ="
    SELECT 
    a.LBO_DETAIL_ID idx,
    CASE 
      WHEN c.DEFECT_CAT = 'AESTHETIC' THEN 'AESTHETIC'
      WHEN c.DEFECT_CAT = 'FUNCTION' THEN 'FUNCTION'
      WHEN IFNULL(c.DEFECT_CAT, 0) = 0 THEN 'GOOD' 
    END typex,
    b.QC_LBO_INSPECT_TYPE inspx,
    IFNULL(c.DEFECT_CODE,'') defx, IFNULL(c.DEFECT_NAME,'') def_namex,
    IFNULL(d.CBSD_PROC_DESC,'') procx, b.QC_LBO_LOT lotx, b.QC_LBO_SS ssx
    FROM qc_lbo_input_detail a 
    LEFT JOIN qc_lbo_input b ON a.QC_LBO_ID = b.QC_LBO_ID 
    LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
    LEFT JOIN toy_part_cbsd d ON a.LBO_PROCESS_ID = d.CBSD_ID
    WHERE a.QC_LBO_ID = '".$lot_id."';
    ";
  } else if ($section == 4){ //add lot list
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $prod_id = $_GET['prod_id'];
    $part_id = $_GET['part_id'];
    $insp_type = $_GET['inspect'];
    $lot_qty = $_GET['lot_qty'];
    $line = $_GET['line'];
    $group = $_GET['group'];

    $lot_ex = 'NULL';
    if (isset($_GET['lot_id'])) {
      $lot_ex = $_GET['lot_id'];
    }

    $lot_exs = 'NULL';
    if (isset($_GET['lot_seq'])) {
      $lot_exs = $_GET['lot_seq'];
    }

    $strSql = "
      SELECT (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) plan_id
      FROM plan_prod_daily a WHERE 
      (
        REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
        CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')
      ) = '".$prod_id."' LIMIT 1;
    ";
    //echo $strSql;

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $prod_id = $row['plan_id'];

    $lot_seq = 'NULL';
    if ($insp_type == 'N') {
      $lot_seq = "(
        SELECT (IFNULL(MAX(QC_LBO_SEQ), 0) + 1) QC_LBO_SEQ  
        FROM qc_lbo_input a WHERE a.QC_LBO_PLAN_ID = '".$prod_id."' 
        AND a.QC_LBO_INSPECT_TYPE = 'N'
      ) `QC_LBO_SEQ`";
    } else {
      $lot_seq = "NULL";
    }

    $strSql = "
      INSERT INTO `qc_lbo_input` (
        `QC_LBO_DATE`, `QC_LBO_TIME`, `QC_LBO_PLAN_ID`, 
        `QC_LBO_PLAN_QR`, `QC_LBO_PART`, `QC_LBO_LOT`, 
        `QC_LBO_SS`, `QC_LBO_HOUR_TARGET`, `QC_LBO_INSPECT_TYPE`, `QC_LBO_LOTX`, `QC_LBO_LOTS`, `QC_LBO_SEQ`,
        `QC_LBO_LINE`, `QC_LBO_GROUP`,
        `QC_LBO_ADD_ID`, `QC_LBO_ADD_TIME`, `QC_LBO_MOD_TIME`
      )
      SELECT CURDATE() QC_LBO_DATE, CURTIME() QC_LBO_TIME, '".$prod_id."' QC_LBO_PLAN_ID, 
        NULL QC_LBO_PLAN_QR, '".$part_id."' QC_LBO_PART, ".$lot_qty." QC_LBO_LOT, g.lbo_smpl_ss QC_LBO_SS,
        0 `QC_LBO_HOUR_TARGET`, '".$insp_type."' `QC_LBO_INSPECT_TYPE`, ".$lot_ex.", ".$lot_exs.", ".$lot_seq.",
        '".$line."' `QC_LBO_LINE`, '".$group."' `QC_LBO_GROUP`,
        ".$useridx." `QC_LBO_ADD_ID`,  NOW() `QC_LBO_ADD_TIME`, NOW() `QC_LBO_MOD_TIME`
      FROM toy_part f 
      LEFT JOIN qc_lbo_smpl g ON IFNULL(f.PART_TYPE,'MNL') = g.lbo_smpl_type 
      AND ".$lot_qty." BETWEEN g.lbo_smpl_lot_size_min 
      AND g.lbo_smpl_lot_size_max 
      AND '".$insp_type."' = g.lbo_smpl_ins
      WHERE f.part_num='".$part_id."';
    ";
    
    //echo $strSql;
    if (mysqli_query($conn, $strSql)) {
      $strSql = "SELECT MAX(QC_LBO_ID) last_id FROM qc_lbo_input WHERE QC_LBO_PLAN_ID='".$prod_id."';";
      $res = mysqli_query($conn, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $last_id = $row['last_id'];
    } else {
      $last_id = 0;
    }

    $strSql = "
      SELECT a.QC_LBO_ID lbo_idx, a.QC_LBO_DATE lbo_datex, a.QC_LBO_TIME lbo_timex, a.QC_LBO_INSPECT_TYPE lbo_insx,
      a.QC_LBO_LOT lbo_lotx, a.QC_LBO_SS lbo_ssx,  IFNULL(b.gdx, 0) lbo_gdx, IFNULL(b.defa, 0) lbo_defa, 
      IFNULL(b.defb, 0) lbo_deff, CONCAT(d.lbo_sampl_a, '/', d.lbo_sampl_r) arx, 'not checked yet' lbo_acc_statx, a.QC_LBO_LOTX lot_ex, a.QC_LBO_LOTS lot_exs, a.QC_LBO_SEQ lot_seq
      FROM qc_lbo_input a 
      LEFT JOIN (
        SELECT 1 idx, SUM(gdx) gdx, SUM(defa) defa, SUM(defb) defb  
        FROM (
          SELECT COUNT(*) gdx, 0 defa, 0 defb 
          FROM qc_lbo_input_detail b 
          WHERE b.QC_LBO_ID = '".$last_id."' AND b.LBO_CATEGORY='GOOD' UNION ALL
          SELECT 0 gdx, COUNT(*) defa, 0 defb
          FROM qc_lbo_input_detail b
          LEFT JOIN defect_lbo c ON b.LBO_DEFECT_CODE = c.DEFECT_CODE
          WHERE b.QC_LBO_ID = '".$last_id."' 
          AND b.LBO_CATEGORY='DEFECT' AND c.DEFECT_CAT = 'AESTHETIC' UNION ALL
          SELECT 0 gdx, 0 defa, COUNT(*) defb
          FROM qc_lbo_input_detail b 
          LEFT JOIN defect_lbo c ON b.LBO_DEFECT_CODE = c.DEFECT_CODE
          WHERE b.QC_LBO_ID = '".$last_id."' 
          AND b.LBO_CATEGORY='DEFECT' AND c.DEFECT_CAT = 'FUNCTION'
        ) b
      ) b ON 1 = b.idx
      LEFT JOIN toy_part c ON a.QC_LBO_PART = c.PART_NUM
      LEFT JOIN qc_lbo_smpl d ON IFNULL(c.PART_TYPE,'MNL') = d.lbo_smpl_type AND
      a.QC_LBO_LOT BETWEEN d.lbo_smpl_lot_size_min AND d.lbo_smpl_lot_size_max
      AND a.QC_LBO_INSPECT_TYPE = d.lbo_smpl_ins
      WHERE a.QC_LBO_ID ='".$last_id."';
    ";
  } else if ($section == 5){ //add defect list

    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $part_id = $_GET['part_id'];
    $defect_type = $_GET['def_type'];
    $strSql = "
      SELECT 'D' typex, a.DEFECT_CODE codex, a.DEFECT_NAME namex
      FROM defect_lbo a 
      WHERE " . ($defect_type == "A" ? "a.DEFECT_CAT = 'AESTHETIC'" : "a.DEFECT_CAT = 'FUNCTION'") . " 
      UNION ALL
      SELECT 'P' typex, a.CBSD_ID codex, a.CBSD_PROC_DESC namex 
      FROM toy_part_cbsd a 
      WHERE a.CBSD_PART_NUM = '".$part_id."';
    ";
  } else if ($section == 6){ //add lot detail
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $lot_id = $_GET['lot_id'];
    $defect_data = $_GET['defect_data'];
    $cat = 'GOOD';
    $prc = 'NULL';
    $def = 'NULL';

    $query_data = explode("-", $defect_data);
    if ($query_data[0] == 'G') {
      $cat = 'GOOD';
      $prc = 'NULL';
      $def = 'NULL';
    } else {
      $cat = 'DEFECT';
      $prc = ($query_data[1] == '0' ? "NULL" : $query_data[1]);
      $def = ($query_data[2] == '0' ? "NULL" : $query_data[2]);
    }

    //GET LAST SEQUEN
    $strSql = "
      SELECT COUNT(*) + 1 seqx 
      FROM qc_lbo_input_detail a WHERE a.QC_LBO_ID = " . $lot_id . ";
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $sequen = $row['seqx'];

    //INSERT DATA
    $strSql = "
      INSERT INTO `qc_lbo_input_detail` (
        `QC_LBO_ID`, `LBO_CATEGORY`, `LBO_SEQUENCE`, 
        `LBO_PROCESS_ID`, `LBO_DEFECT_CODE`, 
        `LBO_ADD_ID`, `LBO_ADD_TIME`
      ) VALUES (
        ".$lot_id.", '".$cat."', ".$sequen.", 
        ".$prc.", ".$def.", 
        ".$useridx.", NOW()
      );
    ";
    //echo $strSql;
    if (mysqli_query($conn, $strSql)) {
      //$strSql = "SELECT ".mysqli_insert_id($conn)." idx,'YES' resx, ".$sequen." seqx;";
      
      $strSql = "SELECT MAX(LBO_DETAIL_ID) last_id FROM qc_lbo_input_detail WHERE QC_LBO_ID='".$lot_id."';";
      $res = mysqli_query($conn, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $last_id = $row['last_id'];

      $strSql = "SELECT ".$last_id." idx,'YES' resx, ".$sequen." seqx;";
    } else {
      $strSql = "SELECT 0 idx, 'NO' resx, 0 seqx;";
    }

  } else if ($section == 7){ //del lot list
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $param_id = $_GET['param_id'];
    $detail = ''; $header = 'N';

    $strSql = "DELETE FROM qc_lbo_input_detail WHERE QC_LBO_ID ='".$param_id."';";
    if (mysqli_query($conn, $strSql)) {
      $detail = 'Y'; 
    } else {
      $detail = 'N';
    }

    $strSql = "DELETE FROM qc_lbo_input WHERE QC_LBO_ID ='".$param_id."';";
    if (mysqli_query($conn, $strSql)) {
      $header = 'Y'; 
    } else {
      $header = 'N';
    }

    if($header == 'Y') {
      $strSql = "SELECT 'Y' resx;";
    } else {
      $strSql = "SELECT 'N' resx;";
    }
  } else if ($section == 8){ //del lot detail
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 
    
    $param_id = $_GET['param_id'];
    $detail = ''; $header = 'N';
    $strSql = "DELETE FROM qc_lbo_input_detail WHERE LBO_DETAIL_ID ='".$param_id."';";
    //echo $strSql;
    if (mysqli_query($conn, $strSql)) {
      $detail = 'Y'; 
    } else {
      $detail = 'N';
    }

    if($detail == 'Y') {
      $strSql = "SELECT 'Y' resx;";
    } else {
      $strSql = "SELECT 'N' resx;";
    }

  } else if ($section == 9) { //lbo hourly accepted
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];

    $strSql = "
    SELECT datex, HOUR(timex_min) firsth, HOUR(timex_max) lasth, (HOUR(timex_max) - HOUR(timex_min)) + 1 sequenh
    FROM (
      SELECT sx.datex, MIN(timex) timex_min, MAX(timex) timex_max
      FROM (
        SELECT sa.lbo_id, plan_id, datex, timex, partx, inspecx, lotx, ssx, gddx, defx,  IF(IFNULL(defx,0)>IFNULL(sc.lbo_sampl_a, 0), 0, 1) accx
        FROM (
          SELECT lbo_id, plan_id, datex, timex, partx, inspecx, lotx, ssx, SUM(gddx) gddx, SUM(defx) defx 
          FROM (
            SELECT CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N','')) plan_id, a.QC_LBO_DATE datex, a.QC_LBO_TIME timex, a.QC_LBO_ID lbo_id, a.QC_LBO_PART partx, a.QC_LBO_INSPECT_TYPE inspecx, 
            a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, IF(b.LBO_CATEGORY='GOOD',1,0) gddx, IF(b.LBO_CATEGORY='DEFECT', 1, 0) defx
            FROM qc_lbo_input a 
            LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
            WHERE LEFT(a.QC_LBO_PLAN_ID, 8) = '" . str_replace("-", "", $date) . "' AND INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'N') <> 0 
            UNION ALL
            SELECT CONCAT(LEFT(a.QC_LBO_PLAN_ID, 19), REPLACE(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O','')) plan_id, a.QC_LBO_DATE datex, a.QC_LBO_TIME timex, a.QC_LBO_ID lbo_id, a.QC_LBO_PART partx, a.QC_LBO_INSPECT_TYPE inspecx, 
            a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, IF(b.LBO_CATEGORY='GOOD',1,0) gddx, IF(b.LBO_CATEGORY='DEFECT', 1, 0) defx
            FROM qc_lbo_input a 
            LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
            WHERE LEFT(a.QC_LBO_PLAN_ID, 8) = '" . str_replace("-", "", $date) . "' AND INSTR(RIGHT(a.QC_LBO_PLAN_ID, LENGTH(a.QC_LBO_PLAN_ID) - 19), 'O') <> 0
          ) a GROUP BY lbo_id, plan_id, datex, timex, partx, inspecx, lotx, ssx
        ) sa 
        LEFT JOIN toy_part sb ON sa.partx = sb.PART_NUM
        LEFT JOIN qc_lbo_smpl sc ON IFNULL(sb.PART_TYPE, 'MNL') = sc.lbo_smpl_type AND sc.lbo_smpl_ins = sa.inspecx
        AND sa.lotx BETWEEN sc.lbo_smpl_lot_size_min AND sc.lbo_smpl_lot_size_max
      ) sx WHERE sx.accx = 1
      GROUP BY sx.datex
    ) sx order by sx.datex;
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    //$prod_id = $row['plan_id'];

    // CASE WHEN sz.datex = '2024-06-25' AND sz.timex = 14 then lotx END `2024_06_25_14`,

    $str_col = "SELECT sz.plan_id"; $str_sum = "SELECT sz.plan_id";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        for($x = $row['firsth']; $x <= $row['lasth']; $x++){
          $str_sum = $str_sum . ", SUM(`" . str_replace("-","_", $row['datex']) . "_" . $x ."`) `" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          $str_col = $str_col . ", CASE WHEN sz.datex='" . $row['datex'] . "' AND sz.timex=" . $x ." THEN sz.lotx END `" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
        }
      }
    }
    $str_col = $str_col . " FROM (";
    $str_col = $str_col ."
    SELECT sx.plan_id, sx.datex, sx.timex, sx.partx, SUM(lotx) lotx
    FROM (
      SELECT sa.lbo_id, plan_id, datex, HOUR(timex) timex, partx, lotx, ssx, gddx, defx,  IF(IFNULL(defx,0)>IFNULL(sc.lbo_sampl_a, 0), 0, 1) accx
      FROM (
        SELECT lbo_id, plan_id, datex, timex, partx, inspecx, lotx, ssx, SUM(gddx) gddx, SUM(defx) defx 
        FROM (
          SELECT 
          REPLACE(REPLACE(a.QC_LBO_PLAN_ID,'N',''),'O','') plan_id, 
          a.QC_LBO_DATE datex, a.QC_LBO_TIME timex, 
          a.QC_LBO_ID lbo_id, a.QC_LBO_PART partx,
          a.QC_LBO_INSPECT_TYPE inspecx,  
          a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, IF(b.LBO_CATEGORY='GOOD',1,0) gddx, IF(b.LBO_CATEGORY='DEFECT', 1, 0) defx
          FROM qc_lbo_input a 
          LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
          WHERE LEFT(a.QC_LBO_PLAN_ID, 8) = '" . str_replace("-", "", $date) . "'
        ) a 
        WHERE (IFNULL(a.gddx, 0) + IFNULL(a.defx, 0)) <> 0
        GROUP BY lbo_id, plan_id, datex, timex, partx, inspecx, lotx, ssx
      ) sa 
      LEFT JOIN toy_part sb ON sa.partx = sb.PART_NUM
      LEFT JOIN qc_lbo_smpl sc ON IFNULL(sb.PART_TYPE, 'MNL') = sc.lbo_smpl_type AND sc.lbo_smpl_ins = sa.inspecx
      AND sa.lotx BETWEEN sc.lbo_smpl_lot_size_min AND sc.lbo_smpl_lot_size_max 
      AND '" . $date . "' BETWEEN sc.lbo_smpl_date_start AND sc.lbo_smpl_date_end  
    ) sx WHERE sx.accx = 1
    GROUP BY sx.plan_id, sx.datex, sx.timex, sx.partx
    ";
    $str_col = $str_col . " ) sz";

    $str_col = $str_sum . ' FROM (' . $str_col . ') sz GROUP BY sz.plan_id';
    //echo $str_col;
  
    $strSql = "
    SELECT a.linex, c.LINE_DESC line_namex, c.LINE_NAME_SPV spvx, 
      a.groupx, a.partx, d.PART_NAME part_namex, 
      d.PART_TYPE part_typex, a.plan_id group_id, a.plan, IFNULL(b.actual, 0) actual, 
      IFNULL(b.lot_qtyn, 0) acclx, e.*
    FROM (
      SELECT (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) plan_id, 
      a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_PART partx, SUM(a.PLAN_PROD_QTY) plan
      FROM plan_prod_daily a WHERE a.PLAN_PROD_DATE = '" . $date . "'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
      GROUP BY (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')),
      a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_GROUP_ORD, a.PLAN_PROD_PART
    ) a LEFT JOIN (
      SELECT plan_id, SUM(actual) actual, SUM(lotn) lotn, SUM(lot_qtyn) lot_qtyn 
      FROM (
        #PROD QTY
        SELECT plan_id, SUM(prodx) actual, 0 lotn, 0 lot_qtyn, 0 accn, 0 rejn
        FROM (
          SELECT a.OUT_PLAN_ID, REPLACE(REPLACE(a.OUT_PLAN_ID,'N',''),'O','') plan_id, SUM(a.OUT_PROD_QTY) prodx
          FROM output_prod_good a WHERE 
          IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D'
          AND a.OUT_PROD_DATE = '" . $date . "'
          GROUP BY a.OUT_PLAN_ID 
        ) a GROUP BY plan_id UNION ALL
        #LOT QTY NORMAL
        SELECT sa.plan_id, 0 actual, COUNT(lotx) lotx, SUM(lotx) lot_qtyx, SUM(accx) accx, (COUNT(lotx) - SUM(accx)) rejx
        FROM (
          SELECT * FROM (
            SELECT sa.lbo_id, plan_id, partx, lotx, ssx, gddx, defx,  IF(IFNULL(defx,0)>IFNULL(sc.lbo_sampl_a, 0), 0, 1) accx
            FROM (
              SELECT lbo_id, plan_id, partx, inspecx, lotx, ssx, SUM(gddx) gddx, SUM(defx) defx 
              FROM (
                SELECT 
                  REPLACE(REPLACE(a.QC_LBO_PLAN_ID,'N',''),'O','') plan_id, a.QC_LBO_ID lbo_id, 
                  a.QC_LBO_PART partx,
                  a.QC_LBO_INSPECT_TYPE inspecx,  
                  a.QC_LBO_LOT lotx, 
                  a.QC_LBO_SS ssx, IF(b.LBO_CATEGORY='GOOD',1,0) gddx, IF(b.LBO_CATEGORY='DEFECT', 1, 0) defx
                FROM qc_lbo_input a 
                LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
                WHERE LEFT(a.QC_LBO_PLAN_ID, 8) = '" . str_replace("-", "", $date) . "'
              ) a 
              WHERE (IFNULL(a.gddx, 0) + IFNULL(a.defx, 0)) <> 0
              GROUP BY lbo_id, plan_id, partx, inspecx, lotx, ssx
            ) sa 
            LEFT JOIN toy_part sb ON sa.partx = sb.PART_NUM
            LEFT JOIN qc_lbo_smpl sc ON IFNULL(sb.PART_TYPE, 'MNL') = sc.lbo_smpl_type AND sc.lbo_smpl_ins = sa.inspecx
            AND sa.lotx BETWEEN sc.lbo_smpl_lot_size_min AND sc.lbo_smpl_lot_size_max
            AND '" . $date . "' BETWEEN sc.lbo_smpl_date_start AND sc.lbo_smpl_date_end
          ) sx WHERE sx.accx = 1
        ) sa GROUP BY sa.plan_id
      ) a GROUP BY plan_id
    ) b ON a.plan_id = b.plan_id
    LEFT JOIN line c ON a.linex = c.LINE_CODE
    LEFT JOIN toy_part d ON a.partx = d.PART_NUM
    LEFT JOIN (
    ". $str_col ."
    ) e on e.plan_id = a.plan_id
    WHERE 1=1 " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND a.linex ='$line' " : "") . "
    " . (($group !="" && $group != "ALL") ? " AND a.groupx ='$group' " : "") . "
    " . (($style !="" && $style != "ALL") ? " AND (UCASE(a.partx) LIKE '%".strtoupper($style)."%' OR UCASE(d.PART_NAME) LIKE '%".strtoupper($style)."%')" : "") . "
    ORDER BY c.LINE_ORDR, a.groupx, a.partx;
    ";
    //echo '<pre>'. $strSql . '</pre>';
  }
}
//echo $strSql;
$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
