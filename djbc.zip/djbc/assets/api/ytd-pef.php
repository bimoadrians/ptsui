<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  if ($section == 1) { //LBO QUALITY DAILY + WEEKLY

    $date_to = $_GET["date_to"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $cat = $_GET["cat"];
    $def = $_GET["def"];
    $section_det = $_GET["section_det"];

    if ($section_det == '1'){
      $strSql = "
        #DAILY HIGLIGHT
        SELECT * FROM (
        SELECT '1' seqx, a.LBO_DEFECT_CODE defx, c.DEFECT_NAME defnx, c.DEFECT_CAT defcx, COUNT(a.LBO_DEFECT_CODE) defqx
        FROM qc_lbo_input_detail a 
        LEFT JOIN qc_lbo_input b ON a.QC_LBO_ID = b.QC_LBO_ID
        LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
        LEFT JOIN toy_part d ON d.PART_NUM = b.QC_LBO_PART
        LEFT JOIN line e on b.QC_LBO_LINE = e.LINE_CODE
        WHERE b.QC_LBO_DATE='$date_to' 
        AND b.QC_LBO_INSPECT_TYPE = 'N'
        AND a.LBO_CATEGORY = 'DEFECT'
        #AND c.DEFECT_CAT = 'AESTHETIC'
        ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(d.PART_TYPE, 'MNL') ='$cat' " : "")."
        ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
        ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
        GROUP BY a.LBO_DEFECT_CODE, c.DEFECT_NAME, c.DEFECT_CAT
      ) sa ORDER BY defqx DESC;
      ";
    } else if ($section_det == '2'){
      $strSql = "
        #WEEKLY PERFORMANCE
        SELECT '2' seqx, DAYOFWEEK(datex) datex, SUM(ssx) ssx, SUM(defax) defax,SUM(deffx) deffx, (SUM(defax) + SUM(deffx)) deftx 
        FROM (
          SELECT datex, idx, ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx
          FROM (
            SELECT b.QC_LBO_DATE datex, b.QC_LBO_ID idx, b.QC_LBO_SS ssx, 
              CASE WHEN a.LBO_CATEGORY = 'GOOD' THEN 1 ELSE 0 END goodx, 
              CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END defax,
              CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END deffx
            FROM qc_lbo_input b
            LEFT JOIN qc_lbo_input_detail a ON a.QC_LBO_ID = b.QC_LBO_ID
            LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
            LEFT JOIN toy_part d ON d.PART_NUM = b.QC_LBO_PART
            LEFT JOIN line e on b.QC_LBO_LINE = e.LINE_CODE
            WHERE b.QC_LBO_DATE BETWEEN ADDDATE('$date_to', INTERVAL ((DAYOFWEEK('$date_to')-1)*-1) DAY) AND '$date_to' 
            AND b.QC_LBO_INSPECT_TYPE = 'N'
            ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(d.PART_TYPE, 'MNL') ='$cat' " : "")."
            ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
            ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
          ) sa GROUP BY datex, idx, ssx
        ) sa WHERE (goodx + defax + deffx) <> 0
        GROUP BY DAYOFWEEK(datex);
      ";
    } else if ($section_det == '3'){
      $strSql = "
        #WEEKLY DEFECT NAME
        SELECT * FROM (
        SELECT '3' seqx, a.LBO_DEFECT_CODE defx, c.DEFECT_NAME defnx, c.DEFECT_CAT defcx, COUNT(a.LBO_DEFECT_CODE) defqx
        FROM qc_lbo_input_detail a 
        LEFT JOIN qc_lbo_input b ON a.QC_LBO_ID = b.QC_LBO_ID
        LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
        LEFT JOIN toy_part d ON d.PART_NUM = b.QC_LBO_PART
        LEFT JOIN line e on b.QC_LBO_LINE = e.LINE_CODE
        WHERE b.QC_LBO_DATE BETWEEN ADDDATE('$date_to', INTERVAL ((DAYOFWEEK('$date_to')-1)*-1) DAY) AND '$date_to'
        AND b.QC_LBO_INSPECT_TYPE = 'N'
        AND a.LBO_CATEGORY = 'DEFECT'
        #AND c.DEFECT_CAT = 'AESTHETIC'
        ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(d.PART_TYPE, 'MNL') ='$cat' " : "")."
        ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
        ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
        GROUP BY a.LBO_DEFECT_CODE, c.DEFECT_NAME, c.DEFECT_CAT
      ) sa ORDER BY defqx DESC;
      ";
    } else if ($section_det == '4'){
      $strSql = "
        #WEEKLY PART
        SELECT seqx, partx, partnx, linex, linenx, defx, IFNULL(procx, '') procx  
        FROM (
          SELECT '4' seqx, partx, partnx, linex, linenx, COUNT(defx) defx, GROUP_CONCAT(DISTINCT procx) procx 
          FROM (
            SELECT b.QC_LBO_PART partx, f.PART_NAME partnx, b.QC_LBO_LINE linex, e.LINE_DESC linenx, a.LBO_DEFECT_CODE defx, d.CBSD_PROC_DESC procx
            FROM qc_lbo_input_detail a 
            LEFT JOIN qc_lbo_input b ON a.QC_LBO_ID = b.QC_LBO_ID
            LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
            LEFT JOIN toy_part_cbsd d ON a.LBO_PROCESS_ID = d.CBSD_ID
            LEFT JOIN line e on b.QC_LBO_LINE = e.LINE_CODE
            LEFT JOIN toy_part f ON f.PART_NUM = b.QC_LBO_PART
            WHERE b.QC_LBO_DATE BETWEEN ADDDATE('$date_to', INTERVAL ((DAYOFWEEK('$date_to')-1)*-1) DAY) AND '$date_to'
            AND b.QC_LBO_INSPECT_TYPE = 'N'
            AND a.LBO_CATEGORY = 'DEFECT'
            #AND c.DEFECT_CAT = 'AESTHETIC'
            ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(f.PART_TYPE, 'MNL') ='$cat' " : "")."
            ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
            ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
          ) sa GROUP BY partx, partnx, linex, linenx
        ) sa ORDER BY defx DESC
      ";
    }    

    //var_dump($strSql);

  } else if ($section == 2) { //LBO QUALITY FULL YEAR
    $date_to = $_GET["date_to"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $cat = $_GET["cat"];
    $def = $_GET["def"];
    $section_det = $_GET["section_det"];

    $curDate = getdate();
    $curYear = (int)$curDate['year'];
    $curYearTo = (int)substr($date_to, 0, 4);

    if ($section_det == '1'){
      $strSql = "
        #QUARTERLY
        SELECT '1' seqx, sa.quartx, IFNULL(sb.ssx, 0) ssx, IFNULL(sb.goodx, 0) goodx, IFNULL(sb.defax, 0) defax, IFNULL(sb.deffx, 0) deffx
        FROM (
          SELECT 1 quartx UNION ALL
          SELECT 2 quartx UNION ALL
          SELECT 3 quartx UNION ALL
          SELECT 4 quartx
        ) sa LEFT JOIN ( 
          SELECT quartx, SUM(ssx) ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx 
          FROM (
            SELECT quartx, datex, idx, ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx
            FROM (
              SELECT 
                CASE 
                WHEN MONTH(b.QC_LBO_DATE) IN (1,2,3) THEN 1 
                WHEN MONTH(b.QC_LBO_DATE) IN (4,5,6) THEN 2
                WHEN MONTH(b.QC_LBO_DATE) IN (7,8,9) THEN 3
                WHEN MONTH(b.QC_LBO_DATE) IN (10,11,12) THEN 4
                END quartx,			
                b.QC_LBO_DATE datex, b.QC_LBO_ID idx, b.QC_LBO_SS ssx, 
                CASE WHEN a.LBO_CATEGORY = 'GOOD' THEN 1 ELSE 0 END goodx, 
                CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END defax,
                CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END deffx
              FROM qc_lbo_input b            
              LEFT JOIN qc_lbo_input_detail a ON a.QC_LBO_ID = b.QC_LBO_ID
              LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
              LEFT JOIN toy_part d ON d.PART_NUM = b.QC_LBO_PART
              LEFT JOIN line e on e.LINE_CODE = b.QC_LBO_LINE
              WHERE YEAR(b.QC_LBO_DATE) = YEAR('$date_to') AND b.QC_LBO_DATE <= '$date_to'
              ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(d.PART_TYPE, 'MNL') ='$cat' " : "")."
              ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
              ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
              AND b.QC_LBO_INSPECT_TYPE = 'N' 			
            ) sa GROUP BY quartx, datex, idx, ssx
          ) sa WHERE (goodx + defax + deffx) <> 0
          GROUP BY quartx 
        ) sb ON sa.quartx = sb.quartx
      ";
    } else if ($section_det == '2'){
     $strSql = "
        #MONTHLY
        SELECT '2' seqx, sa.monthx, IFNULL(sb.ssx, 0) ssx, IFNULL(sb.goodx, 0) goodx, IFNULL(sb.defax, 0) defax, IFNULL(sb.deffx, 0) deffx
        FROM (
          SELECT 1 monthx UNION ALL
          SELECT 2 monthx UNION ALL
          SELECT 3 monthx UNION ALL
          SELECT 4 monthx UNION ALL
          SELECT 5 monthx UNION ALL
          SELECT 6 monthx UNION ALL
          SELECT 7 monthx UNION ALL
          SELECT 8 monthx UNION ALL
          SELECT 9 monthx UNION ALL
          SELECT 10 monthx UNION ALL
          SELECT 11 monthx UNION ALL
          SELECT 12 monthx
        ) sa LEFT JOIN ( 
          SELECT MONTH(datex) monthx, SUM(ssx) ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx 
          FROM (
            SELECT datex, idx, ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx
            FROM (
              SELECT 
               b.QC_LBO_DATE datex, b.QC_LBO_ID idx, b.QC_LBO_SS ssx, 
                CASE WHEN a.LBO_CATEGORY= 'GOOD' THEN 1 ELSE 0 END goodx, 
                CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END defax,
                CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END deffx
              FROM qc_lbo_input b            
              LEFT JOIN qc_lbo_input_detail a ON a.QC_LBO_ID = b.QC_LBO_ID
              LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
              LEFT JOIN toy_part d ON d.PART_NUM = b.QC_LBO_PART
              LEFT JOIN line e on e.LINE_CODE = b.QC_LBO_LINE
              WHERE YEAR(b.QC_LBO_DATE) = YEAR('$date_to') AND b.QC_LBO_DATE <= '$date_to'
              ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(d.PART_TYPE, 'MNL') ='$cat' " : "")."
              ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
              ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
              AND b.QC_LBO_INSPECT_TYPE = 'N' 			
            ) sa GROUP BY datex, idx, ssx
          ) sa WHERE (goodx + defax + deffx) <> 0
          GROUP BY MONTH(datex) 
        ) sb ON sa.monthx = sb.monthx
      ";
    } else if ($section_det == '3'){
      $strSql = "
        #YEARLY DEFECT NAME
        SELECT * FROM (
          SELECT '3' seqx, a.LBO_DEFECT_CODE defx, c.DEFECT_NAME defnx, c.DEFECT_CAT defcx, COUNT(a.LBO_DEFECT_CODE) defqx
          FROM qc_lbo_input_detail a 
          LEFT JOIN qc_lbo_input b ON a.QC_LBO_ID = b.QC_LBO_ID
          LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
          LEFT JOIN toy_part d ON d.PART_NUM = b.QC_LBO_PART
          LEFT JOIN line e on e.LINE_CODE = b.QC_LBO_LINE
          WHERE YEAR(b.QC_LBO_DATE) = YEAR('$date_to') AND b.QC_LBO_DATE <= '$date_to'
          AND b.QC_LBO_INSPECT_TYPE = 'N'
          AND a.LBO_CATEGORY = 'DEFECT'
          ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(d.PART_TYPE, 'MNL') ='$cat' " : "")."
          ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
          ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
          #AND c.DEFECT_CAT = 'AESTHETIC'
          GROUP BY a.LBO_DEFECT_CODE, c.DEFECT_NAME, c.DEFECT_CAT
        ) sa ORDER BY defqx DESC LIMIT 15;
      ";
    } else if ($section_det == '4'){
      
      $curxDate = new DateTime($date_to);
      $curxWeek =  (int)$curxDate->format("w");
      $curxAdd = ' + '.((6 - $curxWeek) + 1) .' days';
      $curxEnd = New DateTime(date('Y-m-d', strtotime($date_to.' '. $curxAdd)));
      $curxSta = New DateTime($curxEnd->format("Y").'-01-01');
      $curxInv =  DateInterval::createFromDateString('1 day');
      $curxPer = new DatePeriod($curxSta, $curxInv, $curxEnd);

      $strSql = "SELECT * FROM (";
      foreach ($curxPer as $dt) {
        if ($dt->format("w") == "6") {
          //echo $dt->format("Y-m-d").'<br>';
          $strSql .= "
            SELECT '".$dt->format("Y-m-d")."' weekx UNION ALL";
        }
      }
      $strSql =  substr($strSql, 0, (strlen($strSql) - 9));
      $strSql .="
        ) a LEFT JOIN (
          SELECT '4' seqx, weekx, SUM(ssx) ssx, SUM(defax) defax,SUM(deffx) deffx, (SUM(defax) + SUM(deffx)) deftx 
          FROM (
            SELECT ADDDATE(datex,INTERVAL (7-DAYOFWEEK(datex)) DAY) weekx,  datex, idx, ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx
            FROM (
              SELECT b.QC_LBO_DATE datex, b.QC_LBO_ID idx, b.QC_LBO_SS ssx, 
                CASE WHEN a.LBO_CATEGORY = 'GOOD' THEN 1 ELSE 0 END goodx, 
                CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END defax,
                CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END deffx
              FROM qc_lbo_input b
              LEFT JOIN qc_lbo_input_detail a ON a.QC_LBO_ID = b.QC_LBO_ID
              LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
              LEFT JOIN toy_part d ON d.PART_NUM = b.QC_LBO_PART
              LEFT JOIN line e on b.QC_LBO_LINE = e.LINE_CODE
              WHERE b.QC_LBO_DATE BETWEEN '".$curxSta->format("Y-m-d")."' AND '$date_to'
              AND b.QC_LBO_INSPECT_TYPE = 'N'
              ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(d.PART_TYPE, 'MNL') ='$cat' " : "")."
              ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
              ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
            ) sa GROUP BY datex, idx, ssx
          ) sa WHERE (goodx + defax + deffx) <> 0
          GROUP BY weekx
        ) b on a.weekx = b.weekx
      "; 
    } else if ($section_det == '5'){

      $curYear =  (int)(substr($date_to, 0, 4));
      $strYoy = ""; 
      $strYear = "";
      for ($i = 2022; $i<=$curYear; $i++){
        $strYear .= "
          SELECT '$i' yearx UNION ALL";
      }
      $strYear = substr($strYear, 0, strlen($strYear)-9);

      for ($i = 2022; $i<=($curYear-1); $i++){
        $strYoy .= "
          SELECT ytd_year yearx, SUM(ytd_ss) ssx, SUM(ytd_good) goodx, SUM(ytd_defa) defax, SUM(ytd_deff) deffx 
          FROM qc_lbo_ytd a
          LEFT join line b on a.ytd_line = b.LINE_CODE
          WHERE ytd_year = $i 
          ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(a.ytd_part_cat, 'MNL') ='$cat' " : "")."
          ".(($unit !="" && $unit != "ALL") ? " AND b.LINE_PREF ='$unit' " : "")."
          ".(($line !="" && $line != "ALL") ? " AND b.LINE_CODE ='$line' " : "")."
          GROUP BY ytd_year UNION ALL";
      }
      $strYoy = substr($strYoy, 0, strlen($strYoy)-9);

      $strSql = "
      #MONTHLY
      SELECT '5' seqx, sa.yearx, IFNULL(sb.ssx, 0) ssx, IFNULL(sb.goodx, 0) goodx, IFNULL(sb.defax, 0) defax, IFNULL(sb.deffx, 0) deffx
      FROM (
        $strYear
      ) sa LEFT JOIN ( 
        SELECT YEAR(datex) yearx, SUM(ssx) ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx 
        FROM (
          SELECT datex, idx, ssx, SUM(goodx) goodx, SUM(defax) defax, SUM(deffx) deffx
          FROM (
            SELECT 
            b.QC_LBO_DATE datex, b.QC_LBO_ID idx, b.QC_LBO_SS ssx, 
              CASE WHEN a.LBO_CATEGORY = 'GOOD' THEN 1 ELSE 0 END goodx, 
              CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END defax,
              CASE WHEN a.LBO_CATEGORY = 'DEFECT' AND c.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END deffx
            FROM qc_lbo_input b            
            LEFT JOIN qc_lbo_input_detail a ON a.QC_LBO_ID = b.QC_LBO_ID
            LEFT JOIN defect_lbo c ON a.LBO_DEFECT_CODE = c.DEFECT_CODE
            LEFT JOIN toy_part d ON d.PART_NUM = b.QC_LBO_PART
            LEFT JOIN line e on e.LINE_CODE = b.QC_LBO_LINE
            WHERE YEAR(b.QC_LBO_DATE) = YEAR('$date_to') AND b.QC_LBO_DATE <= '$date_to'
            ".(($cat !="" && $cat != "ALL") ? " AND IFNULL(d.PART_TYPE, 'MNL') ='$cat' " : "")."
            ".(($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "")."
            ".(($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "")."
            AND b.QC_LBO_INSPECT_TYPE = 'N' 			
          ) sa GROUP BY datex, idx, ssx
        ) sa WHERE (goodx + defax + deffx) <> 0
        GROUP BY year(datex) UNION ALL
        $strYoy
      ) sb ON sa.yearx = sb.yearx
      ";
    }
  }
}

//echo '<pre>'. $strSql . '</pre>';
$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
