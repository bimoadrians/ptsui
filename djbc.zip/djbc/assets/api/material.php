<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

// require 'vendor/autoload.php';
// use Firebase\JWT\JWT;

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {

  if ($section == 1){ //get waste list
    
    $part = str_replace("'", "\'", strtoupper($_GET['part']));
    $strSql = "
      SELECT a.MATL_CODE pnx, a.MATL_NAME desx, a.MATL_UNIT unitx, 
        IFNULL(a.MATL_CAT, 'OTHER') catx, IFNULL(b.count_qtyg,'') qtygx, IFNULL(b.count_qtys,'') qtysx,
        IFNULL(b.count_mod_date, b.count_add_date) moddx, IFNULL(c.USER_INISIAL,'') moddux
      FROM material a 
      LEFT JOIN material_waste_count b ON a.MATL_CODE = b.count_pn AND b.count_date ='2025-02-01'
      LEFT JOIN xref_user_web c ON IFNULL(b.count_mod_id, b.count_add_id) = c.USER_ID
      WHERE (UCASE(a.MATL_CODE) LIKE '%$part%' OR UCASE(a.MATL_NAME) LIKE '%$part%')
      ORDER BY IFNULL(b.count_qtyg,'') DESC, IFNULL(a.MATL_CAT, 'OTHER') ASC, a.MATL_CODE ASC;
    ";
  } else if ($section == 2){ //save count
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $type = $_POST['type'];
    $part = $_POST['part'];
    $qty = doubleval($_POST['qty']);
    
    $strSql = "
      SELECT COUNT(*) rec_count 
      FROM material_waste_count WHERE count_date ='2025-02-01' AND count_pn='$part';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['rec_count'];
        
    if ($rec_count == 0){ //INSERT
      if ($type=='good') {
        $strSql = "
          INSERT INTO `material_waste_count` (`count_date`, `count_pn`, `count_qtyg`, `count_add_id`, `count_add_date`) 
          VALUES ('2025-02-01', '$part', '$qty', $useridx, NOW());
        ";
      } else {
        $strSql = "
          INSERT INTO `material_waste_count` (`count_date`, `count_pn`, `count_qtys`, `count_add_id`, `count_add_date`) 
          VALUES ('2025-02-01', '$part', '$qty', $useridx, NOW());
        ";
      }
    } else { //UPDATE
      if ($type=='good') {
        $strSql ="
          UPDATE `material_waste_count` SET 
          `count_qtyg`='$qty',
          `count_mod_id`='$useridx',
          `count_mod_date`=NOW() 
          WHERE `count_date`='2025-02-01' AND `count_pn`='$part';
        ";
      } else {
        $strSql ="
          UPDATE `material_waste_count` SET 
          `count_qtys`='$qty',
          `count_mod_id`='$useridx',
          `count_mod_date`=NOW() 
          WHERE `count_date`='2025-02-01' AND `count_pn`='$part';
        ";
      }
    }

    if (mysqli_query($conn, $strSql)) {
      $msgx = '';
      $action = 'TRUE';
    } else {
      $msgx = 'An error occurred, please try again later.';
      $action = 'FALSE';
    }
   
    $strSql = "SELECT '". $action ."' actionx, '$msgx' msgx;";
  
  } else if ($section == 3){ //VIEW-STORAGE LOCATION 
    $area = $_GET['area'];
    $sect = $_GET['sect'];
    $strSql = "
      SELECT `storage_id` idx, `storage_area` areax, `storage_area_i` areaix, 
        `storage_area_o` areaox, `storage_section` secx, `storage_section_col` colx, 
        `storage_section_level` levx, `storage_alias` aliasx
      FROM ic_storage WHERE 1=1 " 
      .(($area !="" && $area != "ALL") ? "AND storage_area='$area'" : "").""
      .(($sect !="") ? "AND storage_alias LIKE '%$sect%'" : "")."
      ORDER BY storage_area_o, storage_section, storage_section_col, storage_section_level ASC;
    ";
    //var_dump($strSql);
  } else if ($section == 4){ //ADD-STORAGE LOCATION 

    $area = $_POST['area'];
    $areaCur = "";
    $areaOrd = "";
    if ($area == 'GOOD STORAGE') {
      $areaCur = "GS";
      $areaOrd = "1";
    } else if ($area == 'WIP') {
      $areaCur = "WIP";
      $areaOrd = "2";
    } else if ($area == 'FINISH COSTUME') {
      $areaCur = "FC";
      $areaOrd = "3";
    }

    $sec = strtoupper($_POST['sec']);
    $secf = (int)$_POST['secf'];
    $sect = (int)$_POST['sect'];
    $levf = (int)$_POST['levf'];
    $levt = (int)$_POST['levt'];
    
    $action = "";
    $msgx = "";
    if (trim($sec) != "") {
      for($i = $secf; $i <= $sect; $i++){
        for ($j = $levf; $j <= $levt; $j++){
          $strAlias = $areaCur."-".$sec.$i."-L".$j;
          $strSql = "
            SELECT COUNT(*) rec_count 
            FROM ic_storage WHERE storage_alias ='$strAlias';
          ";
          $res = mysqli_query($conn, $strSql);
          $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
          $rec_count = $row['rec_count'];              
          if ($rec_count == 0){
            $strSql = "
              INSERT INTO `ic_storage` (`storage_area`, `storage_area_i`, `storage_area_o`, `storage_section`, `storage_section_col`, `storage_section_level`, `storage_alias`, `storage_add_id`, `storage_add_date`) 
              VALUES (
              '$area', '$areaCur', $areaOrd, '$sec', $i, $j, '$strAlias', $useridx, NOW()
              );
            ";
            if (mysqli_query($conn, $strSql)) {
              $msgx = '';
              $actx = 'TRUE';
            } else {
              $msgx = 'An error occurred, please try again later.';
              $actx = 'FALSE';
            }
            //var_dump($strSql);
          }
        }        
      }
      $strSql = "SELECT '$actx' actx, '$msgx' msgx";
    } else {
      $strSql = "SELECT 'FALSE' actx, 'Invalid section' msgx";
    }    
  } else if ($section == 5){ //DEL-STORAGE LOCATION 
    $alias = $_POST['alias'];
    $strSql="DELETE FROM ic_storage WHERE storage_alias='$alias';";
    if (mysqli_query($conn, $strSql)) {
      $actx = 'TRUE'; $msgx = ''; 
    } else {
      $actx = 'FALSE'; $msgx = 'An error occurred, please try again later.';
    }
    $strSql = "SELECT '$actx' actx, '$msgx' msgx, '$alias' aliasx;";
  } else if ($section == 6){ //REQUIRMENT MATERIAL BY PLAN
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $mtype = '';

    if ($_GET["mtype"] == 'D') {
      $mtype = 'D/C';
    } else if ($_GET["mtype"] == 'A'){
      $mtype = 'OTHER';
    }

    // SELECT datex, partx, partnx, prefx, linex, linedx, leadx, 
    //   matlx, yieldx, matlnx, catx, matlux, lineox, SUM(planx) planx
    //   FROM (
    //     SELECT a.PLAN_PROD_DATE datex, a.PLAN_PROD_PART partx, c.PART_NAME partnx, a.PLAN_PROD_LINE_CODE linex,
    //       b.LINE_PREF prefx, b.LINE_DESC linedx, b.LINE_NAME_SPV leadx, b.LINE_ORDR lineox, a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_QTY planx, 
    //       d.PART_MATL_CODE matlx, d.PART_MATL_QTY yieldx, e.MATL_NAME matlnx, e.MATL_CAT catx, e.MATL_UNIT matlux
    //     FROM plan_prod_daily a 
    //     LEFT JOIN line b ON a.PLAN_PROD_LINE_CODE = b.LINE_CODE
    //     LEFT JOIN toy_part c ON a.PLAN_PROD_PART = c.PART_NUM
    //     LEFT JOIN toy_part_matl d ON a.PLAN_PROD_PART = d.PART_NUM
    //     LEFT JOIN material e ON d.PART_MATL_CODE = e.MATL_CODE
    //     WHERE a.PLAN_PROD_DATE='$date'"
    //     .(($unit !="" && $unit != "ALL") ? "AND b.LINE_PREF='$unit'" : "")
    //     .(($line !="" && $line != "ALL") ? "AND a.PLAN_PROD_LINE_CODE='$line'" : "")
    //     .(($mtype !="" && $mtype != "ALL") ? "AND e.MATL_CAT='$mtype'" : "")."
    //   ) a 
    //   GROUP BY datex, partx, partnx, prefx, linex, linedx, leadx, 
    //   matlx, yieldx, matlnx, catx, matlux, lineox

    $strSql = "
    SELECT sa.*, IFNULL(sb.locx, '') locx 
    FROM (
      SELECT datex, partx, partnx, prefx, 
      matlx, yieldx, matlnx, catx, matlux, SUM(planx) planx
      FROM (
        SELECT a.PLAN_PROD_DATE datex, a.PLAN_PROD_PART partx, c.PART_NAME partnx, a.PLAN_PROD_LINE_CODE linex,
          b.LINE_PREF prefx, b.LINE_DESC linedx, b.LINE_NAME_SPV leadx, b.LINE_ORDR lineox, a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_QTY planx, 
          d.PART_MATL_CODE matlx, d.PART_MATL_QTY yieldx, e.MATL_NAME matlnx, e.MATL_CAT catx, e.MATL_UNIT matlux
        FROM plan_prod_daily a 
        LEFT JOIN line b ON a.PLAN_PROD_LINE_CODE = b.LINE_CODE
        LEFT JOIN toy_part c ON a.PLAN_PROD_PART = c.PART_NUM
        LEFT JOIN toy_part_matl d ON a.PLAN_PROD_PART = d.PART_NUM
        LEFT JOIN material e ON d.PART_MATL_CODE = e.MATL_CODE
        WHERE a.PLAN_PROD_DATE='$date'"
        .(($unit !="" && $unit != "ALL") ? "AND b.LINE_PREF='$unit'" : "")
        .(($line !="" && $line != "ALL") ? "AND a.PLAN_PROD_LINE_CODE='$line'" : "")
        .(($mtype !="" && $mtype != "ALL") ? "AND e.MATL_CAT='$mtype'" : "")."
      ) a 
      GROUP BY datex, partx, partnx, prefx,
      matlx, yieldx, matlnx, catx, matlux
    ) sa 
    LEFT JOIN (
      SELECT a.MAT_SCAN_PN matlx, GROUP_CONCAT(DISTINCT a.MAT_SCAN_RAK SEPARATOR ', ') locx
      FROM material_raw_scan_in a 
      WHERE IFNULL(a.MAT_SCAN_RAK, '') NOT IN ('WIP-X0-L0','') AND IFNULL(a.MAT_SCAN_RAK, '') IN (
        SELECT storage_alias FROM ic_storage a WHERE a.storage_area = 'GOOD STORAGE'
      )
      GROUP BY a.MAT_SCAN_PN
    ) sb ON sa.matlx = sb.matlx
    ORDER BY partnx, prefx
    ";

      
  } else if ($section == 7) { // STOCK BY LOCATOR

    $matl = strtoupper($_GET["matl"]);
    $stor = strtoupper($_GET["stor"]);

    $strSql = "    
    SELECT a.*, b.MATL_NAME pndx, b.MATL_UNIT unitx, b.MATL_CAT catx 
    FROM (
      SELECT a.MAT_SCAN_RAK locx, a.MAT_SCAN_PN pnx, SUM(MAT_SCAN_QTYB) qtyx 
      FROM material_raw_scan_in a 
      WHERE IFNULL(a.MAT_SCAN_RAK, '') NOT IN ('WIP-X0-L0','')
      GROUP BY a.MAT_SCAN_RAK, a.MAT_SCAN_PN
    ) a
    LEFT JOIN material b ON a.pnx = b.MATL_CODE 
    WHERE a.locx IN (SELECT storage_alias FROM ic_storage a WHERE a.storage_area = 'GOOD STORAGE')"
    .(($matl !="" && $matl != "ALL") ? "AND (UCASE(b.MATl_CODE) LIKE '%$matl%' OR UCASE(b.MATl_NAME) LIKE '%$matl%')" : "")
    .(($stor !="" && $stor != "ALL") ? "AND a.locx LIKE '%$stor%'" : "")."
    ORDER BY a.locx, a.pnx
    ";
  } else if ($section == 8) { // WIP COUNT SUMMARY
    $date = $_GET["date"];
    $matl = strtoupper($_GET["matl"]);

    $strSql = "
    SELECT * FROM (
      SELECT a.matlx, sb.MATL_NAME matlnx, sb.MATL_UNIT matlux, IFNULL(sb.MATL_CAT, 'OTHER') matlcx, SUM(wip_adm_a) wip_adm_a, SUM(wip_line_a) wip_line_a, SUM(wip_lbo_a) wip_lbo_a, SUM(wip_adm_b) wip_adm_b, SUM(wip_line_b) wip_line_b, SUM(wip_lbo_b) wip_lbo_b  
      FROM (
        SELECT 
          'WIP-ADM-A' locx, 
          a.count_matl matlx,  (IFNULL(count_fcg, 0) + IFNULL(count_fcr, 0) + IFNULL(count_dcs, 0) + IFNULL(count_dcu, 0)) wip_adm_a, 0 wip_line_a, 0 wip_lbo_a, 0 wip_adm_b, 0 wip_line_b, 0 wip_lbo_b
        FROM material_raw_wip_count a 
        WHERE a.count_date='$date' AND count_line_code = '80'
        GROUP BY a.count_line_code, a.count_matl UNION ALL

        SELECT 
          'WIP-LINE-A' locx, 
          a.count_matl, 0 wip_adm_a,  (IFNULL(count_fcg, 0) + IFNULL(count_fcr, 0) + IFNULL(count_dcs, 0) + IFNULL(count_dcu, 0)) wip_line_a, 0 wip_lbo_a, 0 wip_adm_b, 0 wip_line_b, 0 wip_lbo_b
        FROM material_raw_wip_count a 
        LEFT JOIN line b ON a.count_line_code = b.LINE_CODE
        WHERE a.count_date='$date' AND count_line_code NOT IN ('80', '81') AND b.LINE_PREF = 'A'
        GROUP BY a.count_line_code, a.count_matl UNION ALL
        
        SELECT 'WIP-LBO-A' locx, c.PART_MATL_CODE matlx, 
          0 wip_adm_a, 0 wip_line_a, (a.transfer_qty * c.PART_MATL_QTY) wip_lbo_a, 0 wip_adm_b, 0 wip_line_b, 0 wip_lbo_b
        FROM wip_count_scan a 
        LEFT JOIN line b ON b.LINE_CODE = a.transfer_line
        LEFT JOIN toy_part_matl c ON a.transfer_part = c.PART_NUM
        WHERE a.transfer_date ='$date' AND b.LINE_PREF = 'A' UNION ALL
        
        SELECT 
          'WIP-ADM-B' locx, 
          a.count_matl, 0 wip_adm_a,  0 wip_line_a, 0 wip_lbo_a, (IFNULL(count_fcg, 0) + IFNULL(count_fcr, 0) + IFNULL(count_dcs, 0) + IFNULL(count_dcu, 0)) wip_adm_b, 0 wip_line_b, 0 wip_lbo_b
        FROM material_raw_wip_count a 
        WHERE a.count_date='$date' AND count_line_code = '81'
        GROUP BY a.count_line_code, a.count_matl UNION ALL
        
        SELECT 
          'WIP-LINE-B' locx, 
          a.count_matl,  0 wip_adm_a,  0 wip_line_a, 0 wip_lbo_a, 0 wip_adm_b, (IFNULL(count_fcg, 0) + IFNULL(count_fcr, 0) + IFNULL(count_dcs, 0) + IFNULL(count_dcu, 0)) wip_line_b, 0 wip_lbo_b
        FROM material_raw_wip_count a 
        LEFT JOIN line b ON a.count_line_code = b.LINE_CODE
        WHERE a.count_date='$date' AND count_line_code NOT IN ('80', '81') AND b.LINE_PREF = 'B'
        GROUP BY a.count_line_code, a.count_matl UNION ALL
        
        SELECT 'WIP-LBO-B' locx, c.PART_MATL_CODE matlx, 
          0 wip_adm_a,  0 wip_line_a, 0 wip_lbo_a, 0 wip_adm_b, 0 wip_line_b, (a.transfer_qty * c.PART_MATL_QTY) wip_lbo_b
        FROM wip_count_scan a 
        LEFT JOIN line b ON b.LINE_CODE = a.transfer_line
        LEFT JOIN toy_part_matl c ON a.transfer_part = c.PART_NUM
        WHERE a.transfer_date ='$date' AND b.LINE_PREF = 'B'
      
        ) a LEFT JOIN material sb ON a.matlx = sb.MATL_CODE 
      WHERE 1=1 "
      .(($matl !="" && $matl != "ALL") ? "AND (UCASE(sb.MATl_CODE) LIKE '%$matl%' OR UCASE(sb.MATl_NAME) LIKE '%$matl%')" : "").
      "GROUP BY a.matlx, sb.MATL_NAME, sb.MATL_UNIT, sb.MATL_CAT
    ) sa ORDER by sa.matlcx, sa.matlx;
    ";

  } else if ($section == 9) {
    
    $loc = $_GET["loc"];
    $pn = $_GET["pn"];
    
    $strSql = "
    SELECT a.MAT_SCAN_DATE datex, a.MAT_SCAN_ID bcdx, a.MAT_SCAN_PART partx, MAT_SCAN_PN matx, a.MAT_SCAN_QTYB qtyx 
    FROM material_raw_scan_in a 
    WHERE a.MAT_SCAN_RAK = '$loc' 
    AND a.MAT_SCAN_PN = '$pn';
    ";

  } else if ($section == 10) {
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $bcd = $_POST['bcd'];
    $row = $_POST['row'];
    
    //$strSql ="SELECT 1 testx";

    $strSql ="
      UPDATE `material_raw_scan_in` SET 
      `MAT_SCAN_RAK`='' 
      WHERE `MAT_SCAN_ID`='$bcd';
    ";

    if (mysqli_query($conn, $strSql)) {
      $msgx = '';
      $action = 'TRUE';
    } else {
      $msgx = 'An error occurred, please try again later.';
      $action = 'FALSE';
    }
   
    $strSql = "SELECT '". $action ."' actionx, '$msgx' msgx, '$row' rowx;";
  }
}
//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
