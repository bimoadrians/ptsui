<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

// require 'vendor/autoload.php';
// use Firebase\JWT\JWT;

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  //prod list
  if ($section == 1){ //view user list
    $strSql = "
    SELECT 
      a.USER_ID uidx, a.USER_INISIAL namex, a.USER_NAME unamex, 
      a.USER_EMAIL emailx, IFNULL(a.USER_DEP, 0) depidx, IFNULL(d.DEP_NAME,'') depnamex, USER_UNIT unitx, IFNULL(USER_LINE, '') linex, 
      b.menu_id, b.menu_group, b.menu_name, a.USER_AKTIF_STATUS statx, IFNULL(c.menu_act_view,0) act_viewx, IFNULL(c.menu_act_mod, 0) act_modx
    FROM xref_user_web a 
    LEFT JOIN xref_menu_web_new b ON 1=1 
    LEFT JOIN xref_menu_web_aces_new c ON a.USER_ID = c.menu_user_id AND b.menu_id = c.menu_id
    LEFT JOIN xref_dept d ON a.USER_DEP = d.DEP_ID
    ORDER BY a.USER_AKTIF_STATUS desc, a.USER_INISIAL, a.USER_ID, b.menu_order ASC;
    ";
  } else if ($section == 2){ //set user acces
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $menu_id = $_POST['menu_id'];
    $user_id = $_POST['user_id'];
    $act_id = $_POST['act_id'];
    $act_val = $_POST['act_val'];

    if ($act_id == 'VIEW') {
      $col_act = 'menu_act_view';
    } else {
      $col_act = 'menu_act_mod';
    }

    $strSql = "
    SELECT COUNT(*) REC_COUNT 
    FROM xref_menu_web_aces_new 
    WHERE menu_id = $menu_id AND menu_user_id = $user_id;
    ";
 
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['REC_COUNT'];

    //if not exsist add
    if ($rec_count == 0){
      $strSql = "
      INSERT INTO `xref_menu_web_aces_new` (`menu_id`, `menu_user_id`, `$col_act`, `menu_add_date`, `menu_add_id`) 
      VALUES ($menu_id, $user_id, $act_val, NOW(), $useridx);
      ";
    } else {
      $strSql = "
      UPDATE `xref_menu_web_aces_new` SET
      `$col_act`= $act_val, `menu_mod_date`=NOW(), `menu_mod_id`= $useridx
      WHERE `menu_id`=$menu_id AND `menu_user_id`= $user_id;
      ";
    }
    //echo $strSql;
    
    if (mysqli_query($conn, $strSql)) {
      $action = 'TRUE';
    } else {
      $action = 'FALSE';
    }

    $strSql = "SELECT ". $action ." actionx;";
  } else if ($section == 3){ //add user
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $name = $_POST['name'];
    $dept = ($_POST['dept'] == '' ? 0 : $_POST['dept']);
    $unit = $_POST['unit'];
    $line = $_POST['line'];
    $email = $_POST['email'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $stat = $_POST['stat'];

    $val_data = 1;
    $msgx = ''; 
    $fieldx = '';

    if ($name == ""){
      $val_data = 0;
      $msgx += 'Name not allowed empty, ';
      $fieldx = 'NAME';
    }

    if ($uname == ""){
      $val_data = 0;
      $msgx += 'Username not allowed empty, ';
      $fieldx = 'UNAME';
    }

    if ($pass == ""){
      $val_data = 0;
      $msgx += 'Password not allowed empty.';
      $fieldx = 'PASS';
    }

    if ($val_data == 0) {
      $strSql = "SELECT 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
    } else {
      $strSql = "
      SELECT COUNT(*) REC_COUNT 
      FROM xref_user_web WHERE USER_NAME = '$uname';
      ";
      
      $res = mysqli_query($conn, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $rec_count = $row['REC_COUNT'];

      //if not exsist add
      if ($rec_count != 0){
        $msgx = "Username has been used.";
        $fieldx = 'UNAME';
        $strSql = "SELECT 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      } else {

        $pass_has = password_hash($pass, PASSWORD_BCRYPT, [10]);
        
        if ($dept == 'ALL' || $dept == '' || $dept == 'null') {
          $dept = "NULL";
        }

        if ($unit == 'ALL' || $unit == '' || $unit == 'null') {
          $unit = "NULL";
        } else {
          $unit = "'" . $unit . "'";
        }

        if ($line != '' && $line != 'null' && $line != 'ALL') {
          if (strlen($line) > 2) {
            $line = "'\'".str_replace( ",","\',\'", $line)."\''";
          }
        } else {
          $line = 'NULL';
        }
        
        $strSql = "INSERT INTO `xref_user_web` (
          `USER_INISIAL`, `USER_PASS`, `USER_NAME`,  
          `USER_EMAIL`, `USER_DEP`, `USER_UNIT`, `USER_LINE`, 
          `USER_AKTIF_STATUS`, `USER_ADD_DATE`, `USER_ADD_ID`
          ) VALUES (
          '$name', '$pass_has', '$uname', '$email', 
          $dept, $unit, $line, 1, NOW(), $useridx
          );
        ";

        $fieldx = 'OTHER';
        if (mysqli_query($conn, $strSql)) {
          $msgx = '';
          $action = 'SUCCESS';
        } else {
          $msgx = 'An error occurred, please try again later.';
          $action = 'ERROR';
        }
        
        $strSql = "SELECT '". $action ."' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      }
    }
        
  } else if ($section == 4){ //mod user
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $uid = $_POST['uid'];
    $name = $_POST['name'];
    $dept = ($_POST['dept'] == '' ? 0 : $_POST['dept']);
    $unit = $_POST['unit'];
    $line = $_POST['line'];
    $email = $_POST['email'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $stat = $_POST['stat'];

    $val_data = 1;
    $msgx = ''; 
    $fieldx = '';

    if ($name == ""){
      $val_data = 0;
      $msgx .= 'Name not allowed empty, ';
      $fieldx = 'NAME';
    }

    if ($val_data == 0) {
      $strSql = "SELECT $uid idx, 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
    } else {
      $strSql = "
      SELECT COUNT(*) REC_COUNT 
      FROM xref_user_web WHERE USER_NAME = '$uname' AND USER_ID <>'$uid';
      ";
      
      $res = mysqli_query($conn, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $rec_count = $row['REC_COUNT'];

      //if not exsist add
      if ($rec_count != 0){
        $msgx = "Username has been used.";
        $fieldx = 'UNAME';
        $strSql = "SELECT $uid idx, 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      } else {
        
        if ($dept == 'ALL' || $dept == '' || $dept == 'null') {
          $dept = "NULL";
        }

        if ($unit == 'ALL' || $unit == '' || $unit == 'null') {
          $unit = "NULL";
        } else {
          $unit = "'" . $unit . "'";
        }

        if ($line != '' && $line != 'null' && $line != 'ALL') {
          if (strlen($line) > 2) {
            $line = "'\'".str_replace( ",","\',\'", $line)."\''";
          }
        } else {
          $line = "NULL";
        }
        
        $strSql = "UPDATE `xref_user_web` SET
          `USER_INISIAL`='$name',   
          `USER_EMAIL`='$email', `USER_DEP`=$dept, `USER_UNIT`=$unit, `USER_LINE`=$line, 
          `USER_AKTIF_STATUS`=$stat, `USER_MOD_DATE`=NOW(), `USER_MOD_ID`=$useridx
          WHERE USER_ID='$uid';
        ";

        $fieldx = 'OTHER';
        if (mysqli_query($conn, $strSql)) {
          $msgx = '';
          $action = 'SUCCESS';
        } else {
          $msgx = 'An error occurred, please try again later.';
          $action = 'ERROR';
        }
        
        $strSql = "SELECT $uid idx, '". $action ."' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      }
    }
        
  } else if ($section == 5){ //del user
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $uid = $_POST['uid'];

    $strSql = "DELETE FROM `xref_menu_web_aces_new` WHERE menu_user_id='$uid';";
    $fieldx = 'OTHER';
    if (mysqli_query($conn, $strSql)) {
      $msgx = '';
      $action = 'SUCCESS';
    } else {
      $msgx = 'An error occurred, please try again later.';
      $action = 'ERROR';
    }

    $strSql = "DELETE FROM `xref_user_web` WHERE USER_ID='$uid';";
    $fieldx = 'OTHER';
    if (mysqli_query($conn, $strSql)) {
      $msgx = '';
      $action = 'SUCCESS';
    } else {
      $msgx = 'An error occurred, please try again later.';
      $action = 'ERROR';
    }
   
    $strSql = "SELECT $uid idx, '". $action ."' actionx, '$fieldx' fieldx, '$msgx' msgx;";
  
  } else if ($section == 6){ //mod stat
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $uid = $_POST['uid'];
    $stat = $_POST['stat'];
    
    $strSql = "UPDATE `xref_user_web` SET USER_AKTIF_STATUS=$stat WHERE USER_ID='$uid';";
    $fieldx = 'OTHER';
    if (mysqli_query($conn, $strSql)) {
      $msgx = '';
      $action = 'SUCCESS';
    } else {
      $msgx = 'An error occurred, please try again later.';
      $action = 'ERROR';
    }
   
    $strSql = "SELECT $uid idx, '". $action ."' actionx, '$stat' statx, '$msgx' msgx;";
  
  } else if ($section == 7){ //mod user login
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $uid = $_POST['uid'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];

    $val_data = 1;
    $msgx = ''; 
    $fieldx = '';

    if ($uname == ""){
      $val_data = 0;
      $msgx .= 'Username not allowed empty, ';
      $fieldx = 'UNAME';
    }

    if ($pass == ""){
      $val_data = 0;
      $msgx .= 'Password not allowed empty.';
      $fieldx = 'PASS';
    }

    if ($val_data == 0) {
      $strSql = "SELECT $uid idx, 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
    } else {
      $strSql = "
      SELECT COUNT(*) REC_COUNT 
      FROM xref_user_web WHERE USER_NAME = '$uname' AND USER_ID <>'$uid';
      ";
      
      $res = mysqli_query($conn, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $rec_count = $row['REC_COUNT'];

      //if not exsist add
      if ($rec_count != 0){
        $msgx = "Username has been used.";
        $fieldx = 'UNAME';
        $strSql = "SELECT $uid idx, 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      } else {

        //update user
        $pass_has = password_hash($pass, PASSWORD_BCRYPT, [10]);
        $strSql = "UPDATE `xref_user_web` SET
          `USER_NAME`='$uname',   
          `USER_PASS`='$pass_has', `USER_MOD_DATE`=NOW(), `USER_MOD_ID`=$useridx
          WHERE USER_ID='$uid';
        ";

        $fieldx = 'OTHER';
        if (mysqli_query($conn, $strSql)) {
          $msgx = '';
          $action = 'SUCCESS';
        } else {
          $msgx = 'An error occurred, please try again later.';
          $action = 'ERROR';
        }
        
        $strSql = "SELECT $uid idx, '". $action ."' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      }
    }
        
  }
}
//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
