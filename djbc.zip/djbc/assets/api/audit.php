<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  if ($section == 1){ //view list audit sharp tools

    $date = $_GET['date'];
    $unit = $_GET['unit'];
    $line = $_GET['line'];

    $strSql = "
    SELECT unitx, linex, linecx, IFNULL(sc.audit_lead, sa.leadx) leadx, groupx, partx, partnx, sb.ref_code, sb.ref_desc, 
      IFNULL(sc.audit_value_y, 0) audit_valy, IFNULL(sc.audit_value_n, 0) audit_valn,
      IFNULL(sc.audit_value_y2, 0) audit_valy2, IFNULL(sc.audit_value_n2, 0) audit_valn2,
      IFNULL(sc.audit_remark, '') audit_remark, IFNULL(sc.audit_remark2, '') audit_remark2,
      sd.USER_NAME audit_mod 
    FROM (
      SELECT unitx, linex, linecx, leadx, groupx, ordx, GROUP_CONCAT(partx SEPARATOR ' / ') partx, GROUP_CONCAT(partnx SEPARATOR ' / ') partnx
      FROM (
        SELECT DISTINCT c.LINE_PREF unitx, a.PLAN_PROD_LINE_CODE linex, c.LINE_DESC linecx, c.LINE_NAME_SPV leadx, c.LINE_ORDR ordx, 
          IFNULL(a.PLAN_PROD_GROUP_ORD,'') groupx, a.PLAN_PROD_PART partx, b.PART_NAME partnx
        FROM plan_prod_daily a 
        LEFT JOIN toy_part b ON a.PLAN_PROD_PART = b.PART_NUM 
        LEFT JOIN line c ON a.PLAN_PROD_LINE_CODE = c.LINE_CODE
        WHERE a.PLAN_PROD_DATE ='$date'
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : "AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")." 
      ) a 
      GROUP BY unitx, linex, linecx, leadx, groupx, ordx
      UNION ALL
      SELECT 'C' unitx, 'A1' linex, 'IC' linecx, 'DENOK' leadx, 'ALL' groupx, 1000 ordx, '' partx, 'STORE AREA' partnx UNION ALL
      SELECT 'C' unitx, 'A2' linex, 'MECHANIC' linecx, 'AKIM' leadx, 'ALL' groupx, 1001 ordx, '' partx, 'MECHANIC AREA' partnx UNION ALL
      SELECT 'C' unitx, 'A3' linex, 'PACKING (FC)' linecx, 'ANGGI' leadx, 'ALL' groupx, 1002 ordx, '' partx, 'PACKAGE AREA' partnx
    ) sa 
    LEFT JOIN audit_ref sb ON 1=1 AND sb.ref_group = 'ST'
    LEFT JOIN audit_sharp_tools sc ON  sc.audit_date = '$date' AND sc.audit_line = sa.linex AND sc.audit_group = sa.groupx AND sc.audit_code = sb.ref_code
    LEFT JOIN xref_user_web sd ON sd.USER_ID = IFNULL(sc.audit_mod_id, sc.audit_add_id) 
    WHERE 1=1 "
    .(($unit !="" && $unit != "ALL") ? " AND sa.unitx ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND sa.linex ='$line' " : "")."
    ORDER BY sa.unitx, sa.ordx, sa.groupx, sb.ref_order
    ";
  } else if ($section == 2){ //update lead
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $req_date = $_POST['date'];
    $req_line = $_POST['line'];
    $req_group = $_POST['group'];
    $req_part = $_POST['part'];
    $req_part_desc = $_POST['partd'];
    $req_lead = $_POST['lead'];
       
    $msgx = '';

    $strSql = "
      SELECT IFNULL(COUNT(*),0) rec_count FROM audit_sharp_tools 
      WHERE audit_date='$req_date' 
      AND audit_line='$req_line'
      AND audit_group='$req_group';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['rec_count'];

    if ($rec_count == 0) {
      $strSql = "
      INSERT INTO `audit_sharp_tools` (
        `audit_date`, `audit_line`, `audit_group`, `audit_code`, 
        `audit_lead`, `audit_part`, `audit_part_name`,
        `audit_add_date`, `audit_add_id`
      ) VALUES (
        '$req_date', '$req_line', '$req_group', 'A', 
        '$req_lead', '$req_part', '$req_part_desc', NOW(), $useridx
      );
      ";

      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }

    } else {
      $strSql = "
      UPDATE `audit_sharp_tools` SET 
      `audit_lead`='$req_lead',
      `audit_mod_id`=$useridx,
      `audit_mod_date`=NOW()
      WHERE `audit_date`='$req_date' AND `audit_line` ='$req_line' AND `audit_group`= '$req_group'
      ";
      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }
    }
    
    $strSql = "
      SELECT '$action' actionx, '$msgx' msgx;
    ";
  
  } else if ($section == 3){ //update audit value
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $req_date = $_POST['date'];
    $req_line = $_POST['line'];
    $req_group = $_POST['group'];
    $req_part = $_POST['part'];
    $req_part_desc = $_POST['partd'];
    $req_lead = $_POST['lead'];
    $req_code = $_POST['refc'];
    $req_valy = $_POST['opty'];
    $req_valn = $_POST['optn'];
    $req_rem = trim($_POST['remark']);
    $req_audit = (int)$_POST['audit'];

    $insert_col = '';
    $update_col = '';
    if ($req_audit == 1) {
      $insert_col = "`audit_value_y`, `audit_value_n`, `audit_remark`,";
      $update_col = "`audit_value_y`=$req_valy, `audit_value_n`=$req_valn,`audit_remark`='$req_rem',";
    } else {
      $insert_col = "`audit_value_y2`, `audit_value_n2`, `audit_remark2`,";
      $update_col = "`audit_value_y2`=$req_valy, `audit_value_n2`=$req_valn,`audit_remark2`='$req_rem',";
    }
    
    $msgx = '';

    $strSql = "
      SELECT IFNULL(COUNT(*),0) rec_count FROM audit_sharp_tools 
      WHERE audit_date='$req_date' 
      AND audit_line='$req_line'
      AND audit_group='$req_group'
      AND audit_code='$req_code';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['rec_count'];

    if ($rec_count == 0) {
      $strSql = "
      INSERT INTO `audit_sharp_tools` (
        `audit_date`, `audit_line`, `audit_group`, 
        `audit_lead`, `audit_part`, `audit_part_name`,
        `audit_code`, ". $insert_col . "
        `audit_add_date`, `audit_add_id`
      ) VALUES (
        '$req_date', '$req_line', '$req_group', 
        '$req_lead', '$req_part', '$req_part_desc', 
        '$req_code', $req_valy, $req_valn, '$req_rem', 
        NOW(), $useridx
      );";
      //echo '<pre>'. $strSql . '</pre>';
      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }

    } else {
      $strSql = "
      UPDATE `audit_sharp_tools` SET 
      `audit_lead`='$req_lead',
      `audit_part`='$req_part',
      `audit_part_name`='$req_part_desc',
      ". $update_col ."
      `audit_mod_id`=$useridx,
      `audit_mod_date`=NOW()
      WHERE `audit_date`='$req_date' AND `audit_line`='$req_line' AND `audit_group`='$req_group' AND `audit_code`='$req_code';
      ";
      //echo '<pre>'. $strSql . '</pre>';
      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }
    }
    
    $strSql = "
      SELECT '$action' actionx, '$msgx' msgx;
    ";
  } else if ($section == 4){ //audit silica - view
    $date = $_GET['date'];
    $strSql = "
      SELECT a.ship_date sdatex, a.ship_part_num partx, b.PART_NAME partnx, a.ship_qty sqtyx, c.audit_id aidx,
      c.audit_date adatex, c.audit_time atimex, c.audit_date_prod pdatex, c.audit_line linex, d.LINE_DESC linedx, c.audit_lead leadx, c.audit_lot lotx,
      c.audit_aval avalx, c.audit_poli_lub pollubx, c.audit_poli_rap polrapx, c.audit_poli_kot polkotx, c.audit_pass passx, 
      IFNULL(c.audit_remark, '') remx, IFNULL(c.audit_reaudit, '') reaudx
      FROM shipment_plan a 
      LEFT JOIN toy_part b ON a.ship_part_num = b.PART_NUM
      LEFT JOIN audit_silica c ON a.ship_part_num = c.audit_part AND c.audit_date_ship = a.ship_date
      LEFT JOIN line d ON c.audit_line = d.LINE_CODE
      WHERE a.ship_date ='$date' AND a.ship_flag='GOOD' 
      AND IFNULL(b.PART_SILICA, 0) = 1
      ORDER BY a.ship_date, a.ship_part_num;
    ";

  } else if ($section == 5){ //audit silica - add
    $strSql ="SELECT '' datax";
    
  } else if ($section == 6){ //audit silica - dell
    $strSql ="SELECT '' datax";

  } else if ($section == 90){ //view list sub. department
    $strSql = "
      SELECT a.id subidx, a.nama subx 
      FROM sub_departemens a WHERE IFNULL(unit, '') <> '' AND a.nama <> '-'
      ORDER BY `order`;
      ;";
  } else if ($section == 91){ //view list karyawan hadir overtime
    $date = $_GET['date'];
    $line_sub = $_GET['line_sub'];

    $strSql = "
    SELECT * FROM (
      SELECT a.id idx, a.nik nikx, a.nama namax, 'TA' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name labx, c.`order` ordx  
      FROM karyawans a 
      LEFT JOIN absens b ON b.tanggal = '$date' AND a.id = b.id_karyawan
      LEFT JOIN sub_departemens c ON a.id_sub_departemen = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      WHERE CAST( IFNULL(CAST(a.keluar AS DATE), DATE_ADD('$date',INTERVAL 1 DAY)) AS DATE) >= '$date' 
      AND c.id = '$line_sub'
      AND IFNULL(b.keterangan, 'A') = 'H' 
      AND a.id NOT IN (
        SELECT request_id_karyawan idx 
        FROM request_overtime na WHERE na.request_date='$date' AND na.request_source='tetap' 
      ) UNION ALL

      SELECT a.id, a.nik, a.nama, 'TR' statkx, 'N' uax, 
        CASE WHEN e.labor_name = 'PDL' THEN c.nama ELSE 'STAFF/OFFICE' END group_depx, 
        c.nama subx, d.nama jabx, e.labor_name, c.`order` ordx 
      FROM karyawans_tr a 
      LEFT JOIN karyawans_tr_absen b ON b.date_absen = '$date' AND a.id = b.id
      LEFT JOIN sub_departemens c ON a.id_sub_dept = c.id
      LEFT JOIN jabatans d ON a.id_jabatan = d.id
      LEFT JOIN labor_type e ON d.labor_id = e.labor_id
      WHERE IFNULL(a.tgl_keluar, DATE_ADD('$date',INTERVAL 1 DAY)) >= '$date'
      AND c.id = '$line_sub'
      AND IFNULL(b.flag, 'A') = 'H' 
      AND a.id NOT IN (
        SELECT request_id_karyawan idx 
        FROM request_overtime na WHERE na.request_date='$date' AND na.request_source='training' 
      )
    ) a
    ORDER BY a.labx DESC, a.ordx, a.subx, a.jabx, a.namax;
    ";
  } else if ($section == 92){ //view all list lead
    
    $strSql = "
    SELECT DISTINCT lead_name leadx FROM (
      SELECT lead_name FROM line_leader a UNION ALL
      SELECT DISTINCT a.LINE_NAME_SPV FROM line a
    ) a ORDER BY lead_name;
    ";
  }
}
//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
