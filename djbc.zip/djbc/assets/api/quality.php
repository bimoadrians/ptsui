<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
    
  
  if ($section == 1){ //view list pp inspection
    $date = $_GET['date'];
    $strSql = "
    SELECT a.idx, a.lotidx, a.linex, a.stylex, a.leadx, a.lotx, a.ssx, a.timex, a.goodx, a.aesx, a.funx, IFNULL(a.defx,'') defx, IFNULL(b.LINE_DESC, b.LINE_DESCX) linenx, c.PART_NAME stylenx 
    FROM (
      SELECT a.idx, a.lotidx, a.linex, stylex, leadx, lotx, ssx, timex, SUM(goodx) goodx, SUM(aesx) aesx, SUM(funx) funx, GROUP_CONCAT(DISTINCT defx SEPARATOR ', ') defx
      FROM (
        SELECT a.inspect_id idx, b.inspect_lot_id lotidx, a.inspect_line linex, a.inspect_style stylex, a.inspect_lead leadx, 
          b.inspect_lot_seq lotx, b.inspect_lot_ss ssx, b.inspect_lot_time timex,
          CASE WHEN c.inspect_flag ='GOOD' THEN c.inspect_qty ELSE 0 END goodx,
          CASE WHEN (c.inspect_flag = 'DEFECT' AND d.DEFECT_CAT = 'AESTHETIC') THEN c.inspect_qty ELSE 0 END aesx,
          CASE WHEN (c.inspect_flag = 'DEFECT' AND d.DEFECT_CAT = 'FUNCTION') THEN c.inspect_qty ELSE 0 END funx,
          d.DEFECT_NAME defx
        FROM qc_pp_insp a 
        LEFT JOIN qc_pp_insp_lot b ON a.inspect_id = b.inspect_id
        LEFT JOIN qc_pp_insp_lot_det c ON b.inspect_lot_id = c.inspect_lot_id
        LEFT JOIN defect_lbo d ON c.inspect_defect = d.DEFECT_CODE
        WHERE a.inspect_date = '$date'
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.inspect_date NOT IN $GLOB_AUDIT_DATE")."
      ) a 
      GROUP BY a.idx, a.lotidx, a.linex, stylex, leadx, lotx, ssx, timex
    ) a 
    LEFT JOIN line b ON a.linex = b.LINE_CODE
    LEFT JOIN toy_part c ON a.stylex = c.PART_NUM
    ORDER BY b.LINE_PREF, b.LINE_ORDR, a.idx, a.lotx;
    ";

  } else if ($section == 2){ //add pp inspect
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $date = $_POST['date'];
    $line = $_POST['line'];
    $style = $_POST['style'];
    $lead = $_POST['lead'];
       
    $msgx = '';

    $strSql = "
      SELECT IFNULL(COUNT(*),0) rec_count 
      FROM qc_pp_insp 
      WHERE inspect_date='$date' 
      AND inspect_line='$line'
      AND inspect_style='$style'
      AND inspect_lead='$lead';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['rec_count'];
    $inspect_id = 0;

    if ($rec_count == 0) {
      $strSql = "
      INSERT INTO `qc_pp_insp` (
        `inspect_date`, `inspect_line`, `inspect_style`, `inspect_lead`, 
        `inspect_add_date`, `inspect_add_id`
      ) VALUES (
        '$date', '$line', '$style', '$lead', 
         NOW(), $useridx
      );
      ";

      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';
        $strSql = "
          SELECT inspect_id 
          FROM qc_pp_insp 
          WHERE inspect_date='$date' 
          AND inspect_line='$line'
          AND inspect_style='$style'
          AND inspect_lead='$lead';
        ";
        $res = mysqli_query($conn, $strSql);
        $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
        $inspect_id = $row['inspect_id'];
        
      } else {
        $action = 'FALSE';
        $inspect_id = 0;
      }

    } else {
      $msgx = "Duplikat line, style dan leader.";
      $action = 'FALSE';
      $inspect_id = 0;
    }
    
    $strSql = "
      SELECT '$inspect_id' idx, '$action' actionx, '$msgx' msgx;
    ";
  
  } else if ($section == 3){ //insert pp lot
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $lot_id = $_POST['lot_id'];
    $lot_date = $_POST['lot_date'];
    $lot_ss = $_POST['lot_ss'];
    $lot_gd = $_POST['lot_gd'];
    $lot_df = $_POST['lot_df'];
    $lot_da = $_POST['lot_da'];
    $lot_rem = substr($_POST['lot_rem'], 0, strlen($_POST['lot_rem']) -2);
    $lot_defc = $_POST['lot_defc'];
    $lot_defq = $_POST['lot_defq'];
    $lot_defn = $_POST['lot_defn'];

    $lotd = explode(",", $lot_defc);
    $lotq = explode(",", $lot_defq);

    $strSql = "SELECT IFNULL(MAX(inspect_lot_seq),0) + 1 lot_seq FROM qc_pp_insp_lot WHERE inspect_id='$lot_id';";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $lot_seq = $row['lot_seq'];

    $strSql = "
      INSERT INTO `qc_pp_insp_lot` (`inspect_id`, `inspect_lot_date`, `inspect_lot_time`, `inspect_lot_seq`, `inspect_lot_ss`, `inspect_add_date`, `inspect_add_id`) VALUES (
        '$lot_id', '$lot_date', NOW(), $lot_seq, '$lot_ss', NOW(), $useridx
      );
    ";

    $last_id = 0;
    $msgx = '';
    if (mysqli_query($conn, $strSql)) {
      $last_id = mysqli_insert_id($conn);
      $strSql = "INSERT INTO `qc_pp_insp_lot_det` (`inspect_lot_id`, `inspect_date`, `inspect_flag`, `inspect_defect`, `inspect_proc`, `inspect_qty`, `inspect_add_date`, `inspect_add_id`) VALUES "; 

      $idx = 0;
      foreach ($lotd as $lot){
        if ($idx == 0 ) {
          $strSql .= "($last_id, '$lot_date', 'GOOD', $lotd[$idx], NULL, '$lotq[$idx]', NOW(), $useridx),";
        } else {
          $strSql .= "($last_id, '$lot_date', 'DEFECT', $lotd[$idx], NULL, '$lotq[$idx]', NOW(), $useridx),";
        }
        $idx ++;
      }
      $strSql = substr($strSql, 0, strlen($strSql) -1);
      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';    
      } else {
        $action = 'FALSE';
        $msgx = "Error insert lot data.";
      }
    } else {
      $action = 'FALSE';
      $msgx = "Error insert lot data.";
    }
    $strSql = "
      SELECT '$action' actionx, '$msgx' msgx, '$lot_id' idx, '$last_id' lotidx, CURTIME() timex, '$lot_seq' seqx, '$lot_ss' ssx, '$lot_gd' goodx, '$lot_da' defax, '$lot_df' deffx, '$lot_rem' remx;
    ";

  } else if ($section == 4){ //del pp lot
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $lot_id = $_POST['lot_id'];
    $strSql = "DELETE FROM qc_pp_insp_lot_det WHERE inspect_lot_id='$lot_id';";
    $actiond = mysqli_query($conn, $strSql);
    $strSql = "DELETE FROM qc_pp_insp_lot WHERE inspect_lot_id='$lot_id';";
    $actionh = mysqli_query($conn, $strSql);

    if ($actiond == true && $actionh == true) {
      $strSql = "
      SELECT 'TRUE' actionx, '$lot_id' lot_idx;
      ";  
    } else {
      $strSql = "
      SELECT 'FALSE' actionx, '$lot_id' lot_idx;
      ";
    }
  
  } else if ($section == 5){ //del pp inspect
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $ins_id = $_POST['ins_id'];
    $strSql = "DELETE FROM qc_pp_insp WHERE inspect_id='$ins_id';";
    $action = mysqli_query($conn, $strSql);
    if ($action == true) {
      $strSql = "
      SELECT 'TRUE' actionx, '$ins_id' lot_idx;
      ";  
    } else {
      $strSql = "
      SELECT 'FALSE' actionx, '$ins_id' lot_idx;
      ";
    }
  } else if ($section == 6){ // view material inspect list

    $date= $_GET['date'];

    $strSql = "
      SELECT a.inspect_id idx, a.inspect_lot lotx, a.inspect_date_prod datepx, a.inspect_pn matlx, b.MATL_NAME matlnx, b.MATL_UNIT unitx, 
        a.inspect_style stylex, c.PART_NAME stylenx, a.inspect_lot_qty lotqx, a.inspect_ss ssx, IFNULL(a.inspect_reject,0) rejx, 
        a.inspect_pass passx, a.inspect_pass_qty passqx, IFNULL(a.inspect_vendor, '') vendx, IFNULL(a.inspect_qc_name, '') qcx,
        IFNULL(a.inspect_def1, 0) def1, IFNULL(a.inspect_def2, 0) def2, IFNULL(a.inspect_def3, 0) def3, 
        IFNULL(a.inspect_def4, 0) def4, IFNULL(a.inspect_def5, 0) def5, IFNULL(a.inspect_def6, 0) def6, IFNULL(a.inspect_def7, 0) def7,
        IFNULL(a.inspect_def8, 0) def8, IFNULL(a.inspect_def9, 0) def9, IFNULL(a.inspect_def10, 0) def10, 
        IFNULL(a.inspect_def11, 0) def11, IFNULL(a.inspect_def12, 0) def12, IFNULL(a.inspect_def13, 0) def13, IFNULL(a.inspect_def14, 0) def14,
        IFNULL(a.inspect_def15, 0) def15, IFNULL(a.inspect_def16, 0) def16, IFNULL(a.inspect_def17, 0) def17, 
        IFNULL(a.inspect_def18, 0) def18, IFNULL(a.inspect_def19, 0) def19, IFNULL(a.inspect_def20, 0) def20, IFNULL(a.inspect_def21, 0) def21
      FROM qc_matl_insp a 
      LEFT JOIN material b ON a.inspect_pn = b.MATL_CODE
      LEFT JOIN toy_part c ON a.inspect_style = c.PART_NUM
      WHERE a.inspect_date ='$date'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.inspect_date NOT IN $GLOB_AUDIT_DATE")."
    ";

  } else if ($section == 7){ // add material inspect

    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $date = $_POST['date'];
    $part = strtoupper(trim($_POST['part']));
    $ss = $_POST['ss'];
       
    $msgx = '';

    //get material detail
    $strSql = "
      SELECT IFNULL(COUNT(*),0) rec_count, MATL_NAME rec_name, MATL_UNIT rec_unit
      FROM material a
      WHERE MATL_CODE='$part';
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['rec_count'];
    $rec_name = $row['rec_name'];
    $rec_unit = $row['rec_unit'];

    //get style detail
    $strSql = "
      SELECT IFNULL(b.PART_NUM,'') stylex, IFNULL(b.PART_NAME, '') stylenx 
      FROM toy_part_matl a 
      LEFT JOIN toy_part b ON a.PART_NUM = b.PART_NUM
      WHERE a.PART_MATL_CODE='$part' ORDER BY a.PART_MOD_DATE DESC LIMIT 1;
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_style = $row['stylex'];
    $rec_stylen = $row['stylenx'];

    //get last inspect
    $strSql = "
      SELECT IFNULL(a.inspect_qc_name, '') inspecx, IFNULL(a.inspect_vendor, '') vendx 
      FROM qc_matl_insp a WHERE a.inspect_pn='$part' ORDER BY a.inspect_date, a.inspect_time DESC LIMIT 1;
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_qc = $row['inspecx'];
    $rec_vend = $row['vendx'];

    //get lot sequent
    $strSql = "
      SELECT IFNULL(MAX(b.inspect_lot), 0) + 1 rec_lot 
      FROM qc_matl_insp b WHERE b.inspect_date='$date';
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_lot = $row['rec_lot'];
    
    if ($rec_count == 0){
      $strSql = "
        SELECT 'FALSE' actionx, '' stylex, '' stylenx, '' matx, '' matnx, '' unitx, '' ss, '' lotx, 'Material not found' msgx;
      ";
    } else {
      $strSql = "
        SELECT 'TRUE' actionx, '$rec_qc' qcx, '$rec_vend' vendx, '$rec_style' stylex, '$rec_stylen' stylenx, '$part' matx, '$rec_name' matnx, '$rec_unit' unitx, '$ss' ssx, '$rec_lot' lotx, 'Material found' msgx;
      ";
    }

  } else if ($section == 8){ // save material inspect

    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $date = $_POST['date'];
    $part = trim($_POST['part']);
    $style = $_POST['style'];
    $date_p = $_POST['date_p'];
    $vendor = $_POST['vendor'];
    $inspr = $_POST['inspr'];
    $ss = $_POST['ss'];
    $lot = $_POST['lot'];
    $pass = $_POST['pass'];
    $pass_qty = doubleval($_POST['sor']);
    $qrc = doubleval($_POST['qrc']);
    $act = doubleval($_POST['act']);

    $d1 = doubleval($_POST['d1']);
    $d2 = doubleval($_POST['d2']);
    $d3 = doubleval($_POST['d3']);
    $d4 = doubleval($_POST['d4']);
    $d5 = doubleval($_POST['d5']);
    $d6 = doubleval($_POST['d6']);
    $d7 = doubleval($_POST['d7']);

    $d8 = doubleval($_POST['d8']);
    $d9 = doubleval($_POST['d9']);
    $d10 = doubleval($_POST['d10']);
    $d11 = doubleval($_POST['d11']);
    $d12 = doubleval($_POST['d12']);
    $d13 = doubleval($_POST['d13']);
    $d14 = doubleval($_POST['d14']);

    $d15 = doubleval($_POST['d15']);
    $d16 = doubleval($_POST['d16']);
    $d17 = doubleval($_POST['d17']);
    $d18 = doubleval($_POST['d18']);
    $d19 = doubleval($_POST['d19']);
    $d20 = doubleval($_POST['d20']);
    $d21 = doubleval($_POST['d21']);

    $bar = $_POST['bar'];
    $d0 = $d1 + $d2 + $d3 + $d4 + $d5 + $d6 + $d7 + $d8 + $d9 + $d10 + $d11 + $d12 + $d13 + $d14 + $d15 + $d16 + $d17 + $d18 + $d19 + $d20 + $d21;

    $strSql = "
      SELECT IFNULL(COUNT(*),0) rec_count, MATL_NAME rec_name, MATL_UNIT rec_unit
      FROM material a
      WHERE MATL_CODE='$part';
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_count = $row['rec_count'];
    $rec_name = $row['rec_name'];
    $rec_unit = $row['rec_unit'];

    $strSql = "
      SELECT PART_NAME 
      FROM toy_part a
      WHERE PART_NUM='$style';
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_stylen = $row['PART_NAME'];

    $strSql = "
      SELECT IFNULL(MAX(b.inspect_lot), 0) + 1 rec_lot 
      FROM qc_matl_insp b WHERE b.inspect_date='$date';
    ";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $rec_lot = $row['rec_lot'];
    
    $strSql = "
      INSERT INTO `qc_matl_insp` (
        `inspect_date`, `inspect_lot`, `inspect_pn`, 
        `inspect_time`, `inspect_date_prod`, `inspect_qr`, `inspect_style`,
        `inspect_vendor`, `inspect_qc_name`, `inspect_lot_qty`, `inspect_ss`, 
        `inspect_def1`, `inspect_def2`, `inspect_def3`, `inspect_def4`, `inspect_def5`, `inspect_def6`, `inspect_def7`,
        `inspect_def8`, `inspect_def9`, `inspect_def10`, `inspect_def11`, `inspect_def12`, `inspect_def13`, `inspect_def14`,
        `inspect_def15`, `inspect_def16`, `inspect_def17`, `inspect_def18`, `inspect_def19`, `inspect_def20`, `inspect_def21`,
        `inspect_reject`, `inspect_qtyq`, `inspect_qtya`, `inspect_pass_qty`, `inspect_pass`,
        `inspect_add_date`, `inspect_add_id`
      ) VALUES (
        NOW(), $rec_lot, '$part', 
        NOW(), '$date_p', '$bar', '$style',
        '$vendor', '$inspr', '$lot', $ss,  
        '$d1', '$d2', '$d3', '$d4', '$d5', '$d6', '$d7',
        '$d8', '$d9', '$d10', '$d11', '$d12', '$d13', '$d14', 
        '$d15', '$d16', '$d17', '$d18', '$d19', '$d20', '$d21',
        '$d0', '$qrc', '$act', '$pass_qty', '$pass',   
        NOW(), $useridx
      );
    ";

    //echo '<pre>'. $strSql . '</pre>';

    $last_id = 0;
    if (mysqli_query($conn, $strSql)) {
      $last_id = mysqli_insert_id($conn);
      $strSql = "
        SELECT 'TRUE' actionx, '$last_id' idx, '$part' matlx, '$rec_name' matlnx, '$rec_unit' unitx, 
          '$style' stylex, '$rec_stylen' stylenx, '$rec_lot' lotx, '$lot' lotqx, '$ss' ssx,
          '$vendor' vendx, '$inspr' qcx, '$d0' rejx, '$pass' passx, '$pass_qty' passqx,   
          '$d1' def1, '$d2' def2, '$d3' def3, '$d4' def4, '$d5' def5, '$d6' def6, '$d7' def7,
          '$d8' def9, '$d10' def11, '$d12' def13, '$d14' def15, '$d16' def17, '$d18' def19, '$d20' def21,
          '$d0' defx, '$qrc' qrx, '$act' actx, '' msgx;
      ";
    } else {
      $strSql = "
        SELECT 'FALSE' actionx, '$last_id' idx, '' matx, '' matnx, '' unitx, '' ssx, ' lotx, '' defx, '' qrx, '' actx, 'Error save inspection.' msgx;
      ";
    }
    

  } else if ($section == 9){ // delete material inspect
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    }

    $lot_id = $_POST['lot_id'] ;
    $strSql = "
      DELETE FROM `qc_matl_insp` WHERE inspect_id='$lot_id';
    ";

    if (mysqli_query($conn, $strSql)) {
      $strSql = "
        SELECT 'TRUE' actionx, '$lot_id' idx;
      ";
    } else {
      $strSql = "
        SELECT 'FALSE' actionx, '$lot_id' idx;
      ";
    }
  } else if ($section == 10){ // update material inspect
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    }    
    $lot_id = $_POST['insp_id'];
    
    $style = $_POST['style'];
    $date_p = $_POST['date_p'];
    $vendor = $_POST['vendor'];
    $inspr = $_POST['inspr'];
        
    $pass = $_POST['pass'];
    $pass_qty = doubleval($_POST['sor']);
    $qrc = doubleval($_POST['qrc']);
    $act = doubleval($_POST['act']);

    $lot = doubleval($_POST['lot']);
    $ss = doubleval($_POST['ss']);

    $d1 = doubleval($_POST['d1']);
    $d2 = doubleval($_POST['d2']);
    $d3 = doubleval($_POST['d3']);
    $d4 = doubleval($_POST['d4']);
    $d5 = doubleval($_POST['d5']);
    $d6 = doubleval($_POST['d6']);
    $d7 = doubleval($_POST['d7']);

    $d8 = doubleval($_POST['d8']);
    $d9 = doubleval($_POST['d9']);
    $d10 = doubleval($_POST['d10']);
    $d11 = doubleval($_POST['d11']);
    $d12 = doubleval($_POST['d12']);
    $d13 = doubleval($_POST['d13']);
    $d14 = doubleval($_POST['d14']);

    $d15 = doubleval($_POST['d15']);
    $d16 = doubleval($_POST['d16']);
    $d17 = doubleval($_POST['d17']);
    $d18 = doubleval($_POST['d18']);
    $d19 = doubleval($_POST['d19']);
    $d20 = doubleval($_POST['d20']);
    $d21 = doubleval($_POST['d21']);

    $bar = $_POST['bar'];
    $d0 = $d1 + $d2 + $d3 + $d4 + $d5 + $d6 + $d7 + $d8 + $d9 + $d10 + $d11 + $d12 + $d13 + $d14 + $d15 + $d16 + $d17 + $d18 + $d19 + $d20 + $d21;

    $strSql = "
      UPDATE qc_matl_insp SET 
        inspect_ss='$ss',
        inspect_date_prod='$date_p',
        inspect_vendor='$vendor',
        inspect_qc_name='$inspr',
        inspect_lot_qty='$lot',
        inspect_ss='$ss',
        inspect_reject='$d0',
        inspect_pass='$pass',
        inspect_pass_qty='$pass_qty',
        inspect_def1='$d1',
        inspect_def2='$d2',
        inspect_def3='$d3',
        inspect_def4='$d4',
        inspect_def5='$d5',
        inspect_def6='$d6',
        inspect_def7='$d7',
        inspect_def8='$d8',
        inspect_def9='$d9',
        inspect_def10='$d10',
        inspect_def11='$d11',
        inspect_def12='$d12',
        inspect_def13='$d13',
        inspect_def14='$d14',
        inspect_def15='$d15',
        inspect_def16='$d16',
        inspect_def17='$d17',
        inspect_def18='$d18',
        inspect_def19='$d19',
        inspect_def20='$d20',
        inspect_def21='$d21',
        inspect_mod_date=NOW(),
        inspect_mod_id=$useridx
      WHERE inspect_id='$lot_id';
    ";

    if (mysqli_query($conn, $strSql)) {
      $strSql = "
        SELECT 'TRUE' actionx, '$lot_id' idx, '$ss' ssx,  
          '$d1' def1, '$d2' def2, '$d3' def3, '$d4' def4, '$d5' def5, '$d6' def6, '$d7' def7,
          '$d0' defx, '$qrc' qrx, '$act' actx, '' msgx;
      ";
    } else {
      $strSql = "
        SELECT 'FALSE' actionx, '$lot_id' idx, '' ssx, ' lotx, '' defx, '' qrx, '' actx, 'Error save inspection.' msgx;
      ";
    }
  } else if ($section == 90){ // view lead list
    $strSql = "
    SELECT DISTINCT lead_name leadx FROM (
      SELECT lead_name FROM line_leader a WHERE IFNULL(lead_expire,'')='' UNION ALL
      SELECT DISTINCT a.LINE_NAME_SPV FROM line a
    ) a WHERE lead_name <> 'N/A' ORDER BY lead_name;
    ";
  } else if ($section == 91) { // view part list
    $date= $_GET['date'];

    $strSql = "
    SELECT DISTINCT b.PART_NUM partx, b.PART_NAME part_namex 
    FROM plan_prod_daily a 
    LEFT JOIN toy_part b on a.PLAN_PROD_PART=b.PART_NUM 
    WHERE a.PLAN_PROD_DATE BETWEEN DATE_ADD('$date', INTERVAL -5 DAY) AND '$date'
    ORDER BY PART_NAME ASC;
    ";
  } else if ($section == 92) { // view defect list
    $strSql = "SELECT DEFECT_CODE, DEFECT_NAME, DEFECT_CAT FROM defect_lbo a;";
  } else if ($section == 93) { // view vendor list
    $strSql = "
      SELECT vendor_id, vendor_name 
      FROM defect_matl_vendor a
      WHERE IFNULL(expire_date, 'N') = 'N'    
    ;";
  } else if ($section == 94) { // view inspector list
    $strSql = "
    SELECT inspector_id, inspector_name 
    FROM defect_matl_inspector a
    WHERE IFNULL(expire_date, 'N') = 'N'    
  ;";
  }
}

//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
