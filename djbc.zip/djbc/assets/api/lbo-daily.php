<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] ="false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  //prod list
  if ($section == 1) { //lbo daily inspected
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];

    $strSql = "
      SELECT 
      MIN(CAST(CONCAT(LEFT(a.QC_LBO_PLAN_ID, 4), '-', MID(a.QC_LBO_PLAN_ID,5,2), '-', MID(a.QC_LBO_PLAN_ID,7,2)) AS DATE)) min_datex,
      MAX(CAST(CONCAT(LEFT(a.QC_LBO_PLAN_ID, 4), '-', MID(a.QC_LBO_PLAN_ID,5,2), '-', MID(a.QC_LBO_PLAN_ID,7,2)) AS DATE)) max_datex 
      FROM qc_lbo_input a WHERE a.QC_LBO_DATE = '".$date."';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $min_date = $row['min_datex'];
    $max_date = $row['max_datex'];

    $strSql = "
      SELECT 
      (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) planx,
      a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_DATE prod_datex
      FROM plan_prod_daily a 
      WHERE a.PLAN_PROD_DATE  BETWEEN '".$min_date."' AND '".$max_date."';
    ";

    //echo $strSql . '<br>';

    $str_prod = "SELECT '' planx, '' prod_datex, '' groupx ";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $str_prod = $str_prod . "
        UNION ALL
        SELECT '". $row['planx'] . "' planx, '".$row['prod_datex']."' prod_datex, '" . $row['groupx'] ."' groupx";
      }
    }
    //echo $str_prod . '<br>';
    
    $strSql = "
    SELECT a.QC_LBO_ID lbo_idx, a.planx, a.QC_LBO_DATE lbo_datex, a.QC_LBO_TIME lbo_timex, 
    a.QC_LBO_INSPECT_TYPE lbo_insx, e.LINE_DESC linex, e.LINE_NAME_SPV spvx, a.partx, c.PART_NAME part_namex, c.PART_TYPE part_typex,
    a.QC_LBO_SEQ lot_seqx, a.QC_LBO_LOT lbo_lotx, a.QC_LBO_SS lbo_ssx, a.QC_LBO_LOTX lbo_lotex, a.QC_LBO_LOTS lbo_lotexs,
    b.lbo_gdx, b.lbo_defa, b.lbo_deff, CONCAT(d.lbo_sampl_a, '/', d.lbo_sampl_r) arx, 
    IF((IFNULL(b.lbo_gdx, 0)+IFNULL(b.lbo_defa, 0)+IFNULL(b.lbo_deff, 0))=0,'-', IF((IFNULL(b.lbo_defa, 0)+IFNULL(b.lbo_deff, 0))>d.lbo_sampl_a, 'R','A')) lbo_acc_statx,
    f.*, g.*, h.inspector inspectorx
    FROM (
      SELECT a.QC_LBO_ID, a.QC_LBO_PLAN_ID planx, a.QC_LBO_PART partx, a.QC_LBO_DATE, a.QC_LBO_TIME, a.QC_LBO_INSPECT_TYPE, a.QC_LBO_SEQ, a.QC_LBO_LOT, a.QC_LBO_SS, a.QC_LBO_LOTX, a.QC_LBO_LOTS 
      FROM qc_lbo_input a 
      WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = 'N'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
    ) a LEFT JOIN (
      #GET TOTAL CHECK
      SELECT a.QC_LBO_ID, SUM(gddx) lbo_gdx, SUM(defa) lbo_defa, SUM(deff) lbo_deff 
      FROM (
        SELECT a.QC_LBO_ID, b.LBO_CATEGORY, b.LBO_DEFECT_CODE, 
          IF(b.LBO_CATEGORY='GOOD', 1, 0) gddx,
          IF(c.DEFECT_CAT = 'AESTHETIC', 1,0) defa,
          IF(c.DEFECT_CAT = 'FUNCTION', 1, 0) deff
        FROM qc_lbo_input a 
        LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
        LEFT JOIN defect_lbo c ON c.DEFECT_CODE = b.LBO_DEFECT_CODE
        WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = 'N'
      ) a GROUP BY a.QC_LBO_ID
    ) b ON a.QC_LBO_ID = b.QC_LBO_ID
    LEFT JOIN toy_part c ON a.partx = c.PART_NUM
    LEFT JOIN qc_lbo_smpl d ON IFNULL(c.PART_TYPE, 'MNL') = d.lbo_smpl_type AND d.lbo_smpl_ins = IFNULL(a.QC_LBO_INSPECT_TYPE, 'N')
    AND a.QC_LBO_LOT BETWEEN d.lbo_smpl_lot_size_min AND d.lbo_smpl_lot_size_max
    LEFT JOIN line e ON e.LINE_CODE = MID(a.planx, 9, 2)
    LEFT JOIN (
      ". $str_prod ."
    ) f on f.planx = a.planx 
    LEFT JOIN (
      SELECT a.lbo_idx, COUNT(a.lbo_idx) lotscx, SUM(lotx) lotsx, SUM(ssx) sssx, SUM(lbo_gdsx) lbo_gdsx, SUM(lbo_defsa) lbo_defsa, SUM(lbo_defsf) lbo_defsf  
      FROM (
        SELECT lbo_id, lbo_idx, lot_seqex, lotx, ssx, SUM(gddx) lbo_gdsx, SUM(defa) lbo_defsa, SUM(deff) lbo_defsf 
        FROM (
          SELECT a.QC_LBO_ID lbo_id, a.QC_LBO_LOTX lbo_idx, a.QC_LBO_LOTS lot_seqex, a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, b.LBO_CATEGORY, b.LBO_DEFECT_CODE, 
            IF(b.LBO_CATEGORY='GOOD', 1, 0) gddx,
            IF(c.DEFECT_CAT = 'AESTHETIC', 1, 0) defa,
            IF(c.DEFECT_CAT = 'FUNCTION', 1, 0) deff
          FROM qc_lbo_input a 
          LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
          LEFT JOIN defect_lbo c ON c.DEFECT_CODE = b.LBO_DEFECT_CODE
          WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = 'T'
        ) a GROUP BY a.lbo_id, a.lbo_idx, lot_seqex, lotx, ssx
      ) a GROUP BY a.lbo_idx
    ) g ON a.QC_LBO_ID = g.lbo_idx 
    LEFT JOIN qc_lbo_inspector h ON h.line_code = e.LINE_CODE AND '" . $date . "' BETWEEN h.date_start AND h.date_end
    WHERE 1=1 
    " . (($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "") . "
    " . (($group !="" && $group != "ALL") ? " AND f.groupx ='$group' " : "") . "
    " . (($style !="" && $style != "ALL") ? " AND (UCASE(c.PART_NUM) LIKE '%".strtoupper($style)."%' OR UCASE(c.PART_NAME) LIKE '%".strtoupper($style)."%')" : "") . "
    ORDER BY e.LINE_PREF, e.LINE_ORDR, f.prod_datex, f.groupx, a.partx, a.QC_LBO_SEQ, a.QC_LBO_TIME;
    ";

    //echo '<pre>'. $strSql . '</pre>';
  } else if ($section == 2) { //lbo daily defect aesthetic
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];
    $insType = $_GET["inspect"];

    $strSql = "
      SELECT 
      MIN(CAST(CONCAT(LEFT(a.QC_LBO_PLAN_ID, 4), '-', MID(a.QC_LBO_PLAN_ID,5,2), '-', MID(a.QC_LBO_PLAN_ID,7,2)) AS DATE)) min_datex,
      MAX(CAST(CONCAT(LEFT(a.QC_LBO_PLAN_ID, 4), '-', MID(a.QC_LBO_PLAN_ID,5,2), '-', MID(a.QC_LBO_PLAN_ID,7,2)) AS DATE)) max_datex 
      FROM qc_lbo_input a WHERE a.QC_LBO_DATE = '".$date."';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $min_date = $row['min_datex'];
    $max_date = $row['max_datex'];

    $strSql = "
      SELECT 
      (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) planx,
      a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_DATE prod_datex
      FROM plan_prod_daily a 
      WHERE a.PLAN_PROD_DATE  BETWEEN '".$min_date."' AND '".$max_date."';
    ";

    //echo $strSql . '<br>';

    $str_prod = "SELECT '' planx, '' prod_datex, '' groupx ";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $str_prod = $str_prod . " UNION ALL
        SELECT '". $row['planx'] . "' planx, '".$row['prod_datex']."' prod_datex, '" . $row['groupx'] ."' groupx";
      }
    }
    //echo $str_prod . '<br>';

    $strSql = "SELECT * FROM defect_lbo a WHERE a.DEFECT_CAT='AESTHETIC' ORDER BY a.DEFECT_CAT, a.DEFECT_ORDER ASC;";
    $strSqlDef = "";
    $strSqlDefSum = "";
    $strSqlDefSumG = "";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $strSqlDef .= ", CASE WHEN b.LBO_DEFECT_CODE = ". $row['DEFECT_CODE']." THEN 1 ELSE 0 END `d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER']."`";
        $strSqlDefSum .= ", SUM(d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER'].") `d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER']."`";
        $strSqlDefSumG .= ", IFNULL(`d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER']."`, '') `d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER']."`";
      }
    }    

    $strSql = "
    SELECT a.QC_LBO_ID lbo_idx, a.planx, a.QC_LBO_DATE lbo_datex, a.QC_LBO_TIME lbo_timex, 
    a.QC_LBO_INSPECT_TYPE lbo_insx, e.LINE_DESC linex, e.LINE_NAME_SPV spvx, a.partx, c.PART_NAME part_namex, c.PART_TYPE part_typex,
    ". ($insType == 'T' ? 'a.QC_LBO_LOTS' : 'a.QC_LBO_SEQ')." lot_seqx, a.QC_LBO_LOT lbo_lotx, a.QC_LBO_SS lbo_ssx, a.QC_LBO_LOTX lbo_lotex, a.QC_LBO_LOTS lbo_lotexs,
    f.*, h.inspector inspectorx".$strSqlDefSumG."
    FROM (
      SELECT a.QC_LBO_ID, a.QC_LBO_PLAN_ID planx, a.QC_LBO_PART partx, a.QC_LBO_DATE, a.QC_LBO_TIME, a.QC_LBO_INSPECT_TYPE, a.QC_LBO_SEQ, a.QC_LBO_LOT, a.QC_LBO_SS, a.QC_LBO_LOTX, a.QC_LBO_LOTS 
      FROM qc_lbo_input a 
      WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = '". $insType."'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
    ) a LEFT JOIN (
      #GET TOTAL CHECK
      SELECT a.QC_LBO_ID".$strSqlDefSum."
      FROM (
        SELECT a.QC_LBO_ID" .$strSqlDef."
        FROM qc_lbo_input a LEFT JOIN qc_lbo_input_detail b 
        ON a.QC_LBO_ID = b.QC_LBO_ID
        WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = '". $insType."'
      ) a GROUP BY a.QC_LBO_ID
    ) b ON a.QC_LBO_ID = b.QC_LBO_ID
    LEFT JOIN toy_part c ON a.partx = c.PART_NUM
    LEFT JOIN line e ON e.LINE_CODE = MID(a.planx, 9, 2)
    LEFT JOIN (
      ". $str_prod ."
    ) f on f.planx = a.planx 
    LEFT JOIN qc_lbo_inspector h ON h.line_code = e.LINE_CODE AND '" . $date . "' BETWEEN h.date_start AND h.date_end
    LEFT JOIN (
      SELECT a.QC_LBO_ID, COUNT(b.QC_LBO_ID) count_check
      FROM qc_lbo_input a LEFT JOIN qc_lbo_input_detail b 
      ON a.QC_LBO_ID = b.QC_LBO_ID
      WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = '". $insType."' 
      GROUP BY a.QC_LBO_ID
    ) i ON a.QC_LBO_ID = i.QC_LBO_ID
    WHERE 1=1 AND i.count_check <> 0
    " . (($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "") . "
    " . (($group !="" && $group != "ALL") ? " AND f.groupx ='$group' " : "") . "
    " . (($style !="" && $style != "ALL") ? " AND (UCASE(c.PART_NUM) LIKE '%".strtoupper($style)."%' OR UCASE(c.PART_NAME) LIKE '%".strtoupper($style)."%')" : "") . "
    ORDER BY e.LINE_PREF, e.LINE_ORDR, f.prod_datex, f.groupx, a.partx, a.QC_LBO_SEQ, a.QC_LBO_TIME;
    ";
    //echo '<pre>'. $strSql . '</pre>';
  } else if ($section == 3) { //lbo daily defect function
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];
    $insType = $_GET["inspect"];

    $strSql = "
      SELECT 
      MIN(CAST(CONCAT(LEFT(a.QC_LBO_PLAN_ID, 4), '-', MID(a.QC_LBO_PLAN_ID,5,2), '-', MID(a.QC_LBO_PLAN_ID,7,2)) AS DATE)) min_datex,
      MAX(CAST(CONCAT(LEFT(a.QC_LBO_PLAN_ID, 4), '-', MID(a.QC_LBO_PLAN_ID,5,2), '-', MID(a.QC_LBO_PLAN_ID,7,2)) AS DATE)) max_datex 
      FROM qc_lbo_input a WHERE a.QC_LBO_DATE = '".$date."';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $min_date = $row['min_datex'];
    $max_date = $row['max_datex'];

    $strSql = "
      SELECT 
      (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) planx,
      a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_DATE prod_datex
      FROM plan_prod_daily a 
      WHERE a.PLAN_PROD_DATE  BETWEEN '".$min_date."' AND '".$max_date."';
    ";

    //echo $strSql . '<br>';

    $str_prod = "SELECT '' planx, '' prod_datex, '' groupx ";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $str_prod = $str_prod . " UNION ALL
        SELECT '". $row['planx'] . "' planx, '".$row['prod_datex']."' prod_datex, '" . $row['groupx'] ."' groupx";
      }
    }
    //echo $str_prod . '<br>';

    $strSql = "SELECT * FROM defect_lbo a WHERE a.DEFECT_CAT='FUNCTION' ORDER BY a.DEFECT_CAT, a.DEFECT_ORDER ASC;";
    $strSqlDef = "";
    $strSqlDefSum = "";
    $strSqlDefSumG = "";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $strSqlDef .= ", CASE WHEN b.LBO_DEFECT_CODE = ". $row['DEFECT_CODE']." THEN 1 ELSE 0 END `d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER']."`";
        $strSqlDefSum .= ", SUM(d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER'].") `d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER']."`";
        $strSqlDefSumG .= ", IFNULL(`d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER']."`, '') `d".($row['DEFECT_CAT'] == 'AESTHETIC' ? "a" : "f")."_". $row['DEFECT_ORDER']."`";
      }
    }    

    $strSql = "
    SELECT a.QC_LBO_ID lbo_idx, a.planx, a.QC_LBO_DATE lbo_datex, a.QC_LBO_TIME lbo_timex, 
    a.QC_LBO_INSPECT_TYPE lbo_insx, e.LINE_DESC linex, e.LINE_NAME_SPV spvx, a.partx, c.PART_NAME part_namex, c.PART_TYPE part_typex,
    ". ($insType == 'T' ? 'a.QC_LBO_LOTS' : 'a.QC_LBO_SEQ')." lot_seqx, a.QC_LBO_LOT lbo_lotx, a.QC_LBO_SS lbo_ssx, a.QC_LBO_LOTX lbo_lotex, a.QC_LBO_LOTS lbo_lotexs,
    f.*, h.inspector inspectorx".$strSqlDefSumG."
    FROM (
      SELECT a.QC_LBO_ID, a.QC_LBO_PLAN_ID planx, a.QC_LBO_PART partx, a.QC_LBO_DATE, a.QC_LBO_TIME, a.QC_LBO_INSPECT_TYPE, a.QC_LBO_SEQ, a.QC_LBO_LOT, a.QC_LBO_SS, a.QC_LBO_LOTX, a.QC_LBO_LOTS 
      FROM qc_lbo_input a 
      WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = '". $insType."'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
    ) a LEFT JOIN (
      #GET TOTAL CHECK
      SELECT a.QC_LBO_ID".$strSqlDefSum."
      FROM (
        SELECT a.QC_LBO_ID" .$strSqlDef."
        FROM qc_lbo_input a LEFT JOIN qc_lbo_input_detail b 
        ON a.QC_LBO_ID = b.QC_LBO_ID
        WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = '". $insType."'
      ) a GROUP BY a.QC_LBO_ID
    ) b ON a.QC_LBO_ID = b.QC_LBO_ID
    LEFT JOIN toy_part c ON a.partx = c.PART_NUM
    LEFT JOIN line e ON e.LINE_CODE = MID(a.planx, 9, 2)
    LEFT JOIN (
      ". $str_prod ."
    ) f on f.planx = a.planx 
    LEFT JOIN qc_lbo_inspector h ON h.line_code = e.LINE_CODE AND '" . $date . "' BETWEEN h.date_start AND h.date_end
    LEFT JOIN (
      SELECT a.QC_LBO_ID, COUNT(b.QC_LBO_ID) count_check
      FROM qc_lbo_input a LEFT JOIN qc_lbo_input_detail b 
      ON a.QC_LBO_ID = b.QC_LBO_ID
      WHERE a.QC_LBO_DATE ='" . $date . "' AND a.QC_LBO_INSPECT_TYPE = '". $insType."' 
      GROUP BY a.QC_LBO_ID
    ) i ON a.QC_LBO_ID = i.QC_LBO_ID
    WHERE 1=1 AND i.count_check <> 0
    " . (($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "") . "
    " . (($group !="" && $group != "ALL") ? " AND f.groupx ='$group' " : "") . "
    " . (($style !="" && $style != "ALL") ? " AND (UCASE(c.PART_NUM) LIKE '%".strtoupper($style)."%' OR UCASE(c.PART_NAME) LIKE '%".strtoupper($style)."%')" : "") . "
    ORDER BY e.LINE_PREF, e.LINE_ORDR, f.prod_datex, f.groupx, a.partx, a.QC_LBO_SEQ, a.QC_LBO_TIME;
    ";
    //echo '<pre>'. $strSql . '</pre>';
  }
}
//echo $strSql;
//echo '<pre>'. $strSql . '</pre>';
$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
