<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

// require 'vendor/autoload.php';
// use Firebase\JWT\JWT;

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  //prod list
  if ($section == 1){ //view part list
    $style = $_GET['style'];
    $strSql = "
    SELECT a.PART_TOY_SN toyx, a.PART_NUM pnx, a.PART_NAME descx, a.PART_UNIT unitx, IFNULL(a.PART_FCH_BUYER, '') fchx, a.PART_TYPE catx,
    a.PART_TOY_TORSO torx, a.PART_TOY_DESC toydx
    FROM toy_part a 
    WHERE a.PART_TOY_SN LIKE '%$style%' OR a.PART_NUM LIKE '%$style%' OR a.PART_NAME LIKE '%$style%'
    ORDER BY a.PART_NUM;
    ";

  } else if ($section == 2){ //set user acces
    
    $style = $_GET['style'];
    $strSql = "
    SELECT a.PART_TOY_SN toyx, a.PART_NUM pnx, a.PART_NAME descx, 
      a.PART_UNIT unitx, IFNULL(a.PART_FCH_BUYER, '') fchx, a.PART_TYPE catx,
      IFNULL(a.PART_TOY_TORSO, '') torx, IFNULL(a.PART_TOY_DESC, '') toydx
    FROM toy_part a WHERE a.PART_NUM = '$style';
    ";

  } else if ($section == 3){ //add user
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $name = $_POST['name'];
    $dept = ($_POST['dept'] == '' ? 0 : $_POST['dept']);
    $unit = $_POST['unit'];
    $line = $_POST['line'];
    $email = $_POST['email'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $stat = $_POST['stat'];

    $val_data = 1;
    $msgx = ''; 
    $fieldx = '';

    if ($name == ""){
      $val_data = 0;
      $msgx += 'Name not allowed empty, ';
      $fieldx = 'NAME';
    }

    if ($uname == ""){
      $val_data = 0;
      $msgx += 'Username not allowed empty, ';
      $fieldx = 'UNAME';
    }

    if ($pass == ""){
      $val_data = 0;
      $msgx += 'Password not allowed empty.';
      $fieldx = 'PASS';
    }

    if ($val_data == 0) {
      $strSql = "SELECT 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
    } else {
      $strSql = "
      SELECT COUNT(*) REC_COUNT 
      FROM xref_user_web WHERE USER_NAME = '$uname';
      ";
      
      $res = mysqli_query($conn, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $rec_count = $row['REC_COUNT'];

      //if not exsist add
      if ($rec_count != 0){
        $msgx = "Username has been used.";
        $fieldx = 'UNAME';
        $strSql = "SELECT 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      } else {

        $pass_has = password_hash($pass, PASSWORD_BCRYPT, [10]);
        
        if ($dept == 'ALL' || $dept == '' || $dept == 'null') {
          $dept = "NULL";
        }

        if ($unit == 'ALL' || $unit == '' || $unit == 'null') {
          $unit = "NULL";
        } else {
          $unit = "'" . $unit . "'";
        }

        if ($line != '' && $line != 'null') {
          if (strlen($line) > 2) {
            $line = "'\'".str_replace( ",","\',\'", $line)."\''";
          }
        } else {
          $line = 'NULL';
        }
        
        $strSql = "INSERT INTO `xref_user_web` (
          `USER_INISIAL`, `USER_PASS`, `USER_NAME`,  
          `USER_EMAIL`, `USER_DEP`, `USER_UNIT`, `USER_LINE`, 
          `USER_AKTIF_STATUS`, `USER_ADD_DATE`, `USER_ADD_ID`
          ) VALUES (
          '$name', '$pass_has', '$uname', '$email', 
          $dept, $unit, $line, 1, NOW(), $useridx
          );
        ";

        $fieldx = 'OTHER';
        if (mysqli_query($conn, $strSql)) {
          $msgx = '';
          $action = 'SUCCESS';
        } else {
          $msgx = 'An error occurred, please try again later.';
          $action = 'ERROR';
        }
        
        $strSql = "SELECT '". $action ."' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      }
    }
        
  } else if ($section == 4){ //mod user
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $uid = $_POST['uid'];
    $name = $_POST['name'];
    $dept = ($_POST['dept'] == '' ? 0 : $_POST['dept']);
    $unit = $_POST['unit'];
    $line = $_POST['line'];
    $email = $_POST['email'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $stat = $_POST['stat'];

    $val_data = 1;
    $msgx = ''; 
    $fieldx = '';

    if ($name == ""){
      $val_data = 0;
      $msgx .= 'Name not allowed empty, ';
      $fieldx = 'NAME';
    }

    if ($val_data == 0) {
      $strSql = "SELECT $uid idx, 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
    } else {
      $strSql = "
      SELECT COUNT(*) REC_COUNT 
      FROM xref_user_web WHERE USER_NAME = '$uname' AND USER_ID <>'$uid';
      ";
      
      $res = mysqli_query($conn, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $rec_count = $row['REC_COUNT'];

      //if not exsist add
      if ($rec_count != 0){
        $msgx = "Username has been used.";
        $fieldx = 'UNAME';
        $strSql = "SELECT $uid idx, 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      } else {
        
        if ($dept == 'ALL' || $dept == '' || $dept == 'null') {
          $dept = "NULL";
        }

        if ($unit == 'ALL' || $unit == '' || $unit == 'null') {
          $unit = "NULL";
        } else {
          $unit = "'" . $unit . "'";
        }

        if ($line != '' && $line != 'null') {
          if (strlen($line) > 2) {
            $line = "'\'".str_replace( ",","\',\'", $line)."\''";
          }
        } else {
          $line = "NULL";
        }
        
        $strSql = "UPDATE `xref_user_web` SET
          `USER_INISIAL`='$name',   
          `USER_EMAIL`='$email', `USER_DEP`=$dept, `USER_UNIT`=$unit, `USER_LINE`=$line, 
          `USER_AKTIF_STATUS`=$stat, `USER_MOD_DATE`=NOW(), `USER_MOD_ID`=$useridx
          WHERE USER_ID='$uid';
        ";

        $fieldx = 'OTHER';
        if (mysqli_query($conn, $strSql)) {
          $msgx = '';
          $action = 'SUCCESS';
        } else {
          $msgx = 'An error occurred, please try again later.';
          $action = 'ERROR';
        }
        
        $strSql = "SELECT $uid idx, '". $action ."' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      }
    }
        
  } else if ($section == 5){ //del user
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $uid = $_POST['uid'];

    $strSql = "DELETE FROM `xref_menu_web_aces_new` WHERE menu_user_id='$uid';";
    $fieldx = 'OTHER';
    if (mysqli_query($conn, $strSql)) {
      $msgx = '';
      $action = 'SUCCESS';
    } else {
      $msgx = 'An error occurred, please try again later.';
      $action = 'ERROR';
    }

    $strSql = "DELETE FROM `xref_user_web` WHERE USER_ID='$uid';";
    $fieldx = 'OTHER';
    if (mysqli_query($conn, $strSql)) {
      $msgx = '';
      $action = 'SUCCESS';
    } else {
      $msgx = 'An error occurred, please try again later.';
      $action = 'ERROR';
    }
   
    $strSql = "SELECT $uid idx, '". $action ."' actionx, '$fieldx' fieldx, '$msgx' msgx;";
  
  } else if ($section == 6){ //mod stat
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $uid = $_POST['uid'];
    $stat = $_POST['stat'];
    
    $strSql = "UPDATE `xref_user_web` SET USER_AKTIF_STATUS=$stat WHERE USER_ID='$uid';";
    $fieldx = 'OTHER';
    if (mysqli_query($conn, $strSql)) {
      $msgx = '';
      $action = 'SUCCESS';
    } else {
      $msgx = 'An error occurred, please try again later.';
      $action = 'ERROR';
    }
   
    $strSql = "SELECT $uid idx, '". $action ."' actionx, '$stat' statx, '$msgx' msgx;";
  
  } else if ($section == 7){ //mod user login
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $uid = $_POST['uid'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];

    $val_data = 1;
    $msgx = ''; 
    $fieldx = '';

    if ($uname == ""){
      $val_data = 0;
      $msgx .= 'Username not allowed empty, ';
      $fieldx = 'UNAME';
    }

    if ($pass == ""){
      $val_data = 0;
      $msgx .= 'Password not allowed empty.';
      $fieldx = 'PASS';
    }

    if ($val_data == 0) {
      $strSql = "SELECT $uid idx, 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
    } else {
      $strSql = "
      SELECT COUNT(*) REC_COUNT 
      FROM xref_user_web WHERE USER_NAME = '$uname' AND USER_ID <>'$uid';
      ";
      
      $res = mysqli_query($conn, $strSql);
      $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
      $rec_count = $row['REC_COUNT'];

      //if not exsist add
      if ($rec_count != 0){
        $msgx = "Username has been used.";
        $fieldx = 'UNAME';
        $strSql = "SELECT $uid idx, 'ERROR' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      } else {

        //update user
        $pass_has = password_hash($pass, PASSWORD_BCRYPT, [10]);
        $strSql = "UPDATE `xref_user_web` SET
          `USER_NAME`='$uname',   
          `USER_PASS`='$pass_has', `USER_MOD_DATE`=NOW(), `USER_MOD_ID`=$useridx
          WHERE USER_ID='$uid';
        ";

        $fieldx = 'OTHER';
        if (mysqli_query($conn, $strSql)) {
          $msgx = '';
          $action = 'SUCCESS';
        } else {
          $msgx = 'An error occurred, please try again later.';
          $action = 'ERROR';
        }
        
        $strSql = "SELECT $uid idx, '". $action ."' actionx, '$fieldx' fieldx, '$msgx' msgx;";
      }
    }
        
  }
}
//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
