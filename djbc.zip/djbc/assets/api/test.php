<?php
error_reporting(E_ALL);
date_default_timezone_set('Asia/Jakarta');
$curtime = strtotime('10:29:42');
//echo time();
//echo setPrdTime($curtime);

phpinfo();


//echo $_POST['defc'];
//echo $_POST['defq'];

$date_to = '2025-02-20';

$curYear =  (int)(substr($date_to, 0, 4));
$strYoy = "";
for ($i = 2021; $i<=($curYear-1); $i++){
  //echo $i.'<br>';
  $strYoy .= "
    SELECT ytd_year yearx, SUM(ytd_ss) ssx, SUM(ytd_good) goodx, SUM(ytd_defa) defax, SUM(ytd_deff) deffx, SUM(ytd_deft) deftx 
    FROM qc_lbo_ytd 
    WHERE ytd_year = $i 
    GROUP BY ytd_year UNION ALL";
}
$strYoy = substr($strYoy, 0, strlen($strYoy)-9);

echo $strYoy.'<br>';

$curxDate = new DateTime('2025-02-20');
$curxWeek =  (int)$curxDate->format("w");
$curxAdd = ' + '.((6 - $curxWeek) + 1) .' days';
$curxEnd = New DateTime(date('Y-m-d', strtotime('2025-02-20 '. $curxAdd)));
$curxSta = New DateTime($curxEnd->format("Y").'-01-01');
$curxInv =  DateInterval::createFromDateString('1 day');
$curxPer = new DatePeriod($curxSta, $curxInv, $curxEnd);

foreach ($curxPer as $dt) {
  if ($dt->format("w") == "6") {
    echo $dt->format("Y-m-d").'<br>';
  }
}


function setPrdTime($curtime) {
  $prdTime = '';
  if ($curtime >= strtotime('07:00:00') && $curtime <= strtotime('09:29:59')) {
    $prdTime = '08:30:00';
  } else if ($curtime >= strtotime('09:30:00') && $curtime <= strtotime('10:29:59')){
    $prdTime = '09:30:00';
  } else if ($curtime >= strtotime('10:30:00') && $curtime <= strtotime('11:29:59')){
    $prdTime = '10:30:00';
  } else if ($curtime >= strtotime('11:30:00') && $curtime <= strtotime('12:29:59')){
    $prdTime = '11:30:00';
  } else if ($curtime >= strtotime('12:30:00') && $curtime <= strtotime('13:29:59')){
    $prdTime = '12:30:00';
  } else if ($curtime >= strtotime('13:30:00') && $curtime <= strtotime('14:29:59')){
    $prdTime = '13:30:00';
  } else if ($curtime >= strtotime('14:30:00') && $curtime <= strtotime('15:29:59')){
    $prdTime = '14:30:00';
  } else if ($curtime >= strtotime('15:30:00') && $curtime <= strtotime('16:29:59')){
    $prdTime = '15:30:00';
  } else if ($curtime >= strtotime('16:30:00') && $curtime <= strtotime('17:29:59')){
    $prdTime = '16:30:00';
  } else if ($curtime >= strtotime('17:30:00') && $curtime <= strtotime('18:29:59')){
    $prdTime = '17:30:00';
  } else if ($curtime >= strtotime('18:30:00') && $curtime <= strtotime('19:29:59')){
    $prdTime = '18:30:00';
  } else if ($curtime >= strtotime('19:30:00') && $curtime <= strtotime('20:29:59')){
    $prdTime = '19:30:00';
  } else if ($curtime >= strtotime('20:30:00') && $curtime <= strtotime('21:29:59')){
    $prdTime = '20:30:00';
  } else if ($curtime >= strtotime('21:30:00') && $curtime <= strtotime('22:29:59')){
    $prdTime = '21:30:00';
  } else if ($curtime >= strtotime('22:30:00') && $curtime <= strtotime('23:59:59')){
    $prdTime = '22:30:00';
  }
  return $prdTime;
}
