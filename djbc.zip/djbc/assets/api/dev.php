<?php

// if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
//   header('Access-Control-Allow-Origin: *');
//   header('Access-Control-Allow-Methods: POST, GET, DELETE, PUT, PATCH, OPTIONS');
//   header('Access-Control-Allow-Headers: token, Content-Type');
//   header('Access-Control-Max-Age: 1728000');
//   header('Content-Length: 0');
//   header('Content-Type: text/plain');
//   die();
// }

header('Access-Control-Allow-Origin: *');
// header('Content-Type: application/json');

session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

$auth = true;

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";


if ($section == 1){
  $strSql = "SELECT 'ACT SEL' actx";
} else if ($section == 2) {
  $strSql = "SELECT 'ACT ADD' actx";
} else if ($section == 3) {
  $strSql = "SELECT 'ACT MOD' actx";
} else if ($section == 4) {
  $strSql = "SELECT 'DEL";
}

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {

  $res = mysqli_query($conn_hr, $strSql);
  if (mysqli_num_rows($res) > 0) {
    
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);