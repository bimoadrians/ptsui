<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";
date_default_timezone_set('Asia/Jakarta');

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];
$menu_del = $accx['menu_act_del'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
}

function setPrdTime($curtime) {
  $prdTime = '';
  if ($curtime >= strtotime('04:00:00') && $curtime <= strtotime('09:29:59')) {
    $prdTime = '08:30:00';
  } else if ($curtime >= strtotime('09:30:00') && $curtime <= strtotime('10:29:59')){
    $prdTime = '09:30:00';
  } else if ($curtime >= strtotime('10:30:00') && $curtime <= strtotime('11:29:59')){
    $prdTime = '10:30:00';
  } else if ($curtime >= strtotime('11:30:00') && $curtime <= strtotime('12:29:59')){
    $prdTime = '11:30:00';
  } else if ($curtime >= strtotime('12:30:00') && $curtime <= strtotime('13:29:59')){
    $prdTime = '12:30:00';
  } else if ($curtime >= strtotime('13:30:00') && $curtime <= strtotime('14:29:59')){
    $prdTime = '13:30:00';
  } else if ($curtime >= strtotime('14:30:00') && $curtime <= strtotime('15:29:59')){
    $prdTime = '14:30:00';
  } else if ($curtime >= strtotime('15:30:00') && $curtime <= strtotime('16:29:59')){
    $prdTime = '15:30:00';
  } else if ($curtime >= strtotime('16:30:00') && $curtime <= strtotime('17:29:59')){
    $prdTime = '16:30:00';
  } else if ($curtime >= strtotime('17:30:00') && $curtime <= strtotime('18:29:59')){
    $prdTime = '17:30:00';
  } else if ($curtime >= strtotime('18:30:00') && $curtime <= strtotime('19:29:59')){
    $prdTime = '18:30:00';
  } else if ($curtime >= strtotime('19:30:00') && $curtime <= strtotime('20:29:59')){
    $prdTime = '19:30:00';
  } else if ($curtime >= strtotime('20:30:00') && $curtime <= strtotime('21:29:59')){
    $prdTime = '20:30:00';
  } else if ($curtime >= strtotime('21:30:00') && $curtime <= strtotime('22:29:59')){
    $prdTime = '21:30:00';
  } else if ($curtime >= strtotime('22:30:00') && $curtime <= strtotime('23:59:59')){
    $prdTime = '22:30:00';
  }
  return $prdTime;
}

if ($auth != false) {
  //prod list
  if ($section == 1){ //view summary transfer lbo
    $date = $_GET["date"];
    $unit = $_GET["unit"];

    $strSql = "
    SELECT sa.partx, sc.PART_NAME partdx, SUM(pqty) pqty, SUM(tqty) tqty 
    FROM (
      SELECT a.transfer_line linex, a.transfer_part partx, IFNULL(a.transfer_group,'') groupx, 0 pqty, SUM(a.transfer_qty) tqty 
      FROM wip_count_scan a 
      LEFT JOIN line b ON a.transfer_line = b.LINE_CODE
      WHERE a.transfer_date ='$date' AND b.LINE_PREF = '$unit' 
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.transfer_date NOT IN $GLOB_AUDIT_DATE")."
      GROUP BY a.transfer_line, a.transfer_part, IFNULL(a.transfer_group,'')
    ) sa 
    LEFT JOIN line sb ON sa.linex = sb.LINE_CODE
    LEFT JOIN toy_part sc ON sa.partx = sc.PART_NUM
    GROUP BY sa.partx, sc.PART_NAME
    ORDER BY sc.PART_NAME;
    ";
    //echo '<pre>'. $strSql . '</pre>';

  } else if ($section == 2) { //view barcode transfer lbo
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $strSql = "
    SELECT a.transfer_date datex, a.transfer_time timex, a.transfer_barcode barcodex, 
      b.LINE_PREF unitx, a.transfer_line linex, b.LINE_DESC linedx, 
      a.transfer_part partx, c.PART_NAME partdx, a.transfer_group groupx, a.transfer_qty trfx 
    FROM wip_count_scan a 
    LEFT JOIN line b ON a.transfer_line = b.LINE_CODE
    LEFT JOIN toy_part c ON a.transfer_part = c.PART_NUM
    WHERE a.transfer_date ='$date' 
    ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.transfer_date NOT IN $GLOB_AUDIT_DATE")."
    AND b.LINE_PREF = '$unit' ORDER BY a.transfer_date, a.transfer_time;
    ";
    //echo '<pre>'. $strSql . '</pre>';

  } else if ($section == 3) { // add scan barcode
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $date = $_POST["date"];
    $barcode = $_POST["barcode"];
    $unit = $_POST["unit"];
    
    //CHEK SCAN
    $strSql ="
    SELECT COUNT(a.PACK_BRCD_NUM) countx, COUNT(c.transfer_barcode) countrx, a.PACK_BRCD_DATE brcdatex,
      a.PACK_BRCD_LINE linex, b.LINE_DESC linedx, a.PACK_BRCD_LEADER leadx, a.PACK_BRCD_GRP groupx,
      a.PACK_BRCD_PART partx, d.PART_NAME partdx, IFNULL(a.PACK_BRCD_QTY, 0) qtyx 
    FROM pack_brcd a 
    LEFT JOIN line b on a.PACK_BRCD_LINE = b.LINE_CODE
    LEFT JOIN wip_count_scan c on a.PACK_BRCD_NUM = c.transfer_barcode AND c.transfer_date = '$date'
    LEFT JOIN toy_part d on a.PACK_BRCD_PART = d.PART_NUM
    WHERE a.PACK_BRCD_NUM='$barcode' AND b.LINE_PREF='$unit' 
    AND a.PACK_BRCD_FLAG = 'N';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
        
    $count_brcd = (int)$row['countx'];
    $count_trfx = (int)$row['countrx'];
    $barcode_date = $row['brcdatex'];
    $line = $row['linex'];
    $lined = $row['linedx'];
    $part = $row['partx'];
    $partd = $row['partdx'];
    $lead = $row['leadx'];
    $group = $row['groupx'];
    $qty = $row['qtyx'];
    $prdtime = setPrdTime(time());

    //invalid barcode or unit
    $action = '';
    $actionFlag = '';
    $actionMsg = '';
    
    $sqlAct = '';

    if ($count_brcd == 0) {
      $action = 'FALSE';
      $actionFlag = 'INVALID';
      $actionMsg = 'Barcode atau unit tidak valid.';
    } else {
      // update data
      if ($count_trfx != 0) {
        $sqlAct = "
        UPDATE `wip_count_scan` SET 
          `transfer_count`=`transfer_count`+1,
          `transfer_scan_second`=NOW(),
          `transfer_mod_date`=NOW(),
          `transfer_mod_id`='$useridx'
        WHERE transfer_barcode='$barcode' AND transfer_date='$date';  
        ";
        $actionFlag = "UPDATE";
        $actionMsg = 'Succes re-scan barcode.';
      // insert data
      } else {
        $sqlAct = "
        INSERT INTO `wip_count_scan` (
          `transfer_date`, `transfer_barcode`, `transfer_time`, 
          `transfer_barcode_date`, `transfer_prod_time`, `transfer_line`, `transfer_part`, 
          `transfer_group`, `transfer_lead`, `transfer_qty`, 
          `transfer_count`, `transfer_scan_frist`,
          `transfer_add_date`, `transfer_add_id`
        ) VALUES (
          '$date', '$barcode', NOW(), 
          '$barcode_date', '$prdtime', '$line', '$part', 
          '$group', '$lead', '$qty', 
          1, NOW(),
          NOW(), $useridx
        );";
        $actionFlag = "INSERT";
        $actionMsg = 'Succes add or update barcode.';
      }
      //echo '<pre>'. $sqlAct . '</pre>';
      $action = '';
      if (mysqli_query($conn, $sqlAct)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
        $actionMsg = 'Invalid barcode or unit.';
      }
    }
    $strSql = "SELECT '$action' actionx, '$actionFlag' actionflagx, '$actionMsg' msgx, CURDATE() datex, CURTIME() timex, '$barcode' barcodex, '$unit' unitx, '$line' linex, '$lined' linedx, '$lead' leadx, '$part' partx, '$partd' partdx, '$group' groupx, '$qty' qtyx;";
  
  } else if ($section == 4) { // del scan barcode
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $date = $_POST["date"];
    $barcode = $_POST["barcode"];
    $rowid = $_POST["rowid"];
    
    $strSql = "SELECT DATEDIFF(CURDATE(), a.transfer_date) otsx FROM wip_count_scan a WHERE transfer_barcode='$barcode';";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $ots = (int)$row['otsx'];

    if ($ots < 4) {
      $strSql ="DELETE FROM wip_count_scan WHERE transfer_barcode='$barcode' and transfer_date='$date';";
      $action ='';
      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }
      $strSql = "SELECT '$action' actionx, 'Success deleting barcode' msgx, '$rowid' rowx;";
    } else {
      $strSql = "SELECT 'FALSE' actionx, 'Exced maximum delete date.' msgx, '$rowid' rowx;";
    }
  } 
}
//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
