<?php
session_start();
//error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ERROR);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
} 

if ($auth != false) {
  //prod list
  if ($section == 1) { //Prod Pef
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];

    $oldQuery = "
    SELECT REPLACE(REPLACE(a.OUT_PLAN_ID, 'N',''),'O','') planx, 
        HOUR(a.OUT_PROD_TIME) hourx, 
        SUM(a.OUT_PROD_QTY) qtyx
        FROM output_prod_good a 
        WHERE a.OUT_PROD_DATE = '$date' 
        AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
        GROUP BY REPLACE(REPLACE(a.OUT_PLAN_ID, 'N',''),'O',''), HOUR(a.OUT_PROD_TIME)
    ";

    $strSql = "
    SELECT ga.*, ROUND((aehx/aahx)*100,0) effx
    FROM (
      SELECT a.planx, c.linex, c.groupx, c.partx, c.fchx, c.peffx, c.dayx, 
        c.phcx, c.pwhx, c.pqtyx, (c.fchx * IFNULL(c.pqtyx,0))/1000 pehx, 
        d.ahcx, (g.awhx/60) awhx, g.taqtyx, g.tltrfx, 
        CASE WHEN c.pwhx < 1 THEN (c.pwhx * d.ahcx) ELSE ((d.ahcx) * (g.awhx/60)) END aahx, 
        (c.fchx * IFNULL(g.taqtyx,0))/1000 aehx, 
        e. a.hourx, IFNULL(a.qtyx, 0) qtyx, IFNULL(a.ltrfx, 0) ltrfx, IFNULL(b.issuex,'') issuex, e.LINE_PREF prefx, e.LINE_DESC line_namex, e.LINE_NAME_SPV leadx, f.PART_NAME part_namex, h.tphcx, h.tahcx 
      FROM (

        SELECT planx, hourx, SUM(qtyx) qtyx, SUM(ltrfx) ltrfx 
        FROM (
          SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) planx, 
          HOUR(a.OUT_PROD_TIME) hourx, 
          SUM(a.OUT_PROD_QTY) qtyx, 0 ltrfx
          FROM output_prod_good a 
          WHERE a.OUT_PROD_DATE = '$date' 
          AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D' AND OUT_PROD_TYPE = 'N'
          GROUP BY CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')), HOUR(a.OUT_PROD_TIME) 
          UNION ALL
          SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) planx, 
          HOUR(a.OUT_PROD_TIME) hourx, 
          SUM(a.OUT_PROD_QTY) qtyx, 0 ltrfx
          FROM output_prod_good a 
          WHERE a.OUT_PROD_DATE = '$date' 
          AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D' AND OUT_PROD_TYPE = 'O'
          GROUP BY CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')), HOUR(a.OUT_PROD_TIME) 
          UNION ALL
          SELECT planx, hourx, 0 qtyx, ltrfx 
          FROM (        
            SELECT b.planx, HOUR(a.transfer_prod_time) hourx, SUM(a.transfer_qty) ltrfx
            FROM qc_lbo_transfer a 
            LEFT JOIN (
              SELECT (REPLACE(CONCAT(CAST(sa.PLAN_PROD_DATE AS CHAR), CAST(sa.PLAN_PROD_LINE_CODE AS CHAR), CAST(sa.PLAN_PROD_PART AS CHAR), CAST(sa.PLAN_PROD_GROUP AS CHAR)),'-','')) planx,
              sa.PLAN_PROD_PART partx, sa.PLAN_PROD_LINE_CODE linex, sa.PLAN_PROD_GROUP_ORD groupx
              FROM plan_prod_daily sa WHERE sa.PLAN_PROD_DATE = '$date'
              GROUP BY (REPLACE(CONCAT(CAST(sa.PLAN_PROD_DATE AS CHAR), CAST(sa.PLAN_PROD_LINE_CODE AS CHAR), CAST(sa.PLAN_PROD_PART AS CHAR), CAST(sa.PLAN_PROD_GROUP AS CHAR)),'-','')), 
              sa.PLAN_PROD_PART, sa.PLAN_PROD_LINE_CODE, sa.PLAN_PROD_GROUP_ORD
            ) b ON a.transfer_line = b.linex AND a.transfer_part = b.partx AND a.transfer_group = b.groupx
            WHERE a.transfer_date ='$date'
            GROUP BY b.planx, HOUR(a.transfer_prod_time)
          ) a WHERE IFNULL(planx, '') <> '' 
        ) a GROUP BY planx, hourx

      ) a 
      LEFT JOIN (
        SELECT plan_id, datex, timex hourx, GROUP_CONCAT(issuex SEPARATOR '<br />') issuex  
        FROM (
          SELECT a.plan_id, a.issue_date datex, a.issue_hour timex, GROUP_CONCAT(UCASE(b.prod_issue_desc)  SEPARATOR '<br />') issuex
          FROM output_prod_issue a
          LEFT JOIN xref_prod_issue b ON a.issue_id = b.prod_issue_id
          WHERE a.issue_date = '$date' AND b.prod_issue_cat <> 'PROCESS'
          GROUP BY a.plan_id, a.issue_date, a.issue_hour UNION ALL
          SELECT a.plan_id, a.issue_date datex, a.issue_hour timex, GROUP_CONCAT(UCASE(a.issue_proc_desc)  SEPARATOR '<br />') issuex
          FROM output_prod_issue a
          LEFT JOIN xref_prod_issue b ON a.issue_id = b.prod_issue_id
          WHERE a.issue_date = '$date' AND b.prod_issue_cat = 'PROCESS'
          GROUP BY a.plan_id, a.issue_date, a.issue_hour
        ) a GROUP BY plan_id, datex, timex
      ) b ON a.planx = b.plan_id AND a.hourx = b.hourx
      RIGHT JOIN (
        SELECT (REPLACE(CONCAT(CAST(sa.PLAN_PROD_DATE AS CHAR), CAST(sa.PLAN_PROD_LINE_CODE AS CHAR), CAST(sa.PLAN_PROD_PART AS CHAR), CAST(sa.PLAN_PROD_GROUP AS CHAR)),'-','')) planx,
        sa.PLAN_PROD_PART partx, sa.PLAN_PROD_FCH fchx, sa.PLAN_PROD_EFF peffx, sa.PLAN_PROD_LINE_CODE linex, sa.PLAN_PROD_GROUP_ORD groupx, sa.PLAN_PROD_RD dayx,
        sa.PLAN_PROD_OPT phcx, SUM(sa.PLAN_PROD_WH) pwhx, SUM(sa.PLAN_PROD_QTY) pqtyx
        FROM plan_prod_daily sa WHERE sa.PLAN_PROD_DATE = '$date'
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND sa.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
        GROUP BY (REPLACE(CONCAT(CAST(sa.PLAN_PROD_DATE AS CHAR), CAST(sa.PLAN_PROD_LINE_CODE AS CHAR), CAST(sa.PLAN_PROD_PART AS CHAR), CAST(sa.PLAN_PROD_GROUP AS CHAR)),'-','')), 
        sa.PLAN_PROD_PART, sa.PLAN_PROD_FCH, sa.PLAN_PROD_EFF, sa.PLAN_PROD_LINE_CODE, sa.PLAN_PROD_GROUP_ORD, sa.PLAN_PROD_OPT, sa.PLAN_PROD_RD
      ) c ON a.planx = c.planx
      LEFT JOIN (
        SELECT DISTINCT planx, ahcx FROM (
          SELECT DISTINCT CONCAT(LEFT(sa.PLAN_ID, 19), REPLACE(RIGHT(sa.PLAN_ID, LENGTH(sa.PLAN_ID) - 19), 'N','')) planx, sa.OUT_PROD_GOOD_AHC ahcx 
          FROM output_prod_good_hc sa 
          WHERE LEFT(sa.PLAN_ID, 8) = '". str_replace('-', '', $date)."'  
          AND INSTR(RIGHT(sa.PLAN_ID, LENGTH(sa.PLAN_ID) - 19), 'N') <> 0 
          UNION ALL
          SELECT DISTINCT CONCAT(LEFT(sa.PLAN_ID, 19), REPLACE(RIGHT(sa.PLAN_ID, LENGTH(sa.PLAN_ID) - 19), 'O','')) planx, sa.OUT_PROD_GOOD_AHC ahcx 
          FROM output_prod_good_hc sa 
          WHERE LEFT(sa.plan_id,8) = '". str_replace('-', '', $date)."'  
          AND INSTR(RIGHT(sa.PLAN_ID, LENGTH(sa.PLAN_ID) - 19), 'O') <> 0
        ) a
      ) d ON a.planx = d.planx
      LEFT JOIN line e ON c.linex = e.LINE_CODE
      LEFT JOIN toy_part f ON c.partx = f.PART_NUM
      LEFT JOIN (
        SELECT planx, SUM(WH_ACT) awhx, SUM(aqtyx) taqtyx, SUM(tltrfx) tltrfx
        FROM (
          SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'N','')) planx,
          count_actual_wh(HOUR(a.FIRST_TIME), HOUR(a.LAST_TIME), a.OUT_PROD_DATE) * 60 WH_ACT, aqtyx, 0 tltrfx
          FROM (
            SELECT 
              a.OUT_PLAN_ID,
              a.OUT_PROD_DATE,
              MIN(a.OUT_PROD_TIME) FIRST_TIME,
              MAX(a.OUT_PROD_TIME) LAST_TIME,
              TIMESTAMPDIFF(MINUTE, MIN(a.OUT_PROD_TIME), MAX(a.OUT_PROD_TIME)) WH_ACT, 0 HC_ACT, SUM(a.OUT_PROD_QTY) aqtyx
            FROM output_prod_good a 
            WHERE a.OUT_PROD_DATE = '$date'
            AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
            AND a.OUT_PROD_TYPE = 'N'
            GROUP BY a.OUT_PLAN_ID, a.OUT_PROD_DATE
          ) a UNION ALL
          
          SELECT CONCAT(LEFT(a.OUT_PLAN_ID, 19), REPLACE(RIGHT(a.OUT_PLAN_ID, LENGTH(a.OUT_PLAN_ID) - 19), 'O','')) planx,
          count_actual_wh(HOUR(a.FIRST_TIME), HOUR(a.LAST_TIME), a.OUT_PROD_DATE) * 60 WH_ACT, aqtyx, 0 tltrfx
          FROM (
            SELECT 
              a.OUT_PLAN_ID,
              a.OUT_PROD_DATE,
              MIN(a.OUT_PROD_TIME) FIRST_TIME,
              MAX(a.OUT_PROD_TIME) LAST_TIME,
              TIMESTAMPDIFF(MINUTE, MIN(a.OUT_PROD_TIME), MAX(a.OUT_PROD_TIME)) WH_ACT, 0 HC_ACT, SUM(a.OUT_PROD_QTY) aqtyx
            FROM output_prod_good a 
            WHERE a.OUT_PROD_DATE = '$date'
            AND IFNULL(a.OUT_PROD_FLAG_DEL,'') <> 'D'
            AND a.OUT_PROD_TYPE = 'O'
            GROUP BY a.OUT_PLAN_ID, a.OUT_PROD_DATE
          ) a UNION ALL

          SELECT planx, 0 whx, 0 aqtyx, tltrfx 
          FROM (        
            SELECT b.planx, SUM(a.transfer_qty) tltrfx
            FROM qc_lbo_transfer a 
            LEFT JOIN (
              SELECT (REPLACE(CONCAT(CAST(sa.PLAN_PROD_DATE AS CHAR), CAST(sa.PLAN_PROD_LINE_CODE AS CHAR), CAST(sa.PLAN_PROD_PART AS CHAR), CAST(sa.PLAN_PROD_GROUP AS CHAR)),'-','')) planx,
              sa.PLAN_PROD_PART partx, sa.PLAN_PROD_LINE_CODE linex, sa.PLAN_PROD_GROUP_ORD groupx
              FROM plan_prod_daily sa WHERE sa.PLAN_PROD_DATE = '$date'
              GROUP BY (REPLACE(CONCAT(CAST(sa.PLAN_PROD_DATE AS CHAR), CAST(sa.PLAN_PROD_LINE_CODE AS CHAR), CAST(sa.PLAN_PROD_PART AS CHAR), CAST(sa.PLAN_PROD_GROUP AS CHAR)),'-','')), 
              sa.PLAN_PROD_PART, sa.PLAN_PROD_LINE_CODE, sa.PLAN_PROD_GROUP_ORD
            ) b ON a.transfer_line = b.linex AND a.transfer_part = b.partx AND a.transfer_group = b.groupx
            WHERE a.transfer_date ='$date'
            GROUP BY b.planx
          ) a WHERE IFNULL(planx, '') <> '' 

        ) a GROUP BY planx
      ) g ON a.planx = g.planx
      LEFT JOIN  (
        SELECT SUM(tphcx) tphcx, SUM(tahcx) tahcx 
        FROM (
          SELECT SUM(tphcx) tphcx, 0 tahcx 
          FROM (
            SELECT DISTINCT a.PLAN_PROD_DATE, a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_GROUP, a.PLAN_PROD_OPT tphcx
            FROM plan_prod_daily a 
            LEFT JOIN line c on a.PLAN_PROD_LINE_CODE = c.LINE_CODE
            WHERE a.PLAN_PROD_DATE = '$date'
            " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
            " . (($line !="" && $line != "ALL") ? " AND c.LINE_CODE ='$line' " : "") . "
            " . (($line_all !="") ? " AND c.LINE_CODE IN (" . $line_all . ")" : "") . "
          ) a
          UNION ALL
          SELECT 0 phcx, SUM(hcx) tahcx 
          FROM (
            SELECT DISTINCT  gidx, hcx 
            FROM (
              SELECT CONCAT(LEFT(planx, 10), RIGHT(planx, LENGTH(planx) - INSTR(planx,'X'))) gidx, a.hcx
              FROM (
                SELECT CONCAT(LEFT(a.PLAN_ID, 19), REPLACE(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'N','X')) planx, a.OUT_PROD_GOOD_AHC hcx
                FROM output_prod_good_hc a 
                LEFT JOIN plan_prod_daily b ON a.PLAN_ID = (REPLACE(CONCAT(CAST(b.PLAN_PROD_DATE AS CHAR), CAST(b.PLAN_PROD_LINE_CODE AS CHAR), CAST(b.PLAN_PROD_PART AS CHAR), CAST(b.PLAN_PROD_FLAG AS CHAR), CAST(b.PLAN_PROD_GROUP AS CHAR)),'-','')) 
                LEFT JOIN line c on b.PLAN_PROD_LINE_CODE = c.LINE_CODE
                WHERE LEFT(a.PLAN_ID,8) = '".str_replace('-', '', $date)."' 
                AND INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'N') <> 0
                AND B.PLAN_PROD_DATE = '$date'
                " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
                " . (($line !="" && $line != "ALL") ? " AND c.LINE_CODE ='$line' " : "") . "
                " . (($line_all !="") ? " AND c.LINE_CODE IN (" . $line_all . ")" : "") . "
                UNION ALL
                SELECT CONCAT(LEFT(a.PLAN_ID, 19), REPLACE(RIGHT(A.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'O','X')) planx, a.OUT_PROD_GOOD_AHC hcx
                FROM output_prod_good_hc a 
                LEFT JOIN plan_prod_daily b ON a.PLAN_ID = (REPLACE(CONCAT(CAST(b.PLAN_PROD_DATE AS CHAR), CAST(b.PLAN_PROD_LINE_CODE AS CHAR), CAST(b.PLAN_PROD_PART AS CHAR), CAST(b.PLAN_PROD_FLAG AS CHAR), CAST(b.PLAN_PROD_GROUP AS CHAR)),'-','')) 
                LEFT JOIN line c on b.PLAN_PROD_LINE_CODE = c.LINE_CODE
                WHERE LEFT(a.PLAN_ID,8) = '".str_replace('-', '', $date)."' 
                AND B.PLAN_PROD_DATE = '$date'
                AND INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 19), 'O') <> 0
                " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
                " . (($line !="" && $line != "ALL") ? " AND c.LINE_CODE ='$line' " : "") . "
                " . (($line_all !="") ? " AND c.LINE_CODE IN (" . $line_all . ")" : "") . "
              ) a
            ) a
          ) a
        ) a
      ) h on 1=1
      WHERE 1=1
      " . (($unit !="" && $unit != "ALL") ? " AND e.LINE_PREF ='$unit' " : "") . "
      " . (($line !="" && $line != "ALL") ? " AND e.LINE_CODE ='$line' " : "") . "
      " . (($line_all !="") ? " AND e.LINE_CODE IN (" . $line_all . ")" : "") . "
    ) ga 
    ORDER BY  ROUND(((aehx/aahx)*100),0)/(peffx * 100), planx, hourx
    ";

  } else if ($section == 2) { //Quality Pef
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $style = $_GET["style"];
    $group = $_GET["group"];
    $insType = $_GET["inspect"];
    $defect = $_GET["defect"];
    $line_all = $_GET["line_all"];

    $strSql = "
      SELECT 
      MIN(CAST(CONCAT(LEFT(a.QC_LBO_PLAN_ID, 4), '-', MID(a.QC_LBO_PLAN_ID,5,2), '-', MID(a.QC_LBO_PLAN_ID,7,2)) AS DATE)) min_datex,
      MAX(CAST(CONCAT(LEFT(a.QC_LBO_PLAN_ID, 4), '-', MID(a.QC_LBO_PLAN_ID,5,2), '-', MID(a.QC_LBO_PLAN_ID,7,2)) AS DATE)) max_datex 
      FROM qc_lbo_input a WHERE a.QC_LBO_DATE = '".$date."';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $min_date = $row['min_datex'];
    $max_date = $row['max_datex'];

    $strSql = "
      SELECT 
      (REPLACE(CONCAT(CAST(a.PLAN_PROD_DATE AS CHAR), CAST(a.PLAN_PROD_LINE_CODE AS CHAR),
      CAST(a.PLAN_PROD_PART AS CHAR), CAST(a.PLAN_PROD_FLAG AS CHAR), CAST(a.PLAN_PROD_GROUP AS CHAR)),'-','')) planx,
      a.PLAN_PROD_GROUP_ORD groupx, a.PLAN_PROD_DATE prod_datex
      FROM plan_prod_daily a 
      WHERE a.PLAN_PROD_DATE  BETWEEN '".$min_date."' AND '".$max_date."'
      ;
    ";

    //echo $strSql . '<br>';

    $str_prod = "SELECT '' planx, '' prod_datex, '' groupx ";
    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        $str_prod = $str_prod . " UNION ALL
        SELECT '". $row['planx'] . "' planx, '".$row['prod_datex']."' prod_datex, '" . $row['groupx'] ."' groupx";
      }
    }
    //echo $str_prod . '<br>';
    
    $strSql = "
    SELECT a.*, CONCAT(a.linex,'-', a.partx, '-', a.groupx) alias_idx, a.timex hourx,b.tlotx, b.tssx, b.def_ax, b.def_fx,
    b.ppmx, c.LINE_DESC line_namex, d.PART_NAME part_namex, d.PART_TYPE part_catx
    FROM (
      SELECT timex, linex, partx, groupx, 
      SUM(lotx) lotx, SUM(ssx) ssx, SUM(goodx) goodx, SUM(defx) defx, 
      SUM(aestx) aestx, SUM(funcx) funcx, 
      IFNULL(GROUP_CONCAT(DISTINCT def_namex),'') def_namex, IFNULL(GROUP_CONCAT(DISTINCT proc_namex),'') proc_namex
      FROM (
        SELECT datex, timex, linex, partx, groupx, seqx, lotx, ssx, 
        SUM(goodx) goodx, SUM(defx) defx, SUM(aestx) aestx, SUM(funcx) funcx, GROUP_CONCAT(DISTINCT def_namex) def_namex, GROUP_CONCAT(DISTINCT proc_namex) proc_namex
        FROM (
          SELECT 
          a.QC_LBO_DATE datex, 
          HOUR(a.QC_LBO_TIME) timex, 
          a.QC_LBO_PLAN_ID planx,
          MID(a.QC_LBO_PLAN_ID, 9, 2) linex,
          a.QC_LBO_PART partx, e.groupx,
          a.QC_LBO_SEQ seqx, 
          a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx, 
          b.LBO_CATEGORY inspx,
          CASE WHEN b.LBO_CATEGORY = 'GOOD' THEN 1 ELSE 0 END goodx,
          CASE WHEN b.LBO_CATEGORY = 'DEFECT' THEN 1 ELSE 0 END defx,
          CASE WHEN c.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END aestx,
          CASE WHEN c.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END funcx,
          c.DEFECT_CAT def_catx, c.DEFECT_NAME def_namex, d.CBSD_PROC_DESC proc_namex
          FROM qc_lbo_input a 
          LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
          LEFT JOIN defect_lbo c ON b.LBO_DEFECT_CODE = c.DEFECT_CODE
          LEFT JOIN toy_part_cbsd d ON d.CBSD_PART_NUM = a.QC_LBO_PART AND b.LBO_PROCESS_ID = d.CBSD_ID
          LEFT JOIN (
          ". $str_prod ."
          ) e on a.QC_LBO_PLAN_ID = e.planx 
          WHERE a.QC_LBO_DATE = '" . $date . "' 
          ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.QC_LBO_DATE NOT IN $GLOB_AUDIT_DATE")."
          ".(($defect !="" && $defect != "ALL") ? " AND b.LBO_DEFECT_CODE ='$defect' " : "") ."
          AND a.QC_LBO_INSPECT_TYPE = 'N'
        ) a 
        GROUP BY datex, timex, linex, partx, groupx, seqx, lotx, ssx
      ) a GROUP BY timex, linex, partx, groupx
    ) a LEFT JOIN (
      SELECT linex, partx, groupx, lotx tlotx, ssx tssx, IFNULL(def_ax, 0) def_ax, IFNULL(def_fx, 0) def_fx,((IFNULL(def_ax, 0) + IFNULL(def_fx, 0))/ssx) * 1000000 ppmx , (defx/ssx) * 1000000 ppmxz 
      FROM (
        SELECT linex, partx, groupx, SUM(lotx) lotx, SUM(ssx) ssx, SUM(def_ax) def_ax, SUM(def_fx) def_fx, SUM(defx) defx
        FROM (
          SELECT linex, partx, groupx, seqx, lotx, ssx, SUM(def_ax) def_ax, SUM(def_fx) def_fx, SUM(defx) defx
          FROM (
            SELECT MID(a.QC_LBO_PLAN_ID, 9, 2) linex, a.QC_LBO_PART partx, c.groupx, a.QC_LBO_SEQ seqx, a.QC_LBO_LOT lotx, a.QC_LBO_SS ssx,
            CASE WHEN b.LBO_CATEGORY = 'DEFECT' THEN 1 ELSE 2 END defx,
            CASE WHEN d.DEFECT_CAT = 'AESTHETIC' THEN 1 ELSE 0 END def_ax,
            CASE WHEN d.DEFECT_CAT = 'FUNCTION' THEN 1 ELSE 0 END def_fx
            FROM qc_lbo_input a 
            LEFT JOIN qc_lbo_input_detail b ON a.QC_LBO_ID = b.QC_LBO_ID
            LEFT JOIN (
            ". $str_prod ."
            ) c ON a.QC_LBO_PLAN_ID = c.planx
            LEFT JOIN defect_lbo d ON b.LBO_DEFECT_CODE = d.DEFECT_CODE
            WHERE a.QC_LBO_DATE = '" . $date . "'
            " . (($defect !="" && $defect != "ALL") ? " AND b.LBO_DEFECT_CODE ='$defect' " : "") . "
            AND a.QC_LBO_INSPECT_TYPE = 'N'
          ) a GROUP BY linex, partx, groupx, seqx, lotx, ssx
        ) a GROUP BY linex, partx, groupx
      ) a 
    ) b ON a.linex = b.linex AND a.partx = b.partx AND a.groupx = b.groupx 
    LEFT JOIN line c on a.linex = c.LINE_CODE
    LEFT JOIN toy_part d ON a.partx = d.PART_NUM
    WHERE 1=1
    " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND c.LINE_CODE ='$line' " : "") . "
    " . (($line_all !="") ? " AND c.LINE_CODE IN (" . $line_all . ")" : "") . "
    ORDER BY b.ppmx DESC, linex, partx, groupx, timex ASC";
  
  } else if ($section == 3) { //shipment

    $date = $_GET['date'];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];

    $date_part = date_create($date);
    $date_box = date_format($date_part, 'y') .''. date_format($date_part, 'm') .''. date_format($date_part, 'd');

    $strSql = "
    SELECT * FROM (
      SELECT sc.LINE_PREF unitx, sa.LINE_CODE linex, sc.LINE_DESC linedx, sc.LINE_NAME_SPV leadx, sc.LINE_ORDR line_ordx, sa.PART partx, sb.PART_NAME partnx, 
      IFNULL(sb.PART_PACK_MAX_QTY,0) plbx, SUM(QTY_SHP) shipx, SUM(QTY_TRF) trfx, (SUM(QTY_TRF) - SUM(QTY_SHP)) blx,
      SUM(QTY_SHP) - MOD(SUM(QTY_SHP),IFNULL(sb.PART_PACK_MAX_QTY,0)) max_plbx,
      (SUM(QTY_SHP) - MOD(SUM(QTY_SHP),IFNULL(sb.PART_PACK_MAX_QTY,0)))/IFNULL(sb.PART_PACK_MAX_QTY,0) cnt_plbx,
      (SUM(QTY_SHP) - MOD(SUM(QTY_SHP),IFNULL(sb.PART_PACK_MAX_QTY,0)))/IFNULL(sb.PART_PACK_MAX_QTY,0) + IF(MOD(SUM(QTY_SHP),IFNULL(sb.PART_PACK_MAX_QTY,0))>0,1,0) cnt_plbax,
      sg.*, sh.line_blx
      FROM (
          SELECT a.shipment_line LINE_CODE, a.shipment_part PART,
          a.shipment_qty QTY_SHP, 0 QTY_TRF
          FROM shipment_track a
          LEFT JOIN line c ON a.shipment_line = c.LINE_CODE
          WHERE a.shipment_date = '" . $date . "'
          ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.shipment_date NOT IN $GLOB_AUDIT_DATE")."
          Union All
          SELECT a.PACK_BRCD_LINE, a.PACK_BRCD_PART, 0 QTY_SHP, SUM(a.PACK_BRCD_QTY) QTY_TRF
          FROM pack_brcd a 
          INNER JOIN pack_scan_tf b ON a.PACK_BRCD_NUM = b.SCAN_ID AND b.SCAN_FLAG = 'I'
          LEFT JOIN line c ON a.PACK_BRCD_LINE = c.LINE_CODE
          WHERE a.PACK_BRCD_DATE = '" . $date . "' AND b.SCAN_DATE = '" . $date . "'
          ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PACK_BRCD_DATE NOT IN $GLOB_AUDIT_DATE")."
          AND IFNULL(a.PACK_BRCD_FLAG,'') <> 'A'
          GROUP BY a.PACK_BRCD_LINE, a.PACK_BRCD_PART
      ) sa
      LEFT JOIN toy_part sb ON sa.PART = sb.PART_NUM
      LEFT JOIN line sc ON sa.LINE_CODE = sc.LINE_CODE
      LEFT JOIN (
        SELECT COUNT(box) box, SUM(boxnx) boxnx, SUM(planx) planx, SUM(planehx) planehx, SUM(actx) actx, SUM(actehx) actehx
        FROM (
          SELECT box, SUM(planx) planx, SUM(planehx) planehx, SUM(actx) actx, SUM(actehx) actehx,
          CASE WHEN (SUM(planx) - SUM(actx)) <> 0 THEN 0 ELSE 1 END boxnx
          FROM (
            SELECT box, partx, gb.PART_FCH_BUYER fchx, 
              IFNULL(planx, 0) planx, ((IFNULL(planx, 0) * gb.PART_FCH_BUYER)/1000) planehx, 
              IFNULL(actx, 0) actx, ((IFNULL(actx, 0) * gb.PART_FCH_BUYER)/1000) actehx
            FROM (
              SELECT a.box_nox box, partx, SUM(planx) planx, SUM(actx) actx 
              FROM (
                SELECT a.ship_box_num box_nox, a.ship_part_num partx, SUM(a.ship_qty) planx, 0 actx
                FROM shipment_plan_packlist a
                LEFT JOIN pack_brcd_box b ON a.ship_box_num = b.PACK_BRCD_BOX_NUM
                WHERE a.ship_date = '" . $date . "'
                GROUP BY a.ship_box_num, a.ship_part_num, a.ship_box_num UNION ALL
                SELECT box_nox, partx, 0 planx, SUM(actx) actx 
                FROM (
                SELECT a.SCAN_NO_BOX box_nox,
                  SUBSTRING_INDEX(SCAN_ID,'.', 1) partx, 0 planx,
                  CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(SCAN_ID,'.', 2),'.', -1) AS DECIMAL(9,0)) actx 
                FROM pack_scan a WHERE a.SCAN_NO_BOX LIKE '%" . $date_box . "%'
                ) a 
                GROUP BY box_nox, partx
              ) a GROUP BY box_nox, partx
            ) ga LEFT JOIN toy_part gb ON ga.partx = gb.PART_NUM
            WHERE IFNULL(ga.planx, 0) <> 0
          ) ga GROUP BY box
        ) ga
      ) sg ON 1 = 1
      LEFT JOIN (
        SELECT linex, SUM(trfx) - SUM(shpx) line_blx 
        FROM (
          SELECT linex, partx, CASE WHEN trfx > shpx THEN shpx ELSE trfx END trfx, shpx
          FROM (
            SELECT LINE_CODE linex, PART partx, SUM(QTY_TRF) trfx, SUM(QTY_SHP) shpx
            FROM (
                SELECT a.shipment_line LINE_CODE, a.shipment_part PART,
                a.shipment_qty QTY_SHP, 0 QTY_TRF
                FROM shipment_track a
                LEFT JOIN line c ON a.shipment_line = c.LINE_CODE
                WHERE a.shipment_date = '" . $date . "'
                Union All
                SELECT a.PACK_BRCD_LINE, a.PACK_BRCD_PART, 0 QTY_SHP, SUM(a.PACK_BRCD_QTY) QTY_TRF
                FROM pack_brcd a 
                INNER JOIN pack_scan_tf b ON a.PACK_BRCD_NUM = b.SCAN_ID AND b.SCAN_FLAG = 'I'
                LEFT JOIN line c ON a.PACK_BRCD_LINE = c.LINE_CODE
                WHERE a.PACK_BRCD_DATE = '" . $date . "' AND b.SCAN_DATE = '" . $date . "'
                AND IFNULL(a.PACK_BRCD_FLAG,'') <> 'A'
                GROUP BY a.PACK_BRCD_LINE, a.PACK_BRCD_PART
            ) ga GROUP BY LINE_CODE, PART
          ) ga
        ) ga GROUP BY linex
      ) sh ON sa.LINE_CODE = sh.linex
      WHERE 1=1
      " . (($unit !="" && $unit != "ALL") ? " AND sc.LINE_PREF ='$unit' " : "") . "
      " . (($line !="" && $line != "ALL") ? " AND sc.LINE_CODE ='$line' " : "") . "
      " . (($line_all !="") ? " AND sc.LINE_CODE IN (" . $line_all . ")" : "") . "
      GROUP BY sa.LINE_CODE, sa.PART
    ) ga
    #WHERE shipx <> 0
	  ORDER BY ga.line_blx, ga.line_ordx, ga.partx;
    ";

    //echo var_dump($strSql);
  } else if ($section == 4) { //attendance pdl
    $date = $_GET['date'];
    $strSql = "
      SELECT 1 labx, sa.cunitx, sa.depx, SUM(cntx) cntx, SUM(tnx) tnx, SUM(trx) trx, SUM(oprx) oprx, SUM(hlpx) hlpx, SUM(qcx) qcx, 
        SUM(hdrx) hdrx, SUM(absx) absx, SUM(sikx) sikx, SUM(permx) permx, SUM(npermx) npermx, 0 outx, SUM(inx) inx, SUM(outx) outx    
      FROM (
        SELECT sa.*, 1 cntx,
          CASE WHEN sa.unitx = '' THEN 'C' ELSE sa.unitx END cunitx, 		 
          CASE WHEN sa.epl IN ('TN', 'TU') THEN 1 ELSE 0 END tnx,
          CASE WHEN sa.epl = 'TR' THEN 1 ELSE 0 END trx, 
          CASE WHEN sa.jabx IN ('OPERATOR SEWING', 'PDM OPERATOR', 'OPERATOR PRESS') THEN 1 ELSE 0 END oprx,
          CASE WHEN sa.jabx IN ('QC', 'PDM QC') THEN 1 ELSE 0 END qcx,
          CASE WHEN sa.jabx IN ('HELPER') THEN 1 ELSE 0 END hlpx,
          CASE WHEN sa.ketx = 'H' THEN 1 ELSE 0 END hdrx,
          CASE WHEN sa.ketx = 'DL' THEN 1 ELSE 0 END dlx,  
          CASE WHEN sa.ketx = 'A' THEN 1 ELSE 0 END absx,		
          CASE WHEN sa.ketx IN ('S', 'SD') THEN 1 ELSE 0 END sikx,
          CASE WHEN sa.ketx IN ('C', 'CK', 'CM') THEN 1 ELSE 0 END permx,
          CASE WHEN sa.ketx IN ('I', 'L', 'LD') THEN 1 ELSE 0 END npermx,
          CASE WHEN sa.masuk = '$date' THEN 1 ELSE 0 END inx,
          CASE WHEN sa.ketx = 'O' THEN 1 ELSE 0 END outx
        FROM (
          SELECT a.*, REPLACE(b.nama, '.', '') depx, b.unit unitx, REPLACE(c.nama, '.', '') jabx, e.labor_name labx, b.`order` ordx, IFNULL(d.keterangan, 'A') ketx
          FROM view_empl_all a
          LEFT JOIN sub_departemens b ON a.id_sub = b.id 
          LEFT JOIN jabatans c ON a.id_jab = c.id
          LEFT JOIN labor_type e ON c.labor_id = e.labor_id
          LEFT JOIN (
            SELECT DISTINCT 'TN' epl, b.nik, a.keterangan 
            FROM absens a 
            LEFT JOIN karyawans b ON a.id_karyawan = b.id
            WHERE a.tanggal = '$date' UNION ALL
            SELECT 'TR' epl, b.nik, a.flag
            FROM karyawans_tr_absen a 
            LEFT JOIN karyawans_tr b ON a.id = b.id
            WHERE a.date_absen = '$date' UNION ALL
            SELECT DISTINCT'TU' epl, b.nik, a.keterangan
            FROM view_absen_ua a
            LEFT JOIN view_karyawan_ua b ON a.id_karyawan = b.id
            WHERE a.tanggal = '$date'
          ) d ON a.epl = d.epl AND a.nik = d.nik
          WHERE a.masuk <= '$date' AND a.keluar > '$date'
          AND e.labor_name = 'PDL'
          UNION ALL
          SELECT a.*, REPLACE(b.nama, '.', '') depx, b.unit unitx, REPLACE(c.nama, '.', '') jabx, e.labor_name labx, b.`order` ordx, 'O' ketx
          FROM view_empl_all a
          LEFT JOIN sub_departemens b ON a.id_sub = b.id 
          LEFT JOIN jabatans c ON a.id_jab = c.id
          LEFT JOIN labor_type e ON c.labor_id = e.labor_id
          WHERE a.keluar = '$date'
          AND e.labor_name = 'PDL'

        ) sa
      ) sa GROUP BY sa.cunitx, sa.depx 
      ORDER BY sa.cunitx, sa.ordx;
    ";

  } else if ($section == 5){ //attendance npdl
    
    $date = $_GET['date'];
    $strSql = "
    SELECT 2 labx, sa.depx, sa.jabx, SUM(cntx) cntx, SUM(tnx) tnx, SUM(trx) trx, SUM(oprx) oprx, SUM(hlpx) hlpx, SUM(qcx) qcx, 
      SUM(hdrx) hdrx, SUM(absx) absx, SUM(sikx) sikx, SUM(permx) permx, SUM(npermx) npermx, 0 outx, SUM(inx) inx, SUM(outx) outx      
    FROM (
      SELECT sa.nik, sa.nama, sa.udepx depx, sa.unitx, sa.jabx, sa.ordx, 1 cntx, 
        CASE WHEN sa.epl IN ('TN', 'TU') THEN 1 ELSE 0 END tnx,
        CASE WHEN sa.epl = 'TR' THEN 1 ELSE 0 END trx, 
        CASE WHEN sa.jabx IN ('OPERATOR SEWING', 'PDM OPERATOR', 'OPERATOR PRESS') THEN 1 ELSE 0 END oprx,
        CASE WHEN sa.jabx IN ('QC', 'PDM QC') THEN 1 ELSE 0 END qcx,
        CASE WHEN sa.jabx IN ('HELPER') THEN 1 ELSE 0 END hlpx,
        CASE WHEN sa.ketx = 'H' THEN 1 ELSE 0 END hdrx,
        CASE WHEN sa.ketx = 'DL' THEN 1 ELSE 0 END dlx,  
        CASE WHEN sa.ketx = 'A' THEN 1 ELSE 0 END absx,		
        CASE WHEN sa.ketx IN ('S', 'SD') THEN 1 ELSE 0 END sikx,
        CASE WHEN sa.ketx IN ('C', 'CK', 'CM') THEN 1 ELSE 0 END permx,
        CASE WHEN sa.ketx IN ('I', 'L', 'LD') THEN 1 ELSE 0 END npermx,
        CASE WHEN sa.masuk = '$date' THEN 1 ELSE 0 END inx,
        CASE WHEN sa.ketx = 'O' THEN 1 ELSE 0 END outx
      FROM (
        SELECT a.*, REPLACE(f.nama, '.', '') udepx, REPLACE(b.nama, '.', '') depx, b.unit unitx, REPLACE(c.nama, '.', '') jabx, e.labor_name labx, b.`order` ordx, IFNULL(d.keterangan, 'A') ketx
        FROM view_empl_all a
        LEFT JOIN sub_departemens b ON a.id_sub = b.id 
        LEFT JOIN jabatans c ON a.id_jab = c.id
        LEFT JOIN labor_type e ON c.labor_id = e.labor_id
        LEFT JOIN (
          SELECT DISTINCT 'TN' epl, b.nik, a.keterangan 
          FROM absens a 
          LEFT JOIN karyawans b ON a.id_karyawan = b.id
          WHERE a.tanggal = '$date' UNION ALL
          SELECT 'TR' epl, b.nik, a.flag
          FROM karyawans_tr_absen a 
          LEFT JOIN karyawans_tr b ON a.id = b.id
          WHERE a.date_absen = '$date' UNION ALL
          SELECT DISTINCT 'TU' epl, b.nik, a.keterangan
          FROM view_absen_ua a
          LEFT JOIN view_karyawan_ua b ON a.id_karyawan = b.id
          WHERE a.tanggal = '$date'
        ) d ON a.epl = d.epl AND a.nik = d.nik
        LEFT JOIN departemens f ON b.id_departemen = f.id
        WHERE a.masuk <= '$date' AND a.keluar > '$date'
        AND e.labor_name <> 'PDL' AND a.nik NOT IN ('G.1906.0832','M.2506.6796')
        UNION ALL
        SELECT a.*, REPLACE(f.nama, '.', '') udepx, REPLACE(b.nama, '.', '') depx, b.unit unitx, REPLACE(c.nama, '.', '') jabx, e.labor_name labx, b.`order` ordx, 'O' ketx
        FROM view_empl_all a
        LEFT JOIN sub_departemens b ON a.id_sub = b.id 
        LEFT JOIN jabatans c ON a.id_jab = c.id
        LEFT JOIN labor_type e ON c.labor_id = e.labor_id
        LEFT JOIN departemens f ON b.id_departemen = f.id
        WHERE a.keluar = '$date'
        AND e.labor_name <> 'PDL'
      ) sa
    ) sa GROUP BY sa.depx, sa.jabx 
    ORDER BY sa.depx, jabx;
    ";

  } else if ($section == 6){ //attendance detail

    $date = $_GET['date'];
    $flag = $_GET['flag'];
    $filx = $_GET['filx'];
    $fils = '';

    if ($flag == 'PDL') {
      $fils = "WHERE sa.depx ='$filx'";
    } else {
      $fils = "WHERE sa.jabx ='$filx'";
    }

    $strSql = "
    SELECT * FROM (
      SELECT sa.nik, sa.nama, sa.depx depx, sa.unitx, sa.jabx, sa.ordx, 1 cntx, ketx
      FROM (
        SELECT a.*, REPLACE(f.nama, '.', '') udepx, REPLACE(b.nama, '.', '') depx, b.unit unitx, REPLACE(c.nama, '.', '') jabx, e.labor_name labx, b.`order` ordx, IFNULL(d.keterangan, 'A') ketx
        FROM view_empl_all a
        LEFT JOIN sub_departemens b ON a.id_sub = b.id 
        LEFT JOIN jabatans c ON a.id_jab = c.id
        LEFT JOIN labor_type e ON c.labor_id = e.labor_id
        LEFT JOIN (
          SELECT DISTINCT 'TN' epl, b.nik, a.keterangan 
          FROM absens a 
          LEFT JOIN karyawans b ON a.id_karyawan = b.id
          WHERE a.tanggal = '$date' UNION ALL
          SELECT 'TR' epl, b.nik, a.flag
          FROM karyawans_tr_absen a 
          LEFT JOIN karyawans_tr b ON a.id = b.id
          WHERE a.date_absen = '$date' UNION ALL
          SELECT DISTINCT 'TU' epl, b.nik, a.keterangan
          FROM view_absen_ua a
          LEFT JOIN view_karyawan_ua b ON a.id_karyawan = b.id
          WHERE a.tanggal = '$date'
        ) d ON a.epl = d.epl AND a.nik = d.nik
        LEFT JOIN departemens f ON b.id_departemen = f.id
        WHERE a.masuk <= '$date' AND a.keluar > '$date'
        AND e.labor_name = '$flag'
        UNION ALL
        SELECT a.*, REPLACE(f.nama, '.', '') udepx, REPLACE(b.nama, '.', '') depx, b.unit unitx, REPLACE(c.nama, '.', '') jabx, e.labor_name labx, b.`order` ordx, 'O' ketx
        FROM view_empl_all a
        LEFT JOIN sub_departemens b ON a.id_sub = b.id 
        LEFT JOIN jabatans c ON a.id_jab = c.id
        LEFT JOIN labor_type e ON c.labor_id = e.labor_id
        LEFT JOIN departemens f ON b.id_departemen = f.id
        WHERE a.keluar = '$date'
        AND e.labor_name = '$flag'
      ) sa
    ) sa $fils ORDER BY sa.ketx, sa.jabx, sa.nik;
    ";
    //echo '<pre>'. $strSql . '</pre>';

  } else if ($section == 7){ //daily prod by transfer lbo
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $style = $_GET["style"];
    $group = $_GET["group"];
    $dates = substr($date, 0, 4) .''. substr($date, 5, 2) .''. substr($date, 8, 2);
    
    $strSql ="
    SELECT datex, partx, gc.PART_NAME partdx, fchx, ((fchx * pqtyx)/1000) pehx, linex, gb.LINE_DESC linedx, gb.LINE_PREF unitx, gb.LINE_NAME_SPV leadx, rdx, gidx, grpx, effx, optx, 
    IFNULL(optax, 0) optax, whnrx, whotx, whtotx, pqtyx, 
    1 pparx, (IFNULL((awhx - breakx), 0) + countx) awhx, 
    IFNULL(tqtyx,0) tqtyx, (((awhx - breakx) + countx) * IFNULL(optax, 0)) ahx,
    ((fchx * tqtyx)/1000) aehx, CASE WHEN tqtyx >= pqtyx THEN 1 ELSE 0 END aparx, 
    IFNULL(stimex,'00:00:00') stimex, 
    IFNULL(lipx, '00:00:00') lipx, countx, ltimex, IFNULL(ltqtyx, '00:00:00') ltqtyx 
    FROM (
      SELECT datex, partx, fchx, linex, rdx, grpx, gidx, effx, optx, optax, whnrx, whotx, 
      (IFNULL(whnrx, 0 ) + IFNULL(whotx, 0)) whtotx, pqtyx, stimex, lipx, HOUR(TIMEDIFF(lipx, stimex)) + 1 awhx, 
      CASE WHEN ('11:30:00' BETWEEN  stimex AND lipx) THEN 1 ELSE 0 END breakx, tqtyx, IFNULL(countx, 0) countx,
      ltimex, IFNULL(ltqtyx, 0) ltqtyx
      FROM (
        SELECT sa.*, sb.fipx, sb.lipx, sb.tqtyx, sc.optax, 
        CASE WHEN (IFNULL(sa.whnrx, 0) + IFNULL(sa.whotx, 0)) >= 5 THEN CAST('08:30:00' AS TIME) ELSE sb.fipx END stimex, sd.countx, se.ltimex, IFNULL(se.ltqtyx, 0) ltqtyx
        FROM (
          #planx
          SELECT a.datex, a.partx, a.fchx, a.linex, a.rdx, a.gidx, a.grpx, a.effx, a.optx, SUM(whnrx) whnrx, SUM(whotx) whotx, SUM(pqtyx) pqtyx 
          FROM (
            SELECT a.PLAN_PROD_DATE datex, a.PLAN_PROD_PART partx, a.PLAN_PROD_FCH fchx, a.PLAN_PROD_LINE_CODE linex, 
              a.PLAN_PROD_RD rdx, a.PLAN_PROD_GROUP gidx, a.PLAN_PROD_GROUP_ORD grpx, a.PLAN_PROD_EFF effx, a.PLAN_PROD_OPT optx,
              CASE WHEN a.PLAN_PROD_FLAG = 'N' THEN a.PLAN_PROD_WH ELSE 0 END whnrx,  
              CASE WHEN a.PLAN_PROD_FLAG = 'O' THEN a.PLAN_PROD_WH ELSE 0 END whotx,
              a.PLAN_PROD_QTY pqtyx 
            FROM plan_prod_daily a 
            WHERE a.PLAN_PROD_DATE='$date' ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
          ) a GROUP BY a.datex, a.partx, a.fchx, a.linex, a.rdx, a.gidx, a.grpx, a.effx, a.optx
        ) sa 
        LEFT JOIN (
          #transf
          SELECT a.transfer_barcode_date datex, a.transfer_part partx, a.transfer_line linex, a.transfer_group grpx, 
          MIN(a.transfer_prod_time) fipx,
          MAX(a.transfer_prod_time) lipx, SUM(a.transfer_qty) tqtyx
          FROM qc_lbo_transfer a 
          WHERE a.transfer_date = '$date' AND a.transfer_barcode_date = '$date' 
          GROUP BY a.transfer_barcode_date, a.transfer_part, a.transfer_line, a.transfer_group
        ) sb ON sb.datex = sa.datex AND sb.linex = sa.linex AND sb.grpx = sa.grpx AND sb.partx = sa.partx
        LEFT JOIN (
          #HC
          SELECT CAST(CONCAT(LEFT(datex, 4),'-', MID(datex, 5, 2),'-', RIGHT(datex, 2)) AS DATE) datex, linex, partx, CAST(gidx AS SIGNED) gidx, MAX(optax) optax 
          FROM (
            SELECT LEFT(a.PLAN_ID,8) datex, 
            RIGHT(LEFT(a.PLAN_ID,10),2) linex, 
            RIGHT(RIGHT(a.PLAN_ID, 3), LENGTH(RIGHT(a.PLAN_ID, 3)) - INSTR(RIGHT(a.PLAN_ID, 3), 'N')) gidx, a.OUT_PROD_GOOD_AHC optax,
            CONCAT( 
              LEFT(LEFT(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), 'N') -1), 5), '-',
              RIGHT(LEFT(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), 'N') -1),	LENGTH(LEFT(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), 'N') -1))-5)
            ) partx
            FROM output_prod_good_hc a 
            WHERE a.PLAN_ID LIKE '$dates%' AND INSTR(RIGHT(a.PLAN_ID, 3), 'N') <> 0 UNION ALL
            SELECT LEFT(a.PLAN_ID,8) datex, 
            RIGHT(LEFT(a.PLAN_ID,10),2) linex, 
            RIGHT(RIGHT(a.PLAN_ID, 3), LENGTH(RIGHT(a.PLAN_ID, 3)) - INSTR(RIGHT(a.PLAN_ID, 3), 'O')) gidx, a.OUT_PROD_GOOD_AHC optax,
            CONCAT( 
              LEFT(LEFT(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), 'O') -1), 5), '-',
              RIGHT(LEFT(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), 'O') -1),	LENGTH(LEFT(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), INSTR(RIGHT(a.PLAN_ID, LENGTH(a.PLAN_ID) - 10), 'O') -1))-5)
            ) partx
            FROM output_prod_good_hc a 
            WHERE a.PLAN_ID LIKE '$dates%' AND INSTR(RIGHT(a.PLAN_ID, 3), 'O') <> 0
          ) a 
          GROUP BY datex, linex, partx, gidx
        ) sc ON sc.datex = sa.datex AND sc.linex = sa.linex AND sc.gidx = sa.gidx AND sc.partx = sa.partx
        LEFT JOIN (
          #transfer after date
          SELECT datex, partx, linex, grpx, timex, 0 countx, COUNT(*) countdx
          FROM (
            SELECT DISTINCT a.transfer_barcode_date datex, a.transfer_part partx, a.transfer_line linex, a.transfer_group grpx, a.transfer_prod_time timex
            FROM qc_lbo_transfer a 
            WHERE a.transfer_barcode_date = '$date' AND a.transfer_date > '$date'
          ) ia GROUP BY datex, partx, linex, grpx, timex
        ) sd on sd.datex = sa.datex AND sd.linex = sa.linex AND sd.grpx = sa.grpx AND sd.partx = sa.partx
        LEFT JOIN (
          #transfer after date last qtyx
          SELECT datex, partx, linex, grpx, MAX(ltimex) ftimex, MAX(ltimex) ltimex, SUM(ltqtyx) ltqtyx
          FROM (
            SELECT a.transfer_barcode_date datex, a.transfer_part partx, a.transfer_line linex, a.transfer_group grpx, 
            CAST(CONCAT(a.transfer_date, ' ', a.transfer_prod_time) AS DATETIME) ltimex, a.transfer_qty ltqtyx
            FROM qc_lbo_transfer a 
            WHERE a.transfer_barcode_date = '$date' 
          ) ia GROUP BY datex, partx, linex, grpx
        ) se on se.datex = sa.datex AND se.linex = sa.linex AND se.grpx = sa.grpx AND se.partx = sa.partx
      ) ga
    ) ga 
    LEFT JOIN line gb ON ga.linex = gb.LINE_CODE
    LEFT JOIN toy_part gc ON ga.partx = gc.PART_NUM
    WHERE 1=1 "
    .(($unit !="" && $unit != "ALL") ? " AND gb.LINE_PREF ='$unit' " : "").""
    .(($line !="" && $line != "ALL") ? " AND gb.LINE_CODE ='$line' " : "").""
    .(($line_all !="") ? " AND gb.LINE_CODE IN (" . $line_all . ")" : "") . ""
    .(($style !="" && $style != "ALL") ? " AND UCASE(partx) = '$style'" : "").""
    .(($group !="" && $group != "ALL") ? " AND UCASE(grpx) = '$group'" : "")."
    ORDER BY gb.LINE_PREF, gb.LINE_ORDR, ga.grpx, ga.gidx, ga.partx;
    ";

    //echo '<pre>'. $strSql . '</pre>';

  } else if ($section == 90){
    $strSql ="
    SELECT DEFECT_CODE codex, CONCAT(DEFECT_CAT, ' > ' , UCASE(DEFECT_NAME)) namex FROM defect_lbo;
    ";
  }
}

//echo '<pre>'. $strSql . '</pre>';
$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  if ($section == 4 || $section == 5 || $section == 6) {
    $res = mysqli_query($conn_hr, $strSql);
  } else {
    $res = mysqli_query($conn, $strSql);
  }  
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
