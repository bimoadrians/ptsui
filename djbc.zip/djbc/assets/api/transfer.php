<?php
session_start();
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";
date_default_timezone_set('Asia/Jakarta');

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";

// valid user
$useridx = $_COOKIE['useridx'];
$userx = $_COOKIE['userx'];
$passx = $_COOKIE['passx'];
$pagex = $_COOKIE['pagex'];

$auth = checkLogin($userx, $passx, $conn);
$accx = checkAcces($pagex, $useridx, $conn);

$menu_view = $accx['menu_act_view'];
$menu_mod = $accx['menu_act_mod'];
$menu_del = $accx['menu_act_del'];

if ($menu_view == 0) {
  $rows["auth_view"] = "false";
  echo json_encode($rows);
  exit();
}

function setPrdTime($curtime) {
  $prdTime = '';
  // if ($curtime >= strtotime('04:00:00') && $curtime <= strtotime('09:29:59')) {
  //   $prdTime = '08:30:00';
  // } else if ($curtime >= strtotime('09:30:00') && $curtime <= strtotime('10:29:59')){
  //   $prdTime = '09:30:00';
  // } else if ($curtime >= strtotime('10:30:00') && $curtime <= strtotime('11:29:59')){
  //   $prdTime = '10:30:00';
  // } else if ($curtime >= strtotime('11:30:00') && $curtime <= strtotime('12:29:59')){
  //   $prdTime = '11:30:00';
  // } else if ($curtime >= strtotime('12:30:00') && $curtime <= strtotime('13:29:59')){
  //   $prdTime = '12:30:00';
  // } else if ($curtime >= strtotime('13:30:00') && $curtime <= strtotime('14:29:59')){
  //   $prdTime = '13:30:00';
  // } else if ($curtime >= strtotime('14:30:00') && $curtime <= strtotime('15:29:59')){
  //   $prdTime = '14:30:00';
  // } else if ($curtime >= strtotime('15:30:00') && $curtime <= strtotime('16:29:59')){
  //   $prdTime = '15:30:00';
  // } else if ($curtime >= strtotime('16:30:00') && $curtime <= strtotime('17:29:59')){
  //   $prdTime = '16:30:00';
  // } else if ($curtime >= strtotime('17:30:00') && $curtime <= strtotime('18:29:59')){
  //   $prdTime = '17:30:00';
  // } else if ($curtime >= strtotime('18:30:00') && $curtime <= strtotime('19:29:59')){
  //   $prdTime = '18:30:00';
  // } else if ($curtime >= strtotime('19:30:00') && $curtime <= strtotime('20:29:59')){
  //   $prdTime = '19:30:00';
  // } else if ($curtime >= strtotime('20:30:00') && $curtime <= strtotime('21:29:59')){
  //   $prdTime = '20:30:00';
  // } else if ($curtime >= strtotime('21:30:00') && $curtime <= strtotime('22:29:59')){
  //   $prdTime = '21:30:00';
  // } else if ($curtime >= strtotime('22:30:00') && $curtime <= strtotime('23:59:59')){
  //   $prdTime = '22:30:00';
  // }

  //NEW UPDATE 2025-07-12
  if ($curtime >= strtotime('04:00:00') && $curtime <= strtotime('08:30:59')) {
    $prdTime = '08:30:00';
  } else if ($curtime >= strtotime('08:31:00') && $curtime <= strtotime('09:30:59')){
    $prdTime = '09:30:00';
  } else if ($curtime >= strtotime('09:31:00') && $curtime <= strtotime('10:30:59')){
    $prdTime = '10:30:00';
  } else if ($curtime >= strtotime('10:31:00') && $curtime <= strtotime('11:30:59')){
    $prdTime = '11:30:00';
  } else if ($curtime >= strtotime('11:31:00') && $curtime <= strtotime('12:30:59')){
    $prdTime = '12:30:00';
  } else if ($curtime >= strtotime('12:31:00') && $curtime <= strtotime('13:30:59')){
    $prdTime = '13:30:00';
  } else if ($curtime >= strtotime('13:31:00') && $curtime <= strtotime('14:30:59')){
    $prdTime = '14:30:00';
  } else if ($curtime >= strtotime('14:31:00') && $curtime <= strtotime('15:30:59')){
    $prdTime = '15:30:00';
  } else if ($curtime >= strtotime('15:31:00') && $curtime <= strtotime('16:30:59')){
    $prdTime = '16:30:00';
  } else if ($curtime >= strtotime('16:31:00') && $curtime <= strtotime('17:30:59')){
    $prdTime = '17:30:00';
  } else if ($curtime >= strtotime('17:31:00') && $curtime <= strtotime('18:30:59')){
    $prdTime = '18:30:00';
  } else if ($curtime >= strtotime('18:31:00') && $curtime <= strtotime('19:30:59')){
    $prdTime = '19:30:00';
  } else if ($curtime >= strtotime('19:31:00') && $curtime <= strtotime('20:30:59')){
    $prdTime = '20:30:00';
  } else if ($curtime >= strtotime('20:31:00') && $curtime <= strtotime('21:30:59')){
    $prdTime = '21:30:00';
  } else if ($curtime >= strtotime('21:31:00') && $curtime <= strtotime('22:30:59')){
    $prdTime = '22:30:00';
  } else if ($curtime >= strtotime('22:31:00') && $curtime <= strtotime('23:59:59')){
    $prdTime = '23:30:00';
  }
  return $prdTime;
}

if ($auth != false) {
  //prod list
  if ($section == 1){ // view summary transfer lbo
    $date = $_GET["date"];
    $unit = $_GET["unit"];

    $strSql = "
    SELECT sa.linex, sb.LINE_DESC linedx, sa.partx, sc.PART_NAME partdx, groupx, SUM(pqty) pqty, SUM(tqty) tqty 
    FROM (
      SELECT a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_PART partx, IFNULL(a.PLAN_PROD_GROUP_ORD,'') groupx, SUM(a.PLAN_PROD_QTY) pqty, 0 tqty 
      FROM plan_prod_daily a 
      LEFT JOIN line b ON a.PLAN_PROD_LINE_CODE = b.LINE_CODE 
      WHERE a.PLAN_PROD_DATE ='$date' AND b.LINE_PREF = '$unit'
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
      GROUP BY a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_PART, IFNULL(a.PLAN_PROD_GROUP_ORD,'') UNION ALL
      SELECT a.transfer_line, a.transfer_part, IFNULL(a.transfer_group,'') groupx, 0 pqty, SUM(a.transfer_qty) tqty 
      FROM qc_lbo_transfer a 
      LEFT JOIN line b ON a.transfer_line = b.LINE_CODE
      WHERE a.transfer_date ='$date' AND b.LINE_PREF = '$unit' 
      ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.transfer_date NOT IN $GLOB_AUDIT_DATE")."
      GROUP BY a.transfer_line, a.transfer_part, IFNULL(a.transfer_group,'')
    ) sa 
    LEFT JOIN line sb ON sa.linex = sb.LINE_CODE
    LEFT JOIN toy_part sc ON sa.partx = sc.PART_NUM
    GROUP BY sa.linex, sb.LINE_DESC, sa.partx, sc.PART_NAME, groupx
    ORDER BY sb.LINE_PREF, sb.LINE_ORDR, sa.groupx;
    ";
    //echo '<pre>'. $strSql . '</pre>';

  } else if ($section == 2) { // view barcode transfer lbo
    $date = $_GET["date"];
    $unit = $_GET["unit"];
    $strSql = "
    SELECT a.transfer_date datex, a.transfer_time timex, a.transfer_barcode barcodex, 
      b.LINE_PREF unitx, a.transfer_line linex, b.LINE_DESC linedx, 
      a.transfer_part partx, c.PART_NAME partdx, a.transfer_group groupx, a.transfer_qty trfx 
    FROM qc_lbo_transfer a 
    LEFT JOIN line b ON a.transfer_line = b.LINE_CODE
    LEFT JOIN toy_part c ON a.transfer_part = c.PART_NUM
    WHERE a.transfer_date ='$date' 
    ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.transfer_date NOT IN $GLOB_AUDIT_DATE")."
    AND b.LINE_PREF = '$unit' ORDER BY a.transfer_date, a.transfer_time;
    ";
    //echo '<pre>'. $strSql . '</pre>';

  } else if ($section == 3) { // add scan barcode
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $barcode = $_POST["barcode"];
    $unit = $_POST["unit"];
    
    //CHEK SCAN
    $strSql ="
    SELECT COUNT(a.PACK_BRCD_NUM) countx, COUNT(c.transfer_barcode) countrx, a.PACK_BRCD_DATE brcdatex,
      a.PACK_BRCD_LINE linex, b.LINE_DESC linedx, a.PACK_BRCD_LEADER leadx, a.PACK_BRCD_GRP groupx,
      a.PACK_BRCD_PART partx, d.PART_NAME partdx, IFNULL(a.PACK_BRCD_QTY, 0) qtyx 
    FROM pack_brcd a 
    LEFT JOIN line b on a.PACK_BRCD_LINE = b.LINE_CODE
    LEFT JOIN qc_lbo_transfer c on a.PACK_BRCD_NUM = c.transfer_barcode
    LEFT JOIN toy_part d on a.PACK_BRCD_PART = d.PART_NUM
    WHERE a.PACK_BRCD_NUM='$barcode' 
    #AND b.LINE_PREF='$unit'
    AND a.PACK_BRCD_FLAG = 'N';
    ";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
        
    $count_brcd = (int)$row['countx'];
    $count_trfx = (int)$row['countrx'];
    $barcode_date = $row['brcdatex'];
    $line = $row['linex'];
    $lined = $row['linedx'];
    $part = $row['partx'];
    $partd = $row['partdx'];
    $lead = $row['leadx'];
    $group = $row['groupx'];
    $qty = $row['qtyx'];
    $prdtime = setPrdTime(time());

    //invalid barcode or unit
    $action = '';
    $actionFlag = '';
    $actionMsg = '';
    
    $sqlAct = '';

    if ($count_brcd == 0) {
      $action = 'FALSE';
      $actionFlag = 'INVALID';
      $actionMsg = 'Barcode atau unit tidak valid.';
    } else {
      // update data
      if ($count_trfx != 0) {
        $sqlAct = "
        UPDATE `qc_lbo_transfer` SET 
          `transfer_count`=`transfer_count`+1,
          `transfer_scan_second`=NOW(),
          `transfer_mod_date`=NOW(),
          `transfer_mod_id`='$useridx'
        WHERE transfer_barcode='$barcode';  
        ";
        $actionFlag = "UPDAVE";
        $actionMsg = 'Succes re-scan barcode.';
      // insert data
      } else {
        $sqlAct = "
        INSERT INTO `qc_lbo_transfer` (
          `transfer_date`, `transfer_barcode`, `transfer_time`, 
          `transfer_barcode_date`, `transfer_prod_time`, `transfer_line`, `transfer_part`, 
          `transfer_group`, `transfer_lead`, `transfer_qty`, 
          `transfer_count`, `transfer_scan_frist`,
          `transfer_add_date`, `transfer_add_id`
        ) VALUES (
          NOW(), '$barcode', NOW(), 
          '$barcode_date', '$prdtime', '$line', '$part', 
          '$group', '$lead', '$qty', 
          1, NOW(),
          NOW(), $useridx
        );";
        $actionFlag = "INSERT";
        $actionMsg = 'Succes add or update barcode.';
      }
      //echo '<pre>'. $sqlAct . '</pre>';
      $action = '';
      if (mysqli_query($conn, $sqlAct)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
        $actionMsg = 'Invalid barcode or unit.';
     }
    }
    $strSql = "SELECT '$action' actionx, '$actionFlag' actionflagx, '$actionMsg' msgx, CURDATE() datex, CURTIME() timex, '$barcode' barcodex, '$unit' unitx, '$line' linex, '$lined' linedx, '$lead' leadx, '$part' partx, '$partd' partdx, '$group' groupx, '$qty' qtyx;";
  
  } else if ($section == 4) { // del scan barcode
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    // if ($menu_del == 0) {
    //   $rows["auth_mod"] = "false";
    //   echo json_encode($rows);
    //   exit();
    // } 

    $barcode = $_POST["barcode"];
    $rowid = $_POST["rowid"];
    
    $strSql = "SELECT DATEDIFF(CURDATE(), a.transfer_date) otsx FROM qc_lbo_transfer a WHERE transfer_barcode='$barcode';";
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $ots = (int)$row['otsx'];

    if ($ots < 7) {
      $strSql ="DELETE FROM qc_lbo_transfer WHERE transfer_barcode='$barcode';";
      $action ='';
      if (mysqli_query($conn, $strSql)) {
        $action = 'TRUE';
      } else {
        $action = 'FALSE';
      }
      $strSql = "SELECT '$action' actionx, 'Success deleting barcode' msgx, '$rowid' rowx;";
    } else {
      $strSql = "SELECT 'FALSE' actionx, 'Exced maximum delete date.' msgx, '$rowid' rowx;";
    }
  } else if ($section == 5) { // view transfer balance lbo
    $date = $_GET["date"];
    $date_to = $_GET["date_to"];
    $unit = $_GET["unit"];
    $line = $_GET["line"];
    $line_all = $_GET["line_all"];
    $style = $_GET["style"];
    $group = $_GET["group"];
    $opt = (int)$_GET["opt"];
    $opteh = $_GET["opteh"];

    $query_date_opt = '';
    if ($opt == 1) {
      $query_date_opt = 'a.transfer_barcode_date';
    } else {
      $query_date_opt = 'a.transfer_date';
    }

    $strSql = "
    SELECT datex, HOUR(timex_min) firsth, HOUR(timex_max) lasth, (HOUR(timex_max) - HOUR(timex_min)) + 1 sequenh
    FROM (
      SELECT sx.datex, MIN(timex) timex_min, MAX(timex) timex_max
      FROM (
        SELECT $query_date_opt datex, a.transfer_prod_time timex 
        FROM qc_lbo_transfer a WHERE $query_date_opt BETWEEN '$date' AND '$date_to' AND a.transfer_line NOT IN ('41','42')
      ) sx
      GROUP BY sx.datex
    ) sx order by sx.datex;
    ";

    //echo $strSql;
    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);

    // CASE WHEN sz.datex = '2024-06-25' AND sz.timex = 14 then lotx END `2024_06_25_14`,

    $str_sum = "SELECT sz.linex linehx, sz.partx parthx, sz.groupx grouphx, SUM(sz.tfx) tfx";
    $str_col = "SELECT sz.linex, sz.partx, sz.groupx, sz.qtyx tfx";

    $res = mysqli_query($conn, $strSql);
    if (mysqli_num_rows($res) > 0) {
      while ($row = mysqli_fetch_array($res)) {
        for($x = $row['firsth']; $x <= $row['lasth']; $x++){
          //qty
          $str_sum = $str_sum . ", SUM(`D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`) `D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
          $str_col = $str_col . ", CASE WHEN sz.datex='" . $row['datex'] . "' AND sz.timex=" . $x ." THEN sz.qtyx END `D_" . str_replace("-","_", $row['datex']) . "_" . $x ."`";
        }
      }
    }
    //qty
    $str_col = $str_col . " FROM (";
    $str_col = $str_col ."
    SELECT sx.linex, sx.partx, sx.groupx, sx.datex, sx.timex, SUM(qtyx) qtyx
    FROM (
      SELECT a.transfer_line linex, a.transfer_part partx, IFNULL(a.transfer_group,'') groupx, 
      $query_date_opt datex, HOUR(a.transfer_prod_time) timex, SUM(a.transfer_qty) qtyx 
      FROM qc_lbo_transfer a WHERE $query_date_opt BETWEEN '$date' AND '$date_to'
      AND a.transfer_line NOT IN ('41','42')
      GROUP BY a.transfer_line, a.transfer_part, IFNULL(a.transfer_group,''), $query_date_opt, HOUR(a.transfer_prod_time)
    ) sx GROUP BY sx.linex, sx.partx, sx.groupx, sx.datex, sx.timex
    ";
    $str_col = $str_col . " ) sz";
    $str_col = $str_sum . ' FROM (' . $str_col . ') sz GROUP BY sz.linex, sz.partx, sz.groupx';

    //last query
    $strSql = "
    SELECT c.LINE_PREF unitx, a.linex, c.LINE_DESC line_namex, c.LINE_NAME_SPV spvx, 
      a.groupx, a.partx, d.PART_NAME part_namex, IFNULL(d.PART_FCH_BUYER, d.PART_FCH_ACTUAL) fchx, 
      d.PART_TYPE part_typex, a.planx, a.admx, IFNULL(a.actual, 0) actualx, 
      e.*
    FROM (
      SELECT a.linex, a.partx, a.groupx, SUM(planx) planx, SUM(admx) admx, SUM(trfx) actual 
      FROM (
        SELECT a.PLAN_PROD_LINE_CODE linex, a.PLAN_PROD_PART partx, IFNULL(a.PLAN_PROD_GROUP_ORD,'') groupx, 
          SUM(a.PLAN_PROD_QTY) planx, 0 trfx, 0 admx 
        FROM plan_prod_daily a 
        WHERE a.PLAN_PROD_DATE BETWEEN '$date' AND '$date_to'
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.PLAN_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
        GROUP BY a.PLAN_PROD_LINE_CODE, a.PLAN_PROD_PART, IFNULL(a.PLAN_PROD_GROUP_ORD,'') UNION ALL
        
        SELECT a.transfer_line, a.transfer_part, IFNULL(a.transfer_group,''), 
          0 planx, SUM(a.transfer_qty) trfx, 0 admx 
        FROM qc_lbo_transfer a WHERE $query_date_opt BETWEEN '$date' AND '$date_to'
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND $query_date_opt NOT IN $GLOB_AUDIT_DATE")."
        AND a.transfer_line NOT IN ('41','42')
        GROUP BY a.transfer_line, a.transfer_part, IFNULL(a.transfer_group,'') UNION ALL

        SELECT a.OUT_PROD_LINE_CODE, a.OUT_PROD_PART, IFNULL(a.OUT_PROD_GROUP,''), 
          0 planx, 0 trfx, SUM(a.OUT_PROD_QTY) admx
        FROM output_prod_good a WHERE 
        IFNULL(a.OUT_PROD_FLAG_DEL, '') <> 'D'
        AND a.OUT_PROD_DATE BETWEEN '$date' AND '$date_to'
        ".($GLOB_AUDIT_FLAG == "OFF" ? "" : " AND a.OUT_PROD_DATE NOT IN $GLOB_AUDIT_DATE")."
        GROUP BY a.OUT_PROD_LINE_CODE, a.OUT_PROD_PART, IFNULL(a.OUT_PROD_GROUP,'')

      ) a GROUP BY a.linex, a.partx, a.groupx
    ) a LEFT JOIN line c ON a.linex = c.LINE_CODE
    LEFT JOIN toy_part d ON a.partx = d.PART_NUM
    LEFT JOIN (
    ". $str_col ."
    ) e on e.linehx = a.linex AND e.parthx = a.partx AND e.grouphx = a.groupx
    WHERE 1=1 " . (($unit !="" && $unit != "ALL") ? " AND c.LINE_PREF ='$unit' " : "") . "
    " . (($line !="" && $line != "ALL") ? " AND a.linex ='$line' " : "") . "
    " . (($line_all !="") ? " AND a.linex IN (" . $line_all . ")" : "") . "
    " . (($group !="" && $group != "ALL") ? " AND a.groupx ='$group' " : "") . "
    " . (($style !="" && $style != "ALL") ? " AND (UCASE(a.partx) LIKE '%".strtoupper($style)."%' OR UCASE(d.PART_NAME) LIKE '%".strtoupper($style)."%')" : "") . "
    ORDER BY c.LINE_PREF, c.LINE_ORDR, a.groupx, a.partx;
    ";
  } else if ($section == 6) { // add wip scan
    
    if ($menu_mod == 0) {
      $rows["auth_mod"] = "false";
      echo json_encode($rows);
      exit();
    } 

    $barcode = $_POST["barcode"];
    $loc = $_POST["loc"];

    $strSql = "
    SELECT SUM(countl) countl, SUM(countb) countb 
    FROM (
      SELECT COUNT(*) countl, 0 countb FROM ic_storage a 
      WHERE storage_alias='$barcode' AND storage_area='WIP' UNION ALL
      SELECT 0 countl, COUNT(*) countb FROM pack_brcd a 
      WHERE a.PACK_BRCD_NUM='$barcode' AND a.PACK_BRCD_FLAG = 'N'
    ) a
    ;";

    $res = mysqli_query($conn, $strSql);
    $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $countloc = (int)$row['countl'];
    $countbcd = (int)$row['countb'];
    
    if ($countloc > 0 AND $countbcd == 0) {
      // SET LOC
      //$strSql = "SELECT 'TRUE' islocx, 'FALSE' isbcdx;";
      $strSql = "
        SELECT 'TRUE' actionx, 'LOC' flagx, 'Location Selected' msgx, a.*, b.PART_NAME descx
        FROM (
          SELECT a.transfer_loc locx, a.transfer_part partx, SUM(transfer_qty) qtyx 
          FROM wip_count_scan a 
          WHERE a.transfer_loc = '$barcode'
          GROUP BY a.transfer_loc, a.transfer_part
        ) a 
        LEFT JOIN toy_part b ON a.partx = b.PART_NUM;
      ";
    } else if ($countloc == 0 AND $countbcd > 0) {
      // SET BCD
      $strSql = "SELECT 'FALSE' islocx, 'TRUE' isbcdx;";
    } else {
      // SET FALSE
      $strSql = "SELECT 'FALSE' actionx, '' flagx, 'Invalid barcode or location' msgx;";
    }

    //$strSql = "SELECT 'TRUE' islocx, 'FALSE' isbcdx;";

    // //CHEK SCAN
    // $strSql ="
    // SELECT COUNT(a.PACK_BRCD_NUM) countx, COUNT(c.transfer_barcode) countrx, a.PACK_BRCD_DATE brcdatex,
    //   a.PACK_BRCD_LINE linex, b.LINE_DESC linedx, a.PACK_BRCD_LEADER leadx, a.PACK_BRCD_GRP groupx,
    //   a.PACK_BRCD_PART partx, d.PART_NAME partdx, IFNULL(a.PACK_BRCD_QTY, 0) qtyx 
    // FROM pack_brcd a 
    // LEFT JOIN line b on a.PACK_BRCD_LINE = b.LINE_CODE
    // LEFT JOIN qc_lbo_transfer c on a.PACK_BRCD_NUM = c.transfer_barcode
    // LEFT JOIN toy_part d on a.PACK_BRCD_PART = d.PART_NUM
    // WHERE a.PACK_BRCD_NUM='$barcode' AND b.LINE_PREF='$unit'
    // AND a.PACK_BRCD_FLAG = 'N';
    // ";

    // $res = mysqli_query($conn, $strSql);
    // $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
        
    // $count_brcd = (int)$row['countx'];
    // $count_trfx = (int)$row['countrx'];
    // $barcode_date = $row['brcdatex'];
    // $line = $row['linex'];
    // $lined = $row['linedx'];
    // $part = $row['partx'];
    // $partd = $row['partdx'];
    // $lead = $row['leadx'];
    // $group = $row['groupx'];
    // $qty = $row['qtyx'];
    // $prdtime = setPrdTime(time());

    // //invalid barcode or unit
    // $action = '';
    // $actionFlag = '';
    // $actionMsg = '';
    
    // $sqlAct = '';

    // if ($count_brcd == 0) {
    //   $action = 'FALSE';
    //   $actionFlag = 'INVALID';
    //   $actionMsg = 'Barcode atau unit tidak valid.';
    // } else {
    //   // update data
    //   if ($count_trfx != 0) {
    //     $sqlAct = "
    //     UPDATE `qc_lbo_transfer` SET 
    //       `transfer_count`=`transfer_count`+1,
    //       `transfer_scan_second`=NOW(),
    //       `transfer_mod_date`=NOW(),
    //       `transfer_mod_id`='$useridx'
    //     WHERE transfer_barcode='$barcode';  
    //     ";
    //     $actionFlag = "UPDATE";
    //     $actionMsg = 'Succes re-scan barcode.';
    //   // insert data
    //   } else {
    //     $sqlAct = "
    //     INSERT INTO `qc_lbo_transfer` (
    //       `transfer_date`, `transfer_barcode`, `transfer_time`, 
    //       `transfer_barcode_date`, `transfer_prod_time`, `transfer_line`, `transfer_part`, 
    //       `transfer_group`, `transfer_lead`, `transfer_qty`, 
    //       `transfer_count`, `transfer_scan_frist`,
    //       `transfer_add_date`, `transfer_add_id`
    //     ) VALUES (
    //       NOW(), '$barcode', NOW(), 
    //       '$barcode_date', '$prdtime', '$line', '$part', 
    //       '$group', '$lead', '$qty', 
    //       1, NOW(),
    //       NOW(), $useridx
    //     );";
    //     $actionFlag = "INSERT";
    //     $actionMsg = 'Succes add or update barcode.';
    //   }
    //   //echo '<pre>'. $sqlAct . '</pre>';
    //   $action = '';
    //   if (mysqli_query($conn, $sqlAct)) {
    //     $action = 'TRUE';
    //   } else {
    //     $action = 'FALSE';
    //     $actionMsg = 'Invalid barcode or unit.';
    //   }
    // }
    // $strSql = "SELECT '$action' actionx, '$actionFlag' actionflagx, '$actionMsg' msgx, CURDATE() datex, CURTIME() timex, '$barcode' barcodex, '$unit' unitx, '$line' linex, '$lined' linedx, '$lead' leadx, '$part' partx, '$partd' partdx, '$group' groupx, '$qty' qtyx;";
  
  }
}
//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
