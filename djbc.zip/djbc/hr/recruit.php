<?php 
session_start();  
error_reporting(E_ALL & ~E_NOTICE);

include "config.php";

$section = isset($_GET["section"]) ? $_GET["section"] : 0;
$strSql = "";
if ($section == 1) {
  $nama = strtoupper($_POST['nam']);
  $jkl = $_POST['jkl'];
  $tempat = strtoupper($_POST['tml']);
  $tanggal = $_POST['tgl'];
  $alamat = strtoupper($_POST['alm']);
  $skill = strtoupper($_POST['skl']);
  $pendidikan = strtoupper($_POST['pdd']);
  $phone = $_POST['pho'];
  $captcha = $_POST['sec'];

  if ($_SESSION["captcha"] == $captcha) {
    
    $strSql ="
    INSERT INTO `oline_recruitmen` (`tanggal`, `nama`, `jkl`, `tem_lahir`, `tgl_lahir`, `alamat`, `pendidikan`, `skill`, `phone`, `ip`, `add_date`) VALUES (
      NOW(), '$nama', '".($jkl == 'L' ? 'L' : 'P')."', 
      '$tempat', '$tanggal', '$alamat', '$pendidikan', '".($skill == 'S' ? 'SKILL' : 'NON SKILL')."', '$phone', '" .get_client_ip()."', NOW());
    ";

    if (mysqli_query($conn_hr, $strSql)) {
      $act = 'TRUE';
    } else {
      $act = 'FALSE';
    }
    $strSql = "SELECT '' etypex, '$act' actx, '".$_SESSION["captcha"]."' secx;";

  } else {
    $strSql = "SELECT 'chapta' etypex, '$act' actx, '".$_SESSION["captcha"]."' secx;";
  }
} else if ($section == 2){
  $nik = strtoupper($_POST['nik']);

  $strSql = " 
    SELECT IFNULL(COUNT(*), 0) countx 
    FROM scan_logs a 
    WHERE a.LOG_DATE=CURDATE() 
    AND a.LOG_NIK = '$nik';
  ";
  $res = mysqli_query($conn_hr, $strSql);
  $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
  $day_count = $row['countx'];

  // $strSql = " 
  //   SELECT COUNT(*) countx 
  //   FROM scan_logs a 
  //   WHERE a.LOG_DATE=CURDATE() AND 
  //   DATE_FORMAT(a.LOG_TIME, '%H:%i') = DATE_FORMAT(CURTIME(), '%H:%i')
  //   AND a.LOG_NIK = '$nik';
  // ";

  $strSql = " 
    SELECT COUNT(*) countx 
    FROM scan_logs a 
    WHERE a.LOG_DATE=CURDATE() 
    AND TIMESTAMPDIFF(MINUTE, a.LOG_DATE_ADD, NOW()) <=3    
    AND a.LOG_NIK = '$nik';
  ";

  $res = mysqli_query($conn_hr, $strSql);
  $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
  $rec_count = $row['countx'];

  if ($rec_count == 0) {
    //INSERT
    $strSql = "
      INSERT INTO `scan_logs` (
        `LOG_DATE`, `LOG_TIME`, 
        `LOG_ID`, `LOG_NIK`, `LOG_FLAG`, 
        `LOG_FLAG_EMPL`, `LOG_IP`, `LOG_COM_KEY`, 
        `LOG_DATE_ADD`
      ) VALUES (
       CURDATE(), CURTIME(), 
       0, '$nik', 'I', 'T', NULL, NULL, NOW()
      );
    ";

    $rec_count = $rec_count + 1;
    mysqli_query($conn_hr, $strSql);
  }

  $strSql = "
  SELECT NOW() datex, $day_count dayx, 'T' eflagx, a.nik nikx, a.nama namax, b.nama subx, c.nama jabx
  FROM karyawans a
  LEFT JOIN sub_departemens b ON a.id_sub_departemen = b.id
  LEFT JOIN jabatans c ON a.id_jabatan = c.id 
  WHERE a.nik='$nik' UNION ALL
  SELECT NOW() datex, $day_count dayx, 'T' eflagx, a.nik nikx, a.nama namax, b.nama subx, c.nama jabx
  FROM karyawans_tr a 
  LEFT JOIN sub_departemens b ON a.id_sub_dept = b.id
  LEFT JOIN jabatans c ON a.id_jabatan = c.id
  WHERE a.nik ='$nik';
  ";
} else if ($section == 3){ // scan area line
  
  $nik = strtoupper($_POST['nik']);
  $line = strtoupper($_POST['line']);

  // $strSql = " 
  //   SELECT IFNULL(COUNT(*), 0) countx 
  //   FROM scan_log_line a
  //   WHERE a.scan_tgl=CURDATE() 
  //   AND a.LOG_NIK = '$nik';
  // ";
  // $res = mysqli_query($conn_hr, $strSql);
  // $row = mysqli_fetch_array($res, MYSQLI_ASSOC);
  // $rec_count = $row['countx'];

  // if ($rec_count == 0) {
  //   //INSERT
  //   $strSql = "
  //     INSERT INTO `scan_log_line` (
  //       `scan_nik`, `scan_tgl`, `scan_time`, 
  //       `scan_nama`, `LOG_NIK`, `LOG_FLAG`, 
  //       `LOG_FLAG_EMPL`, `LOG_IP`, `LOG_COM_KEY`, 
  //       `LOG_DATE_ADD`
  //     ) VALUES (
  //      CURDATE(), CURTIME(), 
  //      0, '$nik', 'I', 'T', NULL, NULL, NOW()
  //     );
  //   ";
  //   mysqli_query($conn_hr, $strSql);
  // } else {
  //   $strSql = "
  //     INSERT INTO `scan_logs` (
  //       `LOG_DATE`, `LOG_TIME`, 
  //       `LOG_ID`, `LOG_NIK`, `LOG_FLAG`, 
  //       `LOG_FLAG_EMPL`, `LOG_IP`, `LOG_COM_KEY`, 
  //       `LOG_DATE_ADD`
  //     ) VALUES (
  //      CURDATE(), CURTIME(), 
  //      0, '$nik', 'I', 'T', NULL, NULL, NOW()
  //     );
  //   ";
  //   mysqli_query($conn_hr, $strSql);
  // }

  $strSql = "
  SELECT NOW() datex, 'T' eflagx, a.nik nikx, a.nama namax, b.nama subx, c.nama jabx
  FROM karyawans a
  LEFT JOIN sub_departemens b ON a.id_sub_departemen = b.id
  LEFT JOIN jabatans c ON a.id_jabatan = c.id 
  WHERE a.nik='$nik' UNION ALL
  SELECT NOW() datex, 'T' eflagx, a.nik nikx, a.nama namax, b.nama subx, c.nama jabx
  FROM karyawans_tr a 
  LEFT JOIN sub_departemens b ON a.id_sub_dept = b.id
  LEFT JOIN jabatans c ON a.id_jabatan = c.id
  WHERE a.nik ='$nik';
  ";
}

//echo '<pre>'. $strSql . '</pre>';

$rows = [];
if ($auth === false) {
  $rows["auth"] = "false";
} else {
  $res = mysqli_query($conn_hr, $strSql);
  if (mysqli_num_rows($res) > 0) {
    while ($row = mysqli_fetch_assoc($res)) {
      # code...
      $rows[] = $row;
    }
  }else{
    $rows["empty"] = "empty";
  }
}
echo json_encode($rows);
?>